/*  The idea behind bigfloat is to get enough precision to plot interesting
	regions of "fractal" or Hausdorf spaces.  Change precision with the
	MNTSA_SIZE define, this is the number of 32 bit longwords used to
	store the mantissa.  Should be even.

			Author = Mike Rosing
			  date  = feb. 14, 2000
*/

#define	MNTSA_SIZE	8
#define	D_SIZE		(MNTSA_SIZE/2)
#define	SIGN_BIT		0x80000000
#define	MSB			0x40000000
#define	MS_MNTSA	(MNTSA_SIZE-1)
#define	MS_MNTSAd	(D_SIZE-1)
#define	DIVISION_LOOPS	3
/*  division loops = log_2(MNTSA_SIZE), see division() */

typedef struct
{
	long		expnt;
	union
	{	/*  data stored in little endian order  */
		unsigned long long d[D_SIZE];
		unsigned long e[MNTSA_SIZE];
	} mntsa;
} FLOAT;

typedef struct
{
	FLOAT	real;
	FLOAT	imag;
} COMPLEX;

#define	OPLOOPd(i)		for(i=0; i<D_SIZE ; i++)

#define	OPLOOP(i)			for(i=0; i<MNTSA_SIZE; i++)

typedef short int       INDEX;
typedef unsigned long   ELEMENT;

void null( FLOAT *a);
void add( FLOAT *a, FLOAT *b, FLOAT *c);
void subtract( FLOAT *a, FLOAT *b, FLOAT *c);
void multiply( FLOAT *a, FLOAT *b, FLOAT *c);
int divide( FLOAT *a, FLOAT *b, FLOAT *c);
void init_float();
void square_root( FLOAT *in, FLOAT *out);
void int_to_float( int num, FLOAT *x);
void one( FLOAT *x);
int ascii_to_float( char *instring, FLOAT *outnum);
void float_to_ascii( FLOAT *numbr, char *outstring);
void printfloat( char *string, FLOAT *numbr);
double bigdown( FLOAT *big);
int iszero( FLOAT *x);
