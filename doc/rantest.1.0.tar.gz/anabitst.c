
#include "randtest.h"

void AnalyzeBitStream(FILE *fpInput, int nWordSize, int nBitNumber)
{
	BITSTREAM	Bits;

	if (InitBitStream(&Bits, fpInput, nWordSize, nBitNumber) != 0)
	{
		perror("AnalyzeBitStream Unable to initialize bit stream:");

		return;
	}

	FIPSTest(&Bits, nBitNumber);

	return;
}