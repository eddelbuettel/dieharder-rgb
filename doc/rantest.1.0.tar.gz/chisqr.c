/****************************************************************************
*									    *
*	The purpose of this code is to create a random bit test suite to    *
*  determine if a set of random bits is "random enough", and if not, just   *
*  what is not random about it.  A combination of DIEHARD and NIST 	    *
*  tests have been combined.  Full documentation should be included.	    *
*					       				    *
*				Author = Mike Rosing			    *
*				 date  = sept. 17, 2001			    *
*									    *
****************************************************************************/

#include <math.h>

/*     subroutine quanc8(fun,a,b,abserr,relerr,result,errest,nofun,flag)

	For details see "Computer Methods for Mathematical Computations"
	by Forsythe, Malcolm, Moler, Prentice Hall, (c) 1977
      double precision fun, a, b, abserr, relerr, result, errest, flag
      integer nofun
*/
double quanc8( double fun(),
			double a, double b,
			double abserr,  double relerr,
			double *errest, double *flag,
			int *nofun)
{
/*
c
c   estimate the integral of fun(x) from a to b
c   to a user provided tolerance.
c   an automatic adaptive routine based on
c   the 8-panel newton-cotes rule.
c
c   input ..
c
c   fun     the name of the integrand function subprogram fun(x).
c   a       the lower limit of integration.
c   b       the upper limit of integration.(b may be less than a.)
c   relerr  a relative error tolerance. (should be non-negative)
c   abserr  an absolute error tolerance. (should be non-negative)
c
c   output ..
c
c   result  an approximation to the integral hopefully satisfying the
c           least stringent of the two error tolerances.
c   errest  an estimate of the magnitude of the actual error.
c   nofun   the number of function values used in calculation of result.
c   flag    a reliability indicator.  if flag is zero, then result
c           probably satisfies the error tolerance.  if flag is
c           xxx.yyy , then  xxx = the number of intervals which have
c           not converged and  0.yyy = the fraction of the interval
c           left to do when the limit on  nofun  was approached.
c
      double precision w0,w1,w2,w3,w4,area,x0,f0,stone,step,cor11,temp
      double precision qprev,qnow,qdiff,qleft,esterr,tolerr
      double precision qright(31),f(16),x(16),fsave(8,30),xsave(8,30)
      double precision dabs,dmax1
      integer levmin,levmax,levout,nomax,nofin,lev,nim,i,j
*/
      double w0,w1,w2,w3,w4,area,x0,f0,stone,step,cor11,temp;
      double qprev,qnow,qdiff,qleft,esterr,tolerr;
      double qright[31],f[16],x[16],fsave[8][30],xsave[8][30];
      double result, dmax1;
      int levmin,levmax,levout,nomax,nofin,lev,nim,i,j;
/*c
c   ***   stage 1 ***   general initialization
c   set constants.
c*/
      levmin = 1;
      levmax = 30;
      levout = 6;
      nomax = 5000;
      i = 2;
//      nofin = nomax - 8*(levmax-levout+2**(levout+1));
      for( j=0; j<levout; j++) i *=2;
      nofin = nomax - 8*(levmax-levout + i);
      
/*c
c   trouble when nofun reaches nofin
c*/
      w0 =   3956.0l / 14175.0l;
      w1 =  23552.0l / 14175.0l;
      w2 =  -3712.0l / 14175.0l;
      w3 =  41984.0l / 14175.0l;
      w4 = -18160.0l / 14175.0l;
/*c
c   initialize running sums to zero.
c*/

      *flag = 0.0l;
      result = 0.0l;
      cor11  = 0.0l;
      *errest = 0.0l;
      area   = 0.0l;
      *nofun = 0;
      if (a == b) return 0.0l;
/*c
c   ***   stage 2 ***   initialization for first interval
c*/
      lev = 0;
      nim = 1;
      x0 = a;
      x[15] = b;
      qprev  = 0.0l;
      f0 = fun(x0);
      stone = (b - a) / 16.0l;
      x[7]  =  (x0  + x[15]) / 2.0l;
      x[3]  =  (x0  + x[7])  / 2.0l;
      x[11] =  (x[7]  + x[15]) / 2.0l;
      x[1]  =  (x0  + x[3])  / 2.0l;
      x[5]  =  (x[3]  + x[7])  / 2.0l;
      x[9] =  (x[7]  + x[11]) / 2.0l;
      x[13] =  (x[11] + x[15]) / 2.0l;
      for( j=1; j<16; j+=2)
         f[j] = fun(x[j]);
      *nofun = 9;
/*c
c   ***   stage 3 ***   central calculation
c   requires qprev,x0,x2,x4,...,x16,f0,f2,f4,...,f16.
c   calculates x1,x3,...x15, f1,f3,...f15,qleft,qright,qnow,qdiff,area.
c*/
      while (nim )
      {
	x[0] = (x0 + x[1]) / 2.0l;
	f[0] = fun(x[0]);
	for (j = 2; j<16; j+=2)
	{
	  x[j] = (x[j-1] + x[j+1]) / 2.0l;
	  f[j] = fun(x[j]);
	}
	*nofun += 8;
	step = (x[15] - x0) / 16.0l;
	qleft  =  (w0*(f0 + f[7])  + w1*(f[0]+f[6])  + w2*(f[1]+f[5])
		   + w3*(f[2]+f[4])  +  w4*f[3]) * step;
	qright[lev]=(w0*(f[7]+f[15])+w1*(f[8]+f[14])+w2*(f[9]+f[13])
		     + w3*(f[10]+f[12]) + w4*f[11]) * step;
	qnow = qleft + qright[lev];
	qdiff = qnow - qprev;
	area = area + qdiff;
/*c
c   ***   stage 4 *** interval convergence test
c*/
	esterr = fabs(qdiff) / 1023.0l;
//      tolerr = dmax1(abserr,relerr*fabs(area)) * (step/stone);
	dmax1 = relerr*fabs(area);
	tolerr = (abserr > dmax1) ? abserr : dmax1;
	tolerr *= (step/stone);
	      
	if ((lev < levmin)  || ( (lev < levmax) && (*nofun <= nofin) && (esterr > tolerr)))
	{     
/*c
c   ***   stage 5   ***   no convergence
c   locate next interval.
c*/
	  nim = 2*nim;
	  lev = lev+1;
/*c
c   store right hand elements for future use.
c*/
	  for( i=0; i<8; i++)
	  {
	    fsave[i][lev] = f[i+8];
	    xsave[i][lev] = x[i+8];
	  }
/*c
c   assemble left hand elements for immediate use.
c*/
	  qprev = qleft;
	  for( i=7; i>=0; i--)
	  {
	    f[2*i+1] = f[i];
	    x[2*i+1] = x[i];
	  }
	  continue;
	}
/*c
c   current level is levmax.
c*/
	else if (lev >= levmax)
	  *flag += 1.0l;	      	

/*c
c   ***   stage 6   ***   trouble section
c   number of function values is about to exceed limit.
c*/
	      
	else if (*nofun > nofin)
	{
	  nofin = 2*nofin;
	  levmax = levout;
	  *flag += (b - x0) / (b - a);
	}
/*c
c   ***   stage 7   ***   interval converged
c   add contributions into running sums.
c*/
	result += qnow;
	*errest += esterr;
	cor11 += qdiff / 1023.0l;

/*c
c   locate next interval.
c*/

	while( !(nim & 1) && nim)
	{
	  nim = nim/2;
	  lev = lev-1;
	}
	nim = nim + 1;
	if (lev <= 0) break;
/*c
c   assemble elements required for the next interval.
c*/
	qprev = qright[lev];
	x0 = x[15];
	f0 = f[15];
	for( i=0; i<8; i++)
	{
	  f[2*i+1] = fsave[i][lev];
	  x[2*i+1] = xsave[i][lev];
	}
      }
/*c
c   ***   stage 8   ***   finalize and return
c*/
      result = area + cor11;

/*c
c   make sure errest not less than roundoff level.
c*/
      if (*errest == 0.0l) return(result);
      temp = fabs(result) + *errest;
      while (temp == fabs(result))
      {
	temp = fabs(result) + *errest;
	*errest *= 2.0l;
      }
      return (result - *errest);
}

/*  First test function  */

double func( double x)
{
	return 1.0/(x*x*x);
}

/*  The following code implements the gamma function for the special
	cases used in the chi square test.  If the input is even, a simple
	factorial is computed.  If the input is odd, a pseudo factorial is
	computed based on formula from "Handbook of Mathematical Functions"
	pg 255, equation 6.1.12
*/

double gamadf( int df)
{
	double gama;
	int i, n;
	
/*  if df is odd, do n+1/2 formula  */

	if( df & 1)
	{
		gama = 1.7724538509;  // sqrt(pi)
		n = (df-1)/2;
		if ( n == 0) return gama;
		for( i=1; i<=n; i++) gama *= (2*i - 1)/2.0;
		return gama;
	}
	gama = 1.0;
	n = df/2;
	for( i=2; i<n; i++) gama *= i;
	return gama;
}

/*  compute the chi-square probability function.
	This is from equation 26.4.1 in "Handbook of Mathematical Functions."
	Enter with chi^2 value and number of degrees of freedom (df).
	Returns probability value.  P(chi^2, df) = 1.0 - Q(chi^2, df).
	P is computed here, but Q is what's used by NIST. (the proability
	that what you observe is *not* random.  Big Q is bad.)
*/

static double df;

double integrand( double t)
{
	double temp;

	if (t < 1e-6) return 0.0;	
	temp = (df/2.0 - 1.0) * log(t);
	temp = exp(temp) * exp(-t/2.0);
	return temp;
}

double chisqr( double x, int deg)
{
	double term, errest, flag;
	int nofun;
	
	df = deg;

/*  use approximation for large df  (see 26.4.13) */

	if( deg > 120)
	{
	  term = sqrt(2.0*x) - sqrt(2.0*df - 1.0);
	  return term;
	}

/*  otherwise compute by brute force  */

	term = quanc8( integrand, 0.0, x, 1e-8, 1e-8, &errest, &flag, &nofun);
	if( flag > 0.0) printf("problems in chi square integrand! flag = %f\n", flag);
	term /= gamadf( deg);
	term /= exp( (deg/2.0)*log(2.0));
	if( term > 1.0) return (1.0);
  	return (term);
}

/*  integrand for error function  */

double erfint( double t)
{
  return exp( -t*t);
}

/*  complementary error function, by brute force  */

double erfc( double z)
{
  double erf, errest, flag;
  int nofun;

  erf = quanc8( erfint, 0.0, z, 1e-8, 1e-8, &errest, &flag, &nofun);
  if( flag > 1.0) printf("problems in erfc integral.\n");
  erf *= 1.0/sqrt(atan(1.0));  // 2.0/sqrt(pi)
  return (1.0 - erf);
}

/*main()
{
	double a, b, abserr, relerr;
	double errest, flag, result;
	int nofun;
	
/*	abserr = .01l;
	relerr = .01l;
	a = .01l;
	b = 3.0l;
	result = quanc8( func , a,  b, abserr,   relerr, &errest,  &flag, &nofun);
	printf("result = %f, errest = %f, flag = %f\n", result, errest, flag);
	printf("number of function calls = %d\n", nofun);*/
	
/*	a = chisqr( 4.0, 7);
	printf("chi square = %f\n", 1.0-a);
}*/
