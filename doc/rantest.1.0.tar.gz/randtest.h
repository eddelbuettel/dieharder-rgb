#ifndef RANDTEST_HEADER_FILE_INCLUDED
#define RANDTEST_HEADER_FILE_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>  // for linux
#define BITS_PER_BYTE 8

#define NUL '\000'

#define false 0
#define true 1

#define SAFECOPY(a,b) {strncpy(a, b, ((sizeof a) - 1));	a[(sizeof a) - 1] = 0;	}

#define SAFECAT(a,b) {strncat(a, b, ((sizeof a) - 1));	a[(sizeof a) - 1] = 0;	}

typedef struct _bs
{
	FILE	*fp;
	int		nWordSize;
	int		nBitNumber;
	int		nError;
	int		nPrevBit;
	unsigned char	ucByteBuf;
}
BITSTREAM;

typedef struct
{
	unsigned char *byteptr;
	int	       bitpos;
} SRCPTR;

typedef struct
{
        int    class;
        double prob;
} CHIENTRY;

typedef unsigned char bool;

#define BIGENDIAN 		1
#define LITTLENDIAN 	0
#define MAXRANK		64


	void	AnalyzeNumeric(FILE *fpInput, int nWordSize);
	void	AnalyzeBitStream(FILE *fpInput, int nWordSize, int nBitNumber);
	int		FillBitStreamBuffer(BITSTREAM *bp);
	int		InitBitStream(BITSTREAM *bp, FILE *fpInput, int nWordSize, int nBitNumber);
	int		GetNextBit(BITSTREAM *bp);
	int		ResetBitStream(BITSTREAM *bp);

	void	FIPSTest(BITSTREAM *bp, int nBit);
	void	F140Monobit(BITSTREAM *bp, int nBit);
	void	F140Poker(BITSTREAM *bp, int nBit);
	void	F140Runs(BITSTREAM *bp, int nBit);
	void	F140LongRun(BITSTREAM *bp, int nBit);

int binrank( SRCPTR  *src, int dim, int endian);
void getbits( SRCPTR *src, unsigned char *dst, int endian, int numbits);
double genMatrixP( int M, int r);
int ranktest( SRCPTR src, int endian, int Ndim, int Mtodo,
	      double *chsqr, double *pvalue);
double chisqr( double x, int deg);
double erfc( double z);
double monobits( SRCPTR *src, int numbits);
double freqtest( SRCPTR *src, int endian, int blocksize, int numblocks);
double runs( SRCPTR *src, int endian, int numbits);
double invPow( int x);
double combination( int n, int r);
double probOfRun( int m, int blocksize);
double probRunBig( int m, int blocksize);
void BuildChiTable( int blocksize, CHIENTRY *ctbl);
double longrun( SRCPTR *src, int endian, 
		int blocksize, int numblocks, 
		CHIENTRY *chitable, int tblsz);


#endif
