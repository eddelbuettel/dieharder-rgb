
#include "randtest.h"

void AnalyzeNumeric(FILE *fpInput, int nWordSize)
{
	return;
}