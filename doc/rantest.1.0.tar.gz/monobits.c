/*  monobits test.  The most basic test possible,
    this counts the number of 1 bits in a block.
    p-value -s erfc(abs(sum)/sqrt(2n)) as described
    in NIST document.  Sum is incremented for set bit,
    decremented for cleared bit.

    Enter with pointer to start of bit block and 
    number of bits to process.  Returns p-value
    and updated source pointer.
*/

#include "randtest.h"

double monobits( SRCPTR *src, int numbits)
{
  double sum, arg;
  unsigned char mask;

  arg = numbits;
  sum = 0.0;
  mask = 1 << src->bitpos;
  while( numbits)
  {
    if( *(src->byteptr) & mask) sum += 1.0;
    else sum -= 1.0;
    mask <<= 1;
    numbits--;
    if ( !(mask & 0xff))
    {
      mask = 1;
      src->byteptr++;
    }
    src->bitpos++;
    src->bitpos &= 7;
  }
  arg = fabs(sum) / sqrt( 2.0*arg);
  arg = erfc(arg);
  return( arg);
}


