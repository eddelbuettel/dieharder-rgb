/*****************************************************************************
 *  dsa.h                                                      VERSION 3.00  *
 *---------------------------------------------------------------------------*
 *  D I G I T A L  S I G N A T U R E   S T A N D A R D  (DSS)                *
 *  FEDERAL INFORMATION PROCESSING STANDARDS PUBLICATION 186                 *
 *  APRIL 1993                                                               *
 *---------------------------------------------------------------------------*
 *  This software was produced at the National Institute of Standards and    *
 *  Technology (NIST) as part of research efforts and is for demonstration   *
 *  purposes only. Our primary goals in its design did not include widespread*
 *  use outside of our own laboratories.  Acceptance of this software implies*
 *  that you agree to use it for non-commercial purposes only and that you   *
 *  agree to accept it as nonproprietary and unlicensed,not supported by NIST*
 *  and not carrying any warranty, either expressed or implied, as to its    *
 *  performance or fitness for any particular purpose.                       *
 *---------------------------------------------------------------------------*
 *  Produced by the National Institute of Standards and Technology (NIST),   *
 *  Computer Systems Laboratory (CSL) Security Technology Group.             *
 *                                                                           *
 *  DATE        WHO            WHAT                                          *
 *  ----------- -------------- ------------------------------------------    *
 *  11/29/2000  Larry Bassham  Re-wrote for increased P and Q sizes          *
 *                                                                           *
 ****************************************************************************/

#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _DSA_H_
#define _DSA_H_

#include "config.h"
#include "Mp.h"
#include "sha.h"

#define MAXPLEN		    128	/* Maximum modulus size in bytes - for DSA2 = 384 */
#define	MAXQLEN		     20	/* Maximum private key size in bytes */
#define	MAXGLEN		MAXPLEN
#define	MAXHLEN		MAXPLEN
#define	MAXSEEDLEN	     64	/* SEED/SEEDKEY size */
#define	MINSEEDLEN	     20	/* SEED/SEEDKEY size */

#define	MAXXLEN		MAXQLEN
#define	MAXYLEN		MAXPLEN
#define	MAXKLEN		MAXQLEN
#define	MAXRLEN		MAXQLEN
#define	MAXSLEN		MAXQLEN

typedef struct _DomainParms_struct {
	MP		P;
	MP		Q;
	MP		G;
	} DomainParms;

/* Selection of functions to generate the G() */
#define		RAN_NULL	0		/*  RAN_SOURCE: Source of random numbers  */
#define		RAN_SHS		1		/*  Should be SHS, DES, or ANSI           */
#define		RAN_DES		2		/*  (NULL only at startup, else error)    */
#define		RAN_ANSI	4
#define		RAN_SHS_CN	9		/*  These two specify the RNGs in 186-2   */
#define		RAN_DES_CN 10		/*  with the change notice                */
#define		SHA_MASK	1
#define		DES_MASK	2
#define		ANSI_MASK	4
#define		CN_MASK		8


#ifdef PROTOTYPES

int		DSA_GenKeyPair(DomainParms PQG, MP XKey, MP Seed, int b,
					   MP *X, MP *Y, int rndtype);
void	free_KeyPair(MP *X, MP *Y);
void	DSA_Sign(BYTE *hashM, DomainParms PQG, MP X, MP Kkey, int b,
				 MP *R, MP *S, int rndtype);
int		DSA_Verify(BYTE *hashM, DomainParms PQG, MP Y, MP R, MP S);
int		DSA_PrimeGen(MP Seed, MP Qparam, MP Pparam);
int		DSA_PrimeVal(MP Seed, int Counter, MP Qparam, MP Pparam);
void	HashSeed(BYTE *Seed, int SeedBytes, BYTE *Val, int HashBytes);
int		DSA_Ggen(MP P, MP Q, MP H, MP G);
int		DSA_GVal(MP Pparam, MP Qparam, MP Gparam, MP Hparam);
int		DSA_Genpqg(MP Seed, int Pbits, int Qbits,
				   DomainParms *PQG, MP H, int *counter);
int		DSA_Test();

#else

int     DSA_GenKeyPair();
void	free_KeyPair();
int     DSA_Sign();
int     DSA_Verify();
int     DSA_PrimeGen();
int     DSA_PrimeVal();
void	HashSeed();
int     DSA_Ggen();
int     DSA_GVal();
int     DSA_Genpqg();
int		DSA_Test();

#endif  /* PROTOTYPES */

#endif  /* _DSA_H_ */

#if defined(__cplusplus)
}
#endif