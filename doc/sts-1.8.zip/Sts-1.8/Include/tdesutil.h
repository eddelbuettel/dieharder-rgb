/*****************************************************************************
 *  TDESUTIL.H                                                               *
 *---------------------------------------------------------------------------*
 *  December 1999                                                            *
 *---------------------------------------------------------------------------* 
 *  This software was developed at the National Institute of Standards and   *
 *  Technology by employees of the Federal Government in the course of their *
 *  official duties. Pursuant to title 17 Section 105 of the United States   *
 *  Code this software is not subject to copyright protection and is in the  *
 *  public domain.  We would appreciate acknowledgement if the software is   *
 *  used.																	 *
 *	This software was produced as part of research efforts and is for		 *
 *  demonstration purposes only. Our primary goals in its design did not	 *
 *  include widespread*
 *  use outside of our own laboratories.  Acceptance of this software implies*
 *  that you agree to use it for non-commercial purposes only and that you   *
 *  agree to accept it as nonproprietary and unlicensed,not supported by NIST*
 *  and not carrying any warranty, either expressed or implied, as to its    *
 *  performance or fitness for any particular purpose.                       *
 *---------------------------------------------------------------------------*
 *  Produced by the National Institute of Standards and Technology (NIST),   *
 *  Computer Systems Laboratory (CSL) Security Technology Group.             *
 ****************************************************************************/

#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _TDESUTIL_H_
#define _TDESUTIL_H_

#include "config.h"
#include "tdes.h"

typedef unsigned char BYTE;
typedef unsigned short USHORT;
typedef USHORT DIGIT; /*16 bit word*/

#ifdef PROTOTYPES

int  setkey (int sw1, int sw2, BYTE inkey[8], unsigned ks[16][4]);
int  des (BYTE in[8], BYTE out[8], unsigned ks[16][4]);
void pack(BYTE *packed, BYTE *binary, int len);
void unpack(BYTE *packed, BYTE *binary, int len);
void sprdltob (long as_l, BYTE as_ba[]);
int  getlinef(FILE *ptr, char *s, int l);
void putl(char c, char *s);
void get_hex2(char *name, int len, char *resp);
void setoddparity(BYTE key1[], BYTE key2[], BYTE key3[]);
void calculateiv2iv3(BYTE *iv1, BYTE *iv2, BYTE *iv3);
void key56to64(BYTE *key56, BYTE *key64);
void getf_hex2(FILE *name, int len, char *resp);
void basis_vector(BYTE *arr, int arr_len, int bitpos);
void genrand( BYTE *val, int len);
void bit_shift_left(char *x, int l);
void GetErrorMsg(char *msg, int errorno);

#else

int  setkey();
int  des();
void pack();
void unpack();
void sprdltob();
int  getline();
void putl();
void get_hex2();
void setoddparity();
void calculateiv2iv3();
void key56to64();
void getf_hex2();
void basis_vector();
void genrand();
void bit_shift_left();
void GetErrorMsg();

#endif /* PROTOTYPES */

#endif /* _TDESUTIL_H_ */

#if defined(__cplusplus)
}
#endif
