
#ifndef _SHA_DEFS_
#define _SHA_DEFS_

typedef unsigned char	BYTE;
typedef	unsigned int	UINT;
typedef	unsigned long	ULONG;
typedef ULONG			WORD64[2];

#define LITTLE_ENDIAN

#define	MSBITNULONG		0x80000000
#define	LSBITNULONG		0x00000001

#endif  /* _SHA_DEFS_ */