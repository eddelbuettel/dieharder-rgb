
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _PROTO_H_
#define _PROTO_H_

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
      		  F U N C T I O N  P R O T O T Y P E S 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

double igamc(double, double);
double erfc(double);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     S T A T I S T I C A L  T E S T  F U N C T I O N  P R O T O T Y P E S 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void Frequency(int);
void BlockFrequency(int, int);
void CumulativeSums(int);
void Runs(int);
void LongestRunOfOnes(int);
void Rank(int);
void DiscreteFourierTransform(int);
void NonOverlappingTemplateMatchings(int, int);
void OverlappingTemplateMatchings(int, int);
void Universal(int, int, int);
void ApproximateEntropy(int, int);
void RandomExcursions(int);
void RandomExcursionsVariant(int);
int  LempelZivCompression(int);
void LinearComplexity(int, int);
void Serial(int, int);
void SequenceComplexity(int);

#endif  /*  _PROTO_H_  */

#if defined(__cplusplus)
}
#endif