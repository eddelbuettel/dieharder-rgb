
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _DECLS_H_
#define _DECLS_H_

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                   G L O B A L   D A T A  S T R U C T U R E S 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

BitField	*epsilon;				/* BIT STREAM 	            */
BitField	*templates;				/* TEMPLATE 	            */
TP			tp;						/* TEST PARAMETER STRUCTURE */
FILE		*stats[NUMOFTESTS+1];	/* FILE OUTPUT STREAM       */
FILE		*results[NUMOFTESTS+1];	/* FILE OUTPUT STREAM       */
FILE		*output;				/* FILE OUTPUT STREAM       */
FILE		*post;					/* FILE OUTPUT STREAM       */
FILE		*fileInfo;				/* FILE OUTPUT STREAM       */
FILE		*cycleInfo;				/* FILE OUTPUT STREAM       */
FILE		*grid;					/* FILE OUTPUT STREAM       */
FILE		*pvals;					/* FILE OUTPUT STREAM       */
FILE		*pvalsRndExc;			/* FILE OUTPUT STREAM       */
FILE		*pvalsRndExcVar;		/* FILE OUTPUT STREAM       */
FILE		*pvalsAperiodic[NUMAPERIODICFILES];	/* FILE OUTPUT STREAM       */
BYTE		testVector[NUMOFTESTS+1];
char   generatorDir[NUMOFGENERATORS][20] = {"AlgorithmTesting", "DRBG-SHA1",
				"DRBG-SHA224", "DRBG-SHA256", "DRBG-SHA384", "DRBG-SHA512",
				"LCG", "BBS", "MS", "QCG1", "QCG2", "CCG", "XOR",
				"ANSI-X9.17", "G-DES", "MODEXP"};
char   testNames[NUMOFTESTS+1][50] = {" ", "frequency", "block-frequency",
				"cumulative-sums", "runs", "longest-run", "rank", "fft",
				"nonperiodic-templates", "overlapping-templates", "universal",
				"apen", "random-excursions", "random-excursions-variant",
				"serial", "linear-complexity"};

#endif

#if defined(__cplusplus)
}
#endif