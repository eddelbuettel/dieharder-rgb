
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _SHA384_H_
#define _SHA384_H_

#include "shadefs.h"
#include "sha512.h"

#define	SHA384_BLOCKLEN			1024
#define	SHA384_BYTEBLOCKLEN		(SHA384_BLOCKLEN/8)
#define SHA384_WORD64BLOCKLEN	(SHA384_BYTEBLOCKLEN/sizeof(WORD64))
#define SHA384_HASHLEN			384
#define SHA384_BYTEHASHLEN		(SHA384_HASHLEN/8)
#define SHA384_ULONGHASHLEN		(SHA384_BYTEHASHLEN/4)
#define	SHA384_WORD64HASHLEN	(SHA384_BYTEHASHLEN/sizeof(WORD64))
#define SHA384_IVLEN			512
#define SHA384_BYTEIVLEN		(SHA384_IVLEN/8)
#define SHA384_ULONGIVLEN		(SHA384_BYTEIVLEN/4)
#define	SHA384_WORD64IVLEN		(SHA384_BYTEIVLEN/sizeof(WORD64))

typedef struct {
	int		Numbits;
	WORD64	MsgLen[2];
	WORD64	Mblock[SHA384_WORD64BLOCKLEN];
	WORD64	H[SHA384_WORD64IVLEN];
} SHA384_CTX;

#ifdef PROTOTYPES

void	SHA384_ProcessBlock(SHA384_CTX *ctx);
int		SHA384_Init(SHA384_CTX *ctx);
int		SHA384_Init2(SHA384_CTX *ctx, WORD64 *IH);
int		SHA384_Update(SHA384_CTX *ctx, BYTE *buffer, int bitcount);
int		SHA384_Final(SHA384_CTX *ctx);

#else

void	SHA384_ProcessBlock();
int		SHA384_Init();
int		SHA384_Init2();
int		SHA384_Update();
int		SHA384_Final();

#endif  /* PROTOTYPES */

#endif  /*  _SHA384_H_  */

#if defined(__cplusplus)
}
#endif