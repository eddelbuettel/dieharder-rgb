
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _RNG_H_
#define _RNG_H_

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <time.h>
#include "dsa.h"
#include "shaexterns.h"
#include "tdesutil.h"
#include "mp.h"

#define	BAD_SEC_LEVEL	1
#define	BAD_HASH_LEN	2
#define	BAD_REQ_LEN		3
	
typedef struct _Hash_DRBG_CTX {
	int		hash_len;
	BYTE	*V;
	BYTE	*C;
	BYTE	*reseed_counter;
	int		strength;
	int		seedlen;
	int		min_entropy;
	} Hash_DRBG_CTX;


int  DSAGenX(MP XKey, MP XSeed, int b, MP Q, MP *X, int RndType);
int  DSAGenX_org(MP XKey, MP XSeed, int b, MP Q, MP *X, int rndtype);
int  DSAGenX_CN(MP XKey, MP XSeed, int b, MP Q, MP *X, int rndtype);
int  DSAGenK(MP KKey, int b, MP Q, MP *K, int rndtype);
int  DSAGenK_org(MP KKey, int b, MP Q, MP *K, int rndtype);
int  DSAGenK_CN(MP KKey, int b, MP Q, MP *K, int rndtype);
void shaG(BYTE *tval, BYTE *C, int b, BYTE **G, int hashlen);
void desG(BYTE *t, BYTE *c, BYTE *G);
void ECDSAGenX(MP XKey, MP XSeed, int b, MP N, MP *X, int rndtype);
void ANSIX931Init(TDESCTX *context, BYTE *Key1, BYTE *Key2);
void ANSIX931GenR(TDESCTX *context, BYTE *V, BYTE *DT, BYTE *R);

int  DSARngTest();
int  ECDSARngTest(int rngtype);
int  ANSIX931RngTest();

int RNG_Test();

int  init_Hash_DRBG(Hash_DRBG_CTX *ctx, int req_sec_level, int hash_len);
BYTE *Hash_df(Hash_DRBG_CTX *ctx, BYTE *in_data, int in_data_len, int num_bits);
int Hash_DRBG(Hash_DRBG_CTX *ctx, int num_bits_requested, int req_sec_level, BYTE **rnd_val);
void Hashgen(HASH *hash, BYTE *V, int seedlen, BYTE **pseudorandomBits, int numOfBits);

#endif

#if defined(__cplusplus)
}
#endif