
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _EXTERNS_H_
#define _EXTERNS_H_

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                   G L O B A L   D A T A  S T R U C T U R E S 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

extern BitField	*epsilon;				/* BIT STREAM 	            */
extern BitField	*templates;				/* TEMPLATE 	            */
extern TP		tp;						/* TEST PARAMETER STRUCTURE */
extern FILE		*stats[NUMOFTESTS+1];	/* FILE OUTPUT STREAM       */
extern FILE		*results[NUMOFTESTS+1];	/* FILE OUTPUT STREAM       */
extern FILE		*output;				/* FILE OUTPUT STREAM       */
extern FILE		*post;					/* FILE OUTPUT STREAM       */
extern FILE		*fileInfo;				/* FILE OUTPUT STREAM       */
extern FILE		*cycleInfo;				/* FILE OUTPUT STREAM       */
extern FILE		*grid;					/* FILE OUTPUT STREAM       */
extern FILE		*pvals;					/* FILE OUTPUT STREAM       */
extern FILE		*pvalsRndExc;			/* FILE OUTPUT STREAM       */
extern FILE		*pvalsRndExcVar;		/* FILE OUTPUT STREAM       */
extern FILE		*pvalsAperiodic[NUMAPERIODICFILES];	/* FILE OUTPUT STREAM       */
extern BYTE		testVector[NUMOFTESTS+1];
extern char		generatorDir[NUMOFGENERATORS][20];
extern char		testNames[NUMOFTESTS+1][50];

#endif


#if defined(__cplusplus)
}
#endif