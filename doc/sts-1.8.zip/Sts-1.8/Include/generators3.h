
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _GENERATOR3_H_
#define _GENERATOR3_H_

#include	"config.h"
#include	"sha.h"
#ifdef sun
#include	<sys/time.h>
#endif
					/* Temp for G_from_DES testing */
#define ENCRYPT 0
#define DECRYPT 1
#define DSA_H_SIZE 20   
#define DSA_Q_SIZE 20   
#define DSA_X_SIZE 20   

#define FALSE           0
#define TRUE            1
#define CHECK_PARITY  	1
#define IGNORE_PARITY	0
#define	CHECKPARITY		1
#define	IGNOREPARITY	0
#define	LeftHalf(x)		(x)
#define	RightHalf(x)	(x+8)

/*typedef unsigned long ULONG;*/

void mbcopy(BYTE str1[], BYTE str2[], int len);
void G_from_DES(BYTE *t, BYTE *c, BYTE *G);
void GDES(ULONG *t, ULONG *c, BYTE *outbuf);
void G_from_ANSI(BYTE *t, BYTE *c, BYTE *G);
void ANSI917(BYTE *V, BYTE *K, int N, int Tflag);
void Crypt917(BYTE *, BYTE *, BYTE *, UINT, UINT);
void GenDTVector(BYTE *dtvector, int genflag);
void UL_to_VOID (BYTE *buffer, ULONG longnum);
void VOID_to_UL (ULONG *longnum, BYTE *buffer);
//void setkey(int sw1, int sw2, BYTE *pkey); 
//void des(BYTE *in, BYTE *out);
//void pack8(BYTE *packed, BYTE *binary);
//void unpack8(BYTE *packed, BYTE *binary);
FILE *debug;
void ahtopb (char *ascii_hex, BYTE *p_binary, int bin_len);

#endif /*  _GENERATOR3_H_  */

#if defined(__cplusplus)
}
#endif