
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _UTILITIES1_H_
#define _UTILITIES1_H_

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
              U T I L I T Y  F U N C T I O N  P R O T O T Y P E S 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#define DISPLAY_IBM_DATA 0

void	displayBits(unsigned);
double	Pr(int, double);
void	induceBias(int);
void	ahtopb (char *ascii_hex, BYTE *p_binary, int bin_len);

#endif

#if defined(__cplusplus)
}
#endif