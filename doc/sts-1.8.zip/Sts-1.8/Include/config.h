/*
 * config.h
 */

#ifndef CONFIG_H
#define	CONFIG_H

/*
 *  EDIT THE FOLLOWING DEFINE BEFORE COMPILING
 *  TO SET THE COMPILATION ENVIRONMENT.
 *   Select:
 *			MSDOS - DOS, non-windows based app
 *       WINDOWS16 - 16-bit windows based app
 *       WINDOWS32 - 32-bit windows based app
 *       UNIX - UNIX app
 */
#define	WINDOWS32

/*
 * AUTO DEFINES (DON'T TOUCH!)
 */
#ifndef	BYTE
typedef unsigned char	BYTE;
#endif
#ifndef	UINT
typedef unsigned int		UINT;
#endif
#ifndef	USHORT
typedef unsigned short	USHORT;
#endif
#ifndef	ULONG
typedef unsigned long	ULONG;
#endif
#ifndef	DIGIT
typedef USHORT	DIGIT;	/* 16-bit word */
#endif
#ifndef	DBLWORD
typedef ULONG	DBLWORD;  /* 32-bit word */
#endif
#ifndef	WORD64
typedef ULONG	WORD64[2];  /* 32-bit word */
#endif

#ifndef CSTRTD
typedef char  *CSTRTD;
#endif
#ifndef BSTRTD
typedef unsigned char  *BSTRTD;
#endif
#ifndef UINT16
typedef unsigned short int UINT16;
#endif
#ifndef UINT32a
typedef unsigned long int UINT32a;
#endif

#define NULLPTR ((void *) 0)


#ifdef  WINDOWS16
#define	WINDOWS
#endif

#ifdef  WINDOWS32 
#define	PROTOTYPES
#define	_far
#define	WINDOWS
#endif

#ifdef  WINDOWS
#define	LITTLE_ENDIAN
#define	LOWHI
#endif

#ifdef  MSDOS
#ifndef WINDOWS
#define	PROTOTYPES
#define	LITTLE_ENDIAN
#define	LOWHI
#define	ECL
#define	PCDELAY		10000
#define	REGDEMO
#endif
#endif

#ifdef UNIX
#define	BIG_ENDIAN
#define	_far
#define	HILOW
#define	HILO
#define	TRYSOFIRST
#define	CHECKTIMEOUT
#define	REGDEMO
#endif

#endif
