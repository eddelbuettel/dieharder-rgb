/*****************************************************************************
 *  TDES.H - header file for calling DES API	                             *
 *  (Also used by library functions in DESAPI.C & TDES.C)				     *
 *---------------------------------------------------------------------------*
 *  December 1999                                                            *
 *---------------------------------------------------------------------------* 
 *  This software was developed at the National Institute of Standards and   *
 *  Technology by employees of the Federal Government in the course of their *
 *  official duties. Pursuant to title 17 Section 105 of the United States   *
 *  Code this software is not subject to copyright protection and is in the  *
 *  public domain.  We would appreciate acknowledgement if the software is   *
 *  used.																	 *
 *	This software was produced as part of research efforts and is for		 *
 *  demonstration purposes only. Our primary goals in its design did not	 *
 *  include widespread*
 *  use outside of our own laboratories.  Acceptance of this software implies*
 *  that you agree to use it for non-commercial purposes only and that you   *
 *  agree to accept it as nonproprietary and unlicensed,not supported by NIST*
 *  and not carrying any warranty, either expressed or implied, as to its    *
 *  performance or fitness for any particular purpose.                       *
 *---------------------------------------------------------------------------*
 *  Produced by the National Institute of Standards and Technology (NIST),   *
 *  Computer Systems Laboratory (CSL) Security Technology Group.             *
 ****************************************************************************/

/****************************************************/
/************ FILE ORIENTED FUNCTIONS ***************/
/****************************************************/
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef __TDES_H_
#define __TDES_H_

//#include "CAVSDefs.h"
#include "defs.h"

/*
 * TDESEncipherFile - Enciphers a file using DES
 * 
 * Parameters:
 *   plainfn	Pathname of plaintext file to be enciphered.
 *   cipherfn	Pathname of ciphertext file (to be created).
 *   key	Pointer to DES key to encipher file with.
 *   keylen	Length of DES key (w/parity bits) in bytes (8 or 16).
 *   iv		Pointer to DES IV (Initialization Vector) to encipher file.
 *   mode       DES Mode to use:  DES_ECB or DES_CBC
 *   flags	Flags to select file encoding options for ciphertext file.
 *                      TDES_FILE_BINARY No ASCII encoding done (UNIX fmt).
 *                      TDES_FILE_ASCII  Encode ciphertext in base64 (RFC1113).
 *                      TDES_FILE_WIPE   Wipe plaintext file after encrypting.
 *
 */
/*int EXPORT
TDESEncipherFile _PARAMS
((CSTRTD plainfn,CSTRTD cipherfn,BSTRTD key,int keylen,BSTRTD iv,int mode,int flags));
*/


/*
 * DESMACFile - Computes a DES MAC for a file
 * 
 * Parameters:
 *   plainfn	Pathname of plaintext file to be MAC'd.
 *   key	Pointer to DES key to encipher file with.
 *   keylen	Length of DES key (w/parity bits) in bytes (8 or 16).
 *   iv		Pointer to DES IV (Initialization Vector) to encipher file.
 *   mac	Pointer to an 8 byte array which receives the MAC.
 *
 */
/*int EXPORT
DESMACFile _PARAMS
((CSTRTD plainfn,BSTRTD key,int keylen,BSTRTD iv,BSTRTD mac));


/*
 * DESMACVerify - Verify a DES MAC for a file
 * 
 * Parameters:
 *   plainfn	Pathname of plaintext file to be MAC'd.
 *   key	Pointer to DES key to encipher file with.
 *   keylen	Length of DES key (w/parity bits) in bytes (8 or 16).
 *   iv		Pointer to DES IV (Initialization Vector) to encipher file.
 *   mac	Pointer to an 8 byte array containing MAC to verify.
 *
 * Returns TRUE (non-zero) if the MAC computed matches the one passed to
 * the function and FALSE (0) otherwise.
 */
/*int EXPORT
DESMACVerify _PARAMS
((CSTRTD plainfn,BSTRTD key,int keylen,BSTRTD iv,BSTRTD mac));
*/

/*
 * TDESDecipherFile -  Deciphers a file using DES in CBC mode
 *
 * Parameters:
 *   cipherfn	Pathname of ciphertext file to be deciphered.
 *   plainfn	Pathname of plaintext file (to be created).
 *   key	Pointer to DES key to decipher with.
 *   keylen	Length of DES key (w/parity bits) in bytes (8 or 16).
 *   iv		Pointer to DES IV (Initialization Vector) to encipher file.
 *   flags	Flags to select file decoding options for ciphertext file.
 *                      TDES_FILE_BINARY No ASCII encoding done (UNIX fmt).
 *                      TDES_FILE_ASCII  Decode as base64 (RFC1113).
 *			
 */
/*int EXPORT
TDESDecipherFile _PARAMS
((CSTRTD cipherfn,CSTRTD plainfn,BSTRTD key,int keylen,BSTRTD iv,int mode,int flags));
*/

/*
 * WipeFile -  Deletes and wipes (overwrites with pseudorandom data) a file.
 *
 * Parameters:
 *   fn		Pathname of file to be wiped.
 *   key	Pointer to DES key to use in creating pseudorandom data.
 *   keylen	Length of DES key (w/parity bits) in bytes (8 or 16).
 *			
 */
/*int EXPORT
WipeFile _PARAMS
((CSTRTD fn, BSTRTD key, int keylen));
*/

/* Options for encoding of ciphertext, etc */
/* Note, first 3 are mutually exclusive */
#define TDES_FILE_NONE           (1)
#define TDES_FILE_BINARY         (2)
#define TDES_FILE_ASCII          (4)
#define TDES_FILE_WIPE           (8)

/*** Error codes ***/
#define DES_ENCF_ERROPENPF	(-1)
#define DES_ENCF_ERROPENCF	(-2)
#define DES_ENCF_ERRORMODE	(-3)
#define DES_ENCF_ERRORSMFN	(-4)
#define DES_DECF_ERROPENPF	(-5)
#define DES_DECF_ERROPENCF	(-6)
#define DES_DECF_ERRORPADD	(-7)
#define DES_DECF_ERRORMODE	(-8)
#define DES_MACF_ERROPENPF	(-9)
#define DES_ERRUNSUPP		(-10) /* unsupported or unimplemented opt */

/*new error codes */
#define TDES_VARPT_ERR		(0x01)
#define TDES_INVPERM_ERR	(0x02)
#define TDES_VARKEY_ERR		(0x03)
#define TDES_PERMOP_ERR		(0x04)
#define TDES_SUBTAB_ERR		(0x05)
#define TDES_MONTE_ERR		(0x06)
#define TDES_MMT_ERR		(0x07)

#define TDES_INVALID_MODE	(0x10)
#define TDES_NOIV			(0x20)
#define TDES_OPENFILE_FAILED (0x30)


#define DES_VARPT_ECB_ERR	(-11)
#define DES_VARPT_CBC_ERR	(-12)
#define DES_VARPT_CBCI_ERR	(-13)
#define DES_VARPT_CFB1_ERR	(-14)
#define DES_VARPT_CFB8_ERR	(-15)
#define DES_VARPT_CFB64_ERR	(-16)
#define DES_VARPT_CFBP1_ERR	(-17)
#define DES_VARPT_CFBP8_ERR	(-18)
#define DES_VARPT_CFBP64_ERR (-19)
#define DES_VARPT_OFB_ERR	(-20)
#define DES_VARPT_OFBI_ERR	(-21)

#define DES_INVPERM_ECB_ERR	(-22)
#define DES_INVPERM_CBC_ERR	(-23)
#define DES_INVPERM_CBCI_ERR	(-24)
#define DES_INVPERM_CFB1_ERR	(-25)
#define DES_INVPERM_CFB8_ERR	(-26)
#define DES_INVPERM_CFB64_ERR	(-27)
#define DES_INVPERM_CFBP1_ERR	(-28)
#define DES_INVPERM_CFBP8_ERR	(-29)
#define DES_INVPERM_CFBP64_ERR (-30)
#define DES_INVPERM_OFB_ERR	(-31)
#define DES_INVPERM_OFBI_ERR	(-32)

#define DES_VARKEY_ECB_ERR	(-33)
#define DES_VARKEY_CBC_ERR	(-34)
#define DES_VARKEY_CBCI_ERR	(-35)
#define DES_VARKEY_CFB1_ERR	(-36)
#define DES_VARKEY_CFB8_ERR	(-37)
#define DES_VARKEY_CFB64_ERR	(-38)
#define DES_VARKEY_CFBP1_ERR	(-39)
#define DES_VARKEY_CFBP8_ERR	(-40)
#define DES_VARKEY_CFBP64_ERR (-41)
#define DES_VARKEY_OFB_ERR	(-42)
#define DES_VARKEY_OFBI_ERR	(-43)

#define DES_PERMOP_ECB_ERR	(-44)
#define DES_PERMOP_CBC_ERR	(-45)
#define DES_PERMOP_CBCI_ERR	(-46)
#define DES_PERMOP_CFB1_ERR	(-47)
#define DES_PERMOP_CFB8_ERR	(-48)
#define DES_PERMOP_CFB64_ERR	(-49)
#define DES_PERMOP_CFBP1_ERR	(-50)
#define DES_PERMOP_CFBP8_ERR	(-51)
#define DES_PERMOP_CFBP64_ERR (-52)
#define DES_PERMOP_OFB_ERR	(-53)
#define DES_PERMOP_OFBI_ERR	(-54)

#define DES_SUBTAB_ECB_ERR	(-55)
#define DES_SUBTAB_CBC_ERR	(-56)
#define DES_SUBTAB_CBCI_ERR	(-57)
#define DES_SUBTAB_CFB1_ERR	(-58)
#define DES_SUBTAB_CFB8_ERR	(-59)
#define DES_SUBTAB_CFB64_ERR	(-60)
#define DES_SUBTAB_CFBP1_ERR	(-61)
#define DES_SUBTAB_CFBP8_ERR	(-62)
#define DES_SUBTAB_CFBP64_ERR (-63)
#define DES_SUBTAB_OFB_ERR	(-64)
#define DES_SUBTAB_OFBI_ERR	(-65)

#define DES_MONTE_ECB_ERR	(-66)
#define DES_MONTE_CBC_ERR	(-67)
#define DES_MONTE_CBCI_ERR	(-68)
#define DES_MONTE_CFB1_ERR	(-69)
#define DES_MONTE_CFB8_ERR	(-70)
#define DES_MONTE_CFB64_ERR	(-71)
#define DES_MONTE_CFBP1_ERR	(-72)
#define DES_MONTE_CFBP8_ERR	(-73)
#define DES_MONTE_CFBP64_ERR (-74)
#define DES_MONTE_OFB_ERR	(-75)
#define DES_MONTE_OFBI_ERR	(-76)


/******************************************************/
/************ BLOCK ORIENTED FUNCTIONS ****************/
/******************************************************/

/* DES CONTEXT */
typedef struct {
  int Mode;                     /* TDES Mode */
  int crypt;					/* Either DES_ENCIPHER or DES_DECIPHER */
  int kbit;                     /* K-Bits for TCFB and OFB Modes */
  int leafnum;					/* Which interleave number */
  unsigned char IV1[8];         /* Packed IV1 */
  unsigned char IV2[8];         /* Packed IV2 */
  unsigned char IV3[8];         /* Packed IV3 */
#ifdef OLDDES
  unsigned char KS1[16][48];    /* Unpacked DES Key Schedule (key1) */
  unsigned char KS2[16][48];    /* Unpacked DES Key Schedule (key2) */
  unsigned char KS3[16][48];    /* Unpacked DES Key Schedule (key3) */
#else
  unsigned KS1[16][4];			/* DES Key Schedule (key 1) */
  unsigned KS2[16][4];			/* DES Key Schedule (key 2) */
  unsigned KS3[16][4];			/* DES Key Schedule (key 3) */
#endif
} TDESCTX;

typedef TDESCTX  *P_TDESCTX;

void TDES_Core(P_TDESCTX context, BYTE *input, BYTE *output);
int	TDESInit (P_TDESCTX context, BSTRTD key1, BSTRTD key2, BSTRTD key3, BSTRTD iv, int mode, int crypt);
void TDES(P_TDESCTX context, BYTE *input, BYTE *output, FILE *stream);
int TDES_Test();
void printvalue(P_TDESCTX context, BYTE *input, FILE *stream);
void shift_concat(int kbits,	BYTE *iv, int len, BYTE *result);


/* TDES Key Options */
#define TDES_ONEKEY      3 //3 independent keys
#define TDES_TWOKEY      2
#define TDES_THREEKEY    1 // k1=k2=k3

/* Masks for extracting info from the modes below */
#define	TDES_ENCEQDEC_MASK		(0x20)
#define	TDES_INTERLEAVED_MASK	(0x10)
#define	TDES_KBITS_MASK			(0x0C)
#define	TDES_MODE_MASK			(0x03)

/*  Defines the basic mode  */
#define TDES_MODE_ECB			(0x00)
#define TDES_MODE_CBC			(0x01)
#define TDES_MODE_CFB			(0x02)
#define TDES_MODE_OFB			(0x03)

/*  Define the number of bits for CFB and CFBP modes */
#define TDES_KBITS_1			(0x04)
#define TDES_KBITS_8			(0x08)
#define TDES_KBITS_64			(0x0C)

/* TDES Modes */
#define TDES_ECB		(0x00)
#define TDES_CBC		(0x01)
#define TDES_CBCI		(0x11)
#define TDES_CFB		(0x22)
#define TDES_CFB_64		(0x2E)
#define TDES_CFB_8		(0x2A)
#define TDES_CFB_1		(0x26)
#define TDES_OFB		(0x23)
#define TDES_OFBI		(0x33)
#define TDES_CFBP_64	(0x3E)
#define TDES_CFBP_8		(0x3A)
#define TDES_CFBP_1		(0x36)
#define TDES_CFBP		(0x32)

// Misc
#define DES_ENCIPHER	0
#define DES_DECIPHER	1
#define DES_BOTH		2
#define CHECKPARITY     1
#define IGNOREPARITY    0

/* Error codes */
#define DES_UPD_ERRBL	1

#define MSBIT           (0x80)
#define LSBIT			(0x01)

#endif  /* __TDES_H_ */

#if defined(__cplusplus)
}
#endif
