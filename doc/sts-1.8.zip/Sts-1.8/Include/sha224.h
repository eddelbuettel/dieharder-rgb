
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _SHA224_H_
#define _SHA224_H_

#include "shadefs.h"

#define	SHA224_BLOCKLEN			512
#define	SHA224_BYTEBLOCKLEN		(SHA224_BLOCKLEN/8)
#define	SHA224_DIGITBLOCKLEN	(SHA224_BYTEBLOCKLEN/sizeof(DIGIT))
#define SHA224_ULONGBLOCKLEN	(SHA224_BYTEBLOCKLEN/sizeof(ULONG))
#define SHA224_HASHLEN			224
#define SHA224_BYTEHASHLEN		(SHA224_HASHLEN/8)
#define	SHA224_DIGITHASHLEN		(SHA224_BYTEHASHLEN/sizeof(DIGIT))
#define	SHA224_ULONGHASHLEN		(SHA224_BYTEHASHLEN/sizeof(ULONG))

#endif  /*  _SHA224_H_  */

#if defined(__cplusplus)
}
#endif