
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _MP_H_
#define _MP_H_

#include "config.h"

#define	MAXDIGIT		0xFFFF
#define	MSBITNDIGIT		0x8000
#define	LSBITNDIGIT		0x0001
#define	MSBITNULONG		0x80000000
#define	LSBITNULONG		0x00000001

#define HEXTODECSTRLEN	2000

typedef struct _MP_struct {
	int		size;	/*  in bytes  */
	int		bitlen;	/*  in bits, duh  */
	BYTE	*val;
	} MP;

#define	FREE(A)	if ( (A) ) { free((A)); (A) = NULL; }
#define	ASCII2BIN(ch)	( (((ch) >= '0') && ((ch) <= '9')) ? ((ch) - '0') : (((ch) >= 'A') && ((ch) <= 'F')) ? ((ch) - 'A' + 10) : ((ch) - 'a' + 10) )


#define NUMLEN		(sizeof(DIGIT)*8)
#define	EXPWD		((DBLWORD)1<<NUMLEN)
#define	sniff_bit(ptr,mask)		(*(ptr) & mask)
#define	TRUE		1
#define	FALSE		0

/*
 * Function Declarations
 */
#ifdef PROTOTYPES

void	bzero(BYTE *x, int l);
void	bcopy(BYTE *x, BYTE *y, int l);
int		eqzero(BYTE *x, int l);
int		equal(BYTE *x, BYTE *y, int l);
int		greater(BYTE *x, BYTE *y, int l);
int		less(BYTE *x, BYTE *y, int l);
BYTE	bshl(BYTE *x, int l);
void	bshr(BYTE *x, int l);
void	Random(BYTE *A, BYTE *T, int L);
void	RandomOdd(BYTE *A, BYTE *T, int L);
int		Mult(BYTE *A, BYTE *B, int LB, BYTE *C, int LC);
void	ModSqr(BYTE *A, BYTE *B, int LB, BYTE *M, int LM);
void	ModMult(BYTE *A, BYTE *B, int LB, BYTE *C, int LC, BYTE *M, int LM);
void	smult(BYTE *A, BYTE b, BYTE *C, int L);
void	Square(BYTE *A, BYTE *B, int L);
void	ModExp(BYTE *A, BYTE *B, int LB, BYTE *C, int LC, BYTE *M, int LM);
int		DivMod(BYTE *x, int lenx, BYTE *n, int lenn, BYTE *quot, BYTE *rem);
void	Mod(BYTE *x, int lenx, BYTE *n, int lenn);
void	Div(BYTE *x, int lenx, BYTE *n, int lenn);
int		InvPrimeField(BYTE *Kinv, BYTE *K, int lenk, BYTE *Q, int lenq);
int		InvExtEuclid(BYTE *D, BYTE *Ain, BYTE *Bin, int len);
int		ExtEuclidAlg(BYTE *Ain, BYTE *Bin, BYTE *Dout, BYTE *Xout, BYTE *Yout, int len);
void	sub(BYTE *A, int LA, BYTE *B, int LB);
int		negate(BYTE *A, int L);
BYTE	add(BYTE *A, int LA, BYTE *B, int LB);
int		IsPrime(BYTE *W, int L, int iter);
void	GenPrime(int datetime, BYTE *Q, int len);
void	CRT(BYTE *res, BYTE *c, BYTE *p, BYTE *q, BYTE *u, BYTE *d,
			BYTE *dpm1, BYTE *dqm1, int lenn);
void	xor(BYTE *A, BYTE *x, BYTE *y, int l);
void	printBstr(char *S, BYTE *A, int L);
void	fprintBstr(FILE *fp, char *S, BYTE *A, int L);
void	sprintBstr(char *S, BYTE *A, int L);
void	printInt(char *S, BYTE *A, int L);
void	fprintInt(FILE *fp, char *S, BYTE *A, int L);
void	freadnum(FILE *fp, BYTE *A, int L);
void	bshrULONG(ULONG *x, int len);
void	ROT_WORD64(WORD64 retval, WORD64 X, int Y);
void	add_WORD64(WORD64 X, WORD64 Y);
void	byteReverse64(WORD64 *buffer, int len);
void	byteReverse(ULONG *buffer, int byteCount);
void	ROTL_ULONGS(ULONG *buffer, int wordcount);
int		getbitsize(BYTE *val, int bitlen);
void	initMP(MP *mp);
void	allocMP(MP *mp, int bitlen);
void	freeMP(MP *mp);
void	GenRand(BYTE *val, int len);
char	*time_str();
void	c2LH(BYTE *n, int l);
void	cLONG2DIGITS(DIGIT *n);
void	cDIGITS2LONG(DIGIT *n);
int		FindMarker(FILE *infile, char *marker);
int		ReadHex(FILE *infile, BYTE *A, int Length, char *str);
int		ReadInt(FILE *infile, BYTE *A, int Length, char *str);
int		Jacobi(BYTE *aorig, int lenA, BYTE *norig, int lenN);
int		LucasPrime(BYTE *N, int lenN);
void	ProcessUVagain(MP U, MP V, MP D, BYTE *N, int lenN);
void	calv1(MP newV, MP U, MP V, MP D, BYTE *N, int lenN);

#else

void	bzero();
void	bcopy();
int		eqzero();
int		equal();
int		greater();
int		less();
DIGIT	bshl();
void	bshr();
int		Random();
int		RandomOdd();
int		Mult();
void	ModSqr();
void	ModMult();
void	smult();
int		Square();
int		ModExp();
void	DivMod();
void	Mod();
int		Inv();
void	Div();
void	sub();
int		negate();
DIGIT	add();
int		IsPrime();
void	GenPrime();
void	CRT();
int		Inv2();
void	xor();
void	printnum();
void	fprintnum();
void	freadnum();
void	bshrULONG();
void	ROT_WORD64();
void	add_WORD64();
void	byteReverse64();
void	byteReverse();
void	ROTL_ULONGS();
int		getbitsize();
void	allocMP();
void	GenRand();
char	*time_str();
void	c2LH();
void	cLONG2DIGITS();
void	cDIGITS2LONG();
int		FindMarker();
int		ReadHex();
int		ReadInt();

#endif

#endif  /* _MP_H_ */

#if defined(__cplusplus)
}
#endif