
#if defined(__cplusplus)
extern "C" {
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                       D E B U G G I N G  A I D E S
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef _DEFS_H_
#define _DEFS_H_

#include "config.h"

#define FREQUENCY       			1
#define BLOCK_FREQUENCY 			1
#define CUSUM 						1
#define RUNS						1
#define LONG_RUNS					1
#define RANK						1
#define MATRICES					0
#define DFT							1
#define APERIODIC_TEMPLATES			1
#define PERIODIC_TEMPLATES			1
#define UNIVERSAL					1
#define APEN						1
#define SERIAL						1
#define RANDOM_EXCURSIONS			1
#define RANDOM_EXCURSIONS_VARIANT	1
#define LINEAR_COMPLEXITY			1
#define DISPLAY_OUTPUT_CHANNELS		0
#define PARTITION					0


/*  Test identifiers  */
#define TESTS_ALL				 0
#define TESTS_FREQUENCY          1
#define TESTS_BLOCK_FREQUENCY    2
#define TESTS_CUM_SUMS           3 
#define TESTS_RUNS               4
#define TESTS_LONGEST_RUNS       5
#define TESTS_RANK				 6
#define TESTS_DFFT               7
#define TESTS_NONPERIODIC_TEMPL  8
#define TESTS_OVERLAPPING_TEMPL  9
#define TESTS_UNIVERSAL         10
#define TESTS_APEN              11
#define TESTS_RANDOM_EXCURSIONS 12
#define TESTS_RANDOM_EXCUR_VAR  13
#define TESTS_SERIAL			14
#define TESTS_LINEAR_COMPLEXITY	15
#define TESTS_IMPOSSIBLE_ERROR  20

/*  Generator identifiers  */
#define GEN_FILE		0
#define GEN_SHA1		1
#define GEN_SHA224		2
#define GEN_SHA256		3
#define GEN_SHA384		4
#define GEN_SHA512		5
#define GEN_LCG			6
#define GEN_BBS			7
#define GEN_MS			8
#define GEN_QCG1		9
#define GEN_QCG2		10
#define GEN_CCG			11
#define GEN_XOR			12
#define GEN_ANSI		13
#define GEN_DES			14
#define GEN_MODEXP		15
#define GEN_ERROR		20

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
        S T A T I S T I C A L  T E S T I N G  A L T E R N A T I V E S
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

//#define INCLUDE_GENERATORS					1
#define LONG_RUNS_CASE_8					0
#define LONG_RUNS_CASE_128					0
#define LONG_RUNS_CASE_10000				1
#define SAVE_FFT_PARAMETERS					0
#define SAVE_APEN_PARAMETERS				0
#define SAVE_RANDOM_EXCURSION_PARAMETERS	0
#define SEQ_LENGTH_STEP_INCREMENTS			5000

#define STS_GUI				1
#undef GEN_TIMING_INFO

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                              M A C R O S
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#define MAX(x,y)             ((x) <  (y)  ? (y)  : (x))
#define MIN(x,y)             ((x) >  (y)  ? (y)  : (x))
#define isNonPositive(x)     ((x) <= 0.e0 ?   1  : 0)
#define isPositive(x)        ((x) >  0.e0 ?   1 : 0)
#define isNegative(x)        ((x) <  0.e0 ?   1 : 0)
#define isGreaterThanOne(x)  ((x) >  1.e0 ?   1 : 0)
#define isZero(x)            ((x) == 0.e0 ?   1 : 0)
#define isOne(x)             ((x) == 1.e0 ?   1 : 0)

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
                         G L O B A L  C O N S T A N T S
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#define MAX_ITERATIONS    5000    		/* INFINITE SERIES MAX ITER. */
#define ALPHA             0.01	  		/* SIGNIFICANCE LEVEL */
#define ITMAX	          2000000 		/* MAX ITERS INC. GAMMA FCN */
#define KAPPA	          3e-15   		/* CONVERGENCE CRITERIA */
#define MAXNUMOFTEMPLATES 148      		/* APERIODIC TEMPLATES */
#define NUMAPERIODICFILES 10			/* Num pval files for aperiodic */
#define NUMOFTESTS        15      		/* MAX TESTS DEFINED  */
#define NUMOFGENERATORS   16      		/* MAX PRNGs */
#define MAXFILESPERMITTEDFORPARTITION 400

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                   G L O B A L   D A T A  S T R U C T U R E S
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
struct bit {   
   unsigned b:1;
};				/ BIT FIELD STRUCTURE      /
*/

struct bit {   
	unsigned char	b:1;
};				/* BIT FIELD STRUCTURE      */

struct complex2 {
	double	a;			/* REAL PART OF COMPLEX #   */
	double	b;			/* IMAG PART OF COMPLEX #   */
};

struct testParameters {
	int		n;
	int		blockFrequencyBlockLength; 
	int		nonOverlappingTemplateBlockLength;
	int		overlappingTemplateBlockLength; 
	int		serialBlockLength;
	int		linearComplexitySequenceLength;
	int		approximateEntropyBlockLength; 
	int		universalBlockLength;
	int		universalNumberInitializationSteps;
	int		numOfBitStreams;
	int		datamode;
	int		generator;
	double	minimumP;
	double	lnSum;
	int		df;
};

typedef struct bit				BitField;
typedef struct complex2			Complex;
typedef struct testParameters	TP;

#endif /*  _DEFS_H_  */


#if defined(__cplusplus)
}
#endif