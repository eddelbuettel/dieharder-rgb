
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _GENERATOR2_H_
#define _GENERATOR2_H_

#define MAXPLEN     128     /* Maximum modulus size in bytes */
#define DSA_Q_SIZE  20
 
#endif  /*  _GENERATOR2_H_  */

#if defined(__cplusplus)
}
#endif