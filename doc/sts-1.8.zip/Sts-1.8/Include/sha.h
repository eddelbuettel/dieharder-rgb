
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _SHA_H_
#define _SHA_H_

#include "shadefs.h"
#include "shaexterns.h"
#include "sha1.h"
#include "sha256.h"
#include "sha384.h"
#include "sha512.h"

#define	MAXBYTEHASHLEN	64

typedef struct _HASH {
	int		hashlen;
	union _ContextUnion {
		SHA1_CTX	ctx1;
		SHA256_CTX	ctx256;
		SHA384_CTX	ctx384;
		SHA512_CTX	ctx512;
		} u_ctx;
	} HASH;

#ifdef PROTOTYPES

void	Hash(BYTE *msg, int len, HASH *ctx, BYTE **hashval);
int		SHA_Test();

#else

void	Hash();
int		SHA_Test();

#endif

#endif /*_SHA_H_*/

#if defined(__cplusplus)
}
#endif