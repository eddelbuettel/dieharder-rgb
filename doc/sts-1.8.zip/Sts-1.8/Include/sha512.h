
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _SHA512_H_
#define _SHA512_H_

#include "shadefs.h"

#define	SHA512_BLOCKLEN			1024
#define	SHA512_BYTEBLOCKLEN		(SHA512_BLOCKLEN/8)
#define SHA512_WORD64BLOCKLEN	(SHA512_BYTEBLOCKLEN/sizeof(WORD64))
#define SHA512_HASHLEN			512
#define SHA512_BYTEHASHLEN		(SHA512_HASHLEN/8)
#define SHA512_ULONGHASHLEN		(SHA512_BYTEHASHLEN/4)
#define	SHA512_WORD64HASHLEN	(SHA512_BYTEHASHLEN/sizeof(WORD64))

typedef struct {
	int		Numbits;
	WORD64	MsgLen[2];
	WORD64	Mblock[SHA512_WORD64BLOCKLEN];
	WORD64	H[SHA512_WORD64HASHLEN];
} SHA512_CTX;

#ifdef PROTOTYPES

void	SHA512_ProcessBlock(SHA512_CTX *ctx);
int		SHA512_Init(SHA512_CTX *ctx);
int		SHA512_Init2(SHA512_CTX *ctx, WORD64 *IH);
int		SHA512_Update(SHA512_CTX *ctx, BYTE *buffer, int bitcount);
int		SHA512_Final(SHA512_CTX *ctx);

#else

void	SHA512_ProcessBlock();
int		SHA512_Init();
int		SHA512_Init2();
int		SHA512_Update();
int		SHA512_Final();

#endif /* PROTOTYPES */

#endif  /*  _SHA512_H_  */

#if defined(__cplusplus)
}
#endif