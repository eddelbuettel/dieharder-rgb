
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _GENERATORS1_H_
#define _GENERATORS1_H_


/*  LIP.H things, but we can't just include LIP.H  */
typedef long * verylong;
void zfree(verylong *x);
void zlowbits(verylong a, long b, verylong *c);
long ztoint(verylong a);
void zrshift(verylong n, long k, verylong *a);
void zcopy(verylong a, verylong *b);

double	lcg_rand(int, double, double*, int);
void	bbs_gen_key(long bit_length, verylong *zn, verylong *zx0);
long	bbs_next_bits(long number, verylong zn, verylong *zx);
void	Micali_Schnorr_gen_key(long bit_length, verylong *ze, verylong *zn,
							   verylong *zx0, long *k, long *r);
void	Micali_Schnorr_next_bits(long k, long r, verylong ze, verylong zn,
								 verylong *zx, verylong *zz);

#endif   /*  _GENERATORS1_H_  */

#if defined(__cplusplus)
}
#endif