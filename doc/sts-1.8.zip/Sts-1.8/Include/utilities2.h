
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _UTILITIES2_H_
#define _UTILITIES2_H_

void displayTests();
void chooseTests();
void fixParameters();
int  generatorOptions(char**);
void openOutputStreams(int);
int  displayGeneratorOptions();
void invokeTestSuite(int, char*);
int convertToBits(BYTE *x, int numBits, int tp_n, int *n0, int *n1, int *bitsRead);

#endif

#if defined(__cplusplus)
}
#endif