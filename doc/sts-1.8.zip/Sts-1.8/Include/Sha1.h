/*****************************************************************************
*  sha.h                                                      VERSION 3.1    *
*----------------------------------------------------------------------------*
*  S E C U R E   H A S H   S T A N D A R D  (SHA)                            *
*  FEDERAL INFORMATION PROCESSING STANDARDS PUBLICATION 180                  *
*  APRIL 1993                                                                *
*----------------------------------------------------------------------------*
*  This software was produced at the National Institute of Standards and     *
*  Technology (NIST) as part of research efforts and is for demonstration    *
*  purposes only.  Our primary goals in its design did not include widespread*
*  use outside of our own laboratories.  Acceptance of this software implies *
*  that you agree to use it for non-commercial purposes only and that you    *
*  agree to accept it as nonproprietary and unlicensed, not supported by NIST*
*  and not carrying any warranty, either expressed or implied, as to its     *
*  performance or fitness for any particular purpose.                        *
*----------------------------------------------------------------------------*
*  Produced by the National Institute of Standards and Technology (NIST),    *
*  Computer Systems Laboratory (CSL) Security Technology Group.              *
*****************************************************************************/


#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _SHA1_H_
#define _SHA1_H_

#include "shadefs.h"

#define	SHA1_BLOCKLEN		512
#define	SHA1_BYTEBLOCKLEN	(SHA1_BLOCKLEN/8)
#define SHA1_ULONGBLOCKLEN	(SHA1_BYTEBLOCKLEN/4)
#define	SHA1_HASHLEN		160
#define SHA1_BYTEHASHLEN	(SHA1_HASHLEN/8)
#define SHA1_ULONGHASHLEN	(SHA1_BYTEHASHLEN/4)

typedef struct {
	ULONG Numbits;
	ULONG Numblocks[2];
	ULONG Mblock[SHA1_ULONGBLOCKLEN];
	ULONG H[SHA1_ULONGHASHLEN];
	} SHA1_CTX;

/*****************
 * SHA functions *
 *****************/
#ifdef PROTOTYPES

int		SHA1_Init(SHA1_CTX *);
int		SHA1_Init2(SHA1_CTX *, ULONG *);
int		SHA1_Update(SHA1_CTX *, BYTE *buffer, int);
int		SHA1_Final(SHA1_CTX *);
void	ProcessBlock(SHA1_CTX *);

#else

int		SHA1_Init();
int		SHA1_Init2();
int		SHA1_Update();
int		SHA1_Final();
void	ProcessBlock();

#endif

#endif /*_SHA_H_*/

#if defined(__cplusplus)
}
#endif