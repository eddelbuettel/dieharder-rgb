
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _STS_H_
#define _STS_H_

#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"
#include "mconf.h"  

void postProcessResults(int);
void partitionResultFile(int, int, int, int);
int computeMetrics(char*,int);

#endif


#if defined(__cplusplus)
}
#endif