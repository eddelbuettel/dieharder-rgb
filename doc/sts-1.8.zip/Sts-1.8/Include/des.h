/*
 * des.h
 *
 * Header file for software DES code
 *
 * Indovina 1/91  Rev 1.0
 */

#ifndef DES_H
#define DES_H

#include "../include/config.h"
typedef unsigned int    INT;

#define TRUE            1
#define FALSE           0
#define CHECKPARITY     1
#define IGNOREPARITY    0
#define ENCRYPT         0
#define DECRYPT         1
#define MSBIT           0x80

/* added new stuff */
void unpack8(BYTE*, BYTE*);
void pack8(BYTE*, BYTE*);

#endif


