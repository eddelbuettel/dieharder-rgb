
#if defined(__cplusplus)
extern "C" {
#endif

#include "shadefs.h"
#include "sha1.h"
#include "sha256.h"
#include "sha384.h"
#include "sha512.h"

extern ULONG	SHA1_IH[SHA1_ULONGHASHLEN];

extern ULONG	SHA224_IH[SHA256_ULONGHASHLEN];

extern ULONG	SHA256_IH[SHA256_ULONGHASHLEN];

extern WORD64	SHA384_IH[SHA384_WORD64IVLEN];

extern WORD64	SHA512_IH[SHA512_WORD64HASHLEN];

#if defined(__cplusplus)
}
#endif