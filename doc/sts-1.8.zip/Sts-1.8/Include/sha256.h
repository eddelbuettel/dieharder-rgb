
#if defined(__cplusplus)
extern "C" {
#endif

#ifndef _SHA256_H_
#define _SHA256_H_

#include "shadefs.h"

#define	SHA256_BLOCKLEN			512
#define	SHA256_BYTEBLOCKLEN		(SHA256_BLOCKLEN/8)
#define	SHA256_DIGITBLOCKLEN	(SHA256_BYTEBLOCKLEN/sizeof(DIGIT))
#define SHA256_ULONGBLOCKLEN	(SHA256_BYTEBLOCKLEN/sizeof(ULONG))
#define SHA256_HASHLEN			256
#define SHA256_BYTEHASHLEN		(SHA256_HASHLEN/8)
#define	SHA256_DIGITHASHLEN		(SHA256_BYTEHASHLEN/sizeof(DIGIT))
#define	SHA256_ULONGHASHLEN		(SHA256_BYTEHASHLEN/sizeof(ULONG))

typedef struct {
	ULONG	Numbits;
	ULONG	MsgLen[2];
	ULONG	Mblock[SHA256_ULONGBLOCKLEN];
	ULONG	H[SHA256_ULONGHASHLEN];
	} SHA256_CTX;

#define	ROT(X,Y)		((X>>Y) | (X<<(32-Y)))

#define	Ch(X, Y, Z)		((X & Y) ^ (~X & Z))
#define Maj(X, Y, Z)	((X & Y) ^ (X & Z) ^ (Y & Z))

#define	CapSigma0(X)	(ROT(X,2) ^ ROT(X,13) ^ ROT(X,22))
#define CapSigma1(X)	(ROT(X,6) ^ ROT(X,11) ^ ROT(X,25))
#define SmallSigma0(X)	(ROT(X,7) ^ ROT(X,18) ^ (X>>3))
#define SmallSigma1(X)	(ROT(X,17) ^ ROT(X,19) ^ (X>>10))

void	SHA256_ProcessBlock(SHA256_CTX *ctx);
int		SHA256_Init(SHA256_CTX *ctx);
int		SHA256_Init2(SHA256_CTX *ctx, ULONG *IH);
int		SHA256_Update(SHA256_CTX *ctx, unsigned char *buffer, int bitcount);
int		SHA256_Final(SHA256_CTX *ctx);

#endif  /*  _SHA256_H_  */

#if defined(__cplusplus)
}
#endif