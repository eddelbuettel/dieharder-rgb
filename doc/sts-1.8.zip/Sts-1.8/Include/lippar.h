#define KARAT	1
#define KAR_MUL_CROV	30
#define KAR_SQU_CROV	33
