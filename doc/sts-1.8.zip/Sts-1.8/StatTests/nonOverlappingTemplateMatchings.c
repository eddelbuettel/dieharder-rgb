#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "utilities1.h"
#include "special-functions.h"
#include "mconf.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
          N O N O V E R L A P P I N G  T E M P L A T E  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void NonOverlappingTemplateMatchings(int m, int n)
{
	int numOfTemplates[22] = {    0,      0,      2,      4,     6,     12,    20,
								 40,     74,    148,     284,  568,   1116,  2232,
							   4424,   8848,  17622,   35244,70340, 140680, 281076, 562152};
	/*----------------------------------------------------------------------------*
	 *NOTE:  Should additional templates lengths beyond 21 be desired, they must  *
	 *first be constructed, saved into files and then the corresponding           *
	 *number of nonperiodic templates for that file be stored in the m-th         *
	 *position in the numOfTemplates variable.                                    *
	 *----------------------------------------------------------------------------*/
	int            SKIP;
	unsigned       bit; 
	FILE*          fp;
	unsigned int   W_obs;
	double         sum, chi2, p_value, lambda;
	int            i, j, jj, k, match, state, ind;
	char           assignment[15], directory[100];
	int            M, N, K = 5;
	unsigned int   nu[6], *Wj;
	double         pi[6], varWj /*, U[6] = {1,2,3,4,5,6}*/;
	extern double lgam ( double x );
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp1;
	fp1 = fopen("NonOverlap.txt", "a");

	start = clock();
#endif
	
	N = 8;
	M = (int)floor(n/N);

	Wj = (unsigned int*)calloc(N,sizeof(unsigned int));
	lambda = (M-m+1)/pow(2,m);
	varWj = M*(1./pow(2.,m) - (2.*m-1.)/pow(2.,2.*m));
	sprintf(directory, "templates/template%d",m);
	/*printf("%s\n", directory);*/

	if ( ((isNegative(lambda)) || (isZero(lambda))) ||
		 ((fp = fopen(directory, "r")) == NULL) ||
		 ((templates = (BitField*) calloc(m,sizeof(BitField))) == NULL)) {
		fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\tNONOVERLAPPING TEMPLATES TESTS ABORTED DUE ");
		fprintf(stats[TESTS_NONPERIODIC_TEMPL], "TO ONE OF THE FOLLOWING : \n");
		fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\tLambda (%f) not being positive!\n", lambda);
		fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\tTemplate file %s not existing\n", directory);
		fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\tInsufficient memory for required work space.\n");
		if ( templates )
			free(templates);
		state = 0;
		exit(-1);
	}
	else {
		if ( APERIODIC_TEMPLATES ) {
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\t\t  NONPERIODIC TEMPLATES TEST\n");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "---------------------------------------------");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "-----------------------------------\n");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\t\t  COMPUTATIONAL INFORMATION\n");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "---------------------------------------------");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "-----------------------------------\n");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\tLAMBDA = %f\tM = %d\tN = %d\tm = %d\tn = %d\n", lambda,M,N,m,n);
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "---------------------------------------------");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "-----------------------------------\n");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\t\tF R E Q U E N C Y\n");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "Template   W_1  W_2  W_3  W_4  W_5  W_6  W_7  W_8");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "    Chi^2   P_value Assignment Index\n");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "---------------------------------------------");
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "-----------------------------------\n");
		}
		if ( numOfTemplates[m] < MAXNUMOFTEMPLATES )
			SKIP = 1;
		else
			SKIP = (int)(numOfTemplates[m]/MAXNUMOFTEMPLATES);
		numOfTemplates[m] = (int)numOfTemplates[m]/SKIP;

		sum = 0.0;
		for( i=0; i<2; i++ ) {			/* Compute Probabilities */
			pi[i] = exp(-lambda+i*log(lambda)-lgam(i+1));
			sum += pi[i];
		}
		pi[0] = sum;
		for( i=2; i<=K; i++ ) {			/* Compute Probabilities */
			pi[i-1] = exp(-lambda+i*log(lambda)-lgam(i+1));
			sum += pi[i-1];
		}
		pi[K] = 1 - sum;

		for( jj=0; jj<MIN(MAXNUMOFTEMPLATES,numOfTemplates[m]); jj++ ) {
			sum = 0;

			for(k = 0; k < m; k++) {
				fscanf(fp, "%d", &bit);
				templates[k].b = bit;
				fprintf(stats[TESTS_NONPERIODIC_TEMPL],"%d", templates[k].b);
			}
			fprintf(stats[TESTS_NONPERIODIC_TEMPL]," ");
			for( k=0; k<=K; k++ )
				nu[k] = 0;
			for( i=0; i<N; i++ ) {
				W_obs = 0;
				for( j=0; j<M-m+1; j++ ) {
					match = 1;
					for( k=0; k<m; k++ ) {
						if ( (int)templates[k].b != (int)epsilon[i*M+j+k].b ) {
							match = 0;
							break;
						}
					}
					if ( match == 1 )
						W_obs++;
				}
				Wj[i] = W_obs;
			}
			sum = 0;
			chi2 = 0.0;                                   /* Compute Chi Square */
			for( i=0; i<N; i++ ) {
				if ( m == 10 )
					fprintf(stats[TESTS_NONPERIODIC_TEMPL], "%3d  ", Wj[i]);
				else
					fprintf(stats[TESTS_NONPERIODIC_TEMPL], "%4d ", Wj[i]);
				chi2 += pow(((double)Wj[i] - lambda)/pow(varWj,0.5),2);
			}
			p_value = igamc(N/2.0,chi2/2.0);
			/*p_value = gammq(N/2.0,chi2/2.0);*/

			if ( isNegative(p_value) || isGreaterThanOne(p_value) )
				fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\t\tWARNING:  P_VALUE IS OUT OF RANGE.\n");

			if ( p_value < ALPHA ) {
				strcpy(assignment,"FAILURE");
				state = 0;
			}
			else {
				strcpy(assignment,"SUCCESS");
				state = 1;
			}
			fprintf(stats[TESTS_NONPERIODIC_TEMPL], "%9.6f %f %s %3d\n", chi2, p_value, assignment, jj);
			fseek(fp, (long)(SKIP-1)*2*m, SEEK_CUR);
			fprintf(results[TESTS_NONPERIODIC_TEMPL], "%f\n", p_value);
			fprintf(grid, "%d", state); fflush(grid);
			ind = jj / ((numOfTemplates[m]+NUMAPERIODICFILES-1)/NUMAPERIODICFILES);
			fprintf(pvalsAperiodic[ind], "%f ", p_value); fflush(pvalsAperiodic[ind]);

			if ( p_value < tp.minimumP )
				tp.minimumP = p_value;
			if ( !_isnan(p_value) )
				tp.lnSum += log(p_value);
			tp.df++;
		}
		fprintf(stats[TESTS_NONPERIODIC_TEMPL], "\n");
		for ( ind=0; ind<NUMAPERIODICFILES; ind++ )
			fprintf(pvalsAperiodic[ind], "\n");
		free(templates);
	}
	fflush(stats[TESTS_NONPERIODIC_TEMPL]);
	fflush(results[TESTS_NONPERIODIC_TEMPL]);
	fflush(grid);
	free(Wj);
	fclose(fp);

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp1, "%d\n", finish - start);
	fclose(fp1);
#endif

	return;
}
