/* --------------------------------------------------------------------------
   Title       :  The NIST Statistical Test Suite

   Date        :  December 1999

   Programmer  :  Juan Soto

   Summary     :  For use in the evaluation of the randomness of bitstreams
		  produced by cryptographic random number generators.

   Package     :  Version 1.0

   Copyright   :  (c) 1999 by the National Institute Of Standards & Technology

   History     :  Version 1.0 by J. Soto, October 1999
		  Revised by J. Soto, November 1999

   Keywords    :  Pseudorandom Number Generator (PRNG), Randomness, Statistical 
                  Tests, Complementary Error functions, Incomplete Gamma 
	          Function, Random Walks, Rank, Fast Fourier Transform, 
                  Template, Cryptographically Secure PRNG (CSPRNG),
		  Approximate Entropy (ApEn), Secure Hash Algorithm (SHA-1), 
                  Blum-Blum-Shub (BBS) CSPRNG, Micali-Schnorr (MS) CSPRNG, 

   Source      :  David Banks, Elaine Barker, James Dray, Allen Heckert, 
		  Stefan Leigh, Mark Levenson, James Nechvatal, Andrew Rukhin, 
		  Miles Smid, Juan Soto, Mark Vangel, and San Vo.

   Technical
   Assistance  :  Lawrence Bassham, Ron Boisvert, James Filliben, Sharon Keller,
		  Daniel Lozier, and Bert Rust.

   Warning     :  Portability Issues.

   Limitation  :  Amount of memory allocated for workspace.

   Restrictions:  Permission to use, copy, and modify this software without 
		  fee is hereby granted, provided that this entire notice is 
		  included in all copies of any software which is or includes
                  a copy or modification of this software and in all copies 
                  of the supporting documentation for such software.
   -------------------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
#include "sts.h"

/*
main(int argc, char *argv[])
{
  int    i;
  int    option;		// TEMPLATE LENGTH/STREAM LENGTH/GENERATOR
  char*  streamFile;	// STREAM FILENAME

  if ( ((output = fopen("stats", "w")) == NULL) ||
       ((post = fopen("finalAnalysisReport", "w")) == NULL) ||
       ((grid = fopen("grid", "w")) == NULL)) {
     printf("\t\tMAIN:  Could not open files stats or grid.\n");
     exit(-1);
  }
  else {
     if ( argc != 2 ) {
        printf("-----------------------------------------------------------\n");
        printf("        P A R A M E T E R       R E P R E S E N T A T I O N\n");
        printf("       --------------------    ----------------------------\n");
        printf("Usage: STREAM-SIZE          => BITSTREAM LENGTH.           \n");
        printf("-----------------------------------------------------------\n");
     }
	 
     else {
        tp.n = atoi(argv[1]);
        tp.blockFrequencyBlockLength = 10;
        tp.nonOverlappingTemplateBlockLength = 10;
        tp.overlappingTemplateBlockLength = 10;
        tp.universalBlockLength = 6;
        tp.universalNumberInitializationSteps = 640;
        tp.approximateEntropyBlockLength = 5;
		tp.serialBlockLength = 5;
        tp.linearComplexitySequenceLength = 5000;
        tp.wordLength = 10;
        tp.numOfBitStreams = 1;
        option = generatorOptions(&streamFile);
        chooseTests();
        fixParameters();
        openOutputStreams(option);
        invokeTestSuite(option,streamFile);
        fclose(output);
        fclose(grid);
        for(i = 0; i < NUMOFTESTS; i++) {
           if ( stats[i] != NULL )
			   fclose(stats[i]);
           if ( results[i] != NULL )
			   fclose(results[i]);
        }
        if ( testVector[0] || testVector[3] ) 
           partitionResultFile(2, tp.numOfBitStreams, option, 0);
        if ( testVector[0] || testVector[8] ) 
           partitionResultFile(MAXNUMOFTEMPLATES, tp.numOfBitStreams, option,1);
        if ( testVector[0] || testVector[12] )
           partitionResultFile(8, tp.numOfBitStreams, option, 2);
        if ( testVector[0] || testVector[13] )
           partitionResultFile(18, tp.numOfBitStreams, option, 3);
        if ( testVector[0] || testVector[14] )
           partitionResultFile(2, tp.numOfBitStreams, option, 4);
        fprintf(post,"-----------------------------------------------");
        fprintf(post,"-------------------------------\n");
        fprintf(post,"RESULTS FOR THE UNIFORMITY OF P-VALUES AND THE ");
		fprintf(post,"PROPORTION OF PASSING SEQUENCES\n");
        fprintf(post,"-----------------------------------------------");
        fprintf(post,"-------------------------------\n\n");
        fprintf(post,"-----------------------------------------------");
        fprintf(post,"-------------------------------\n");
        fprintf(post," C1  C2  C3  C4  C5  C6  C7  C8  C9 C10");
        fprintf(post,"  P-VALUE  PROPORTION  STATISTICAL TEST\n");
        fprintf(post,"-----------------------------------------------");
        fprintf(post,"-------------------------------\n");
        postProcessResults(option);
        fclose(post);
     }
  }
  return 1;
}
*/

#ifdef LBBBBBBBBBBBBBBBBB
void partitionResultFile(int numOfFiles, int numOfSequences, int option, 
                         int category)
{
	int    i, k, m, j, start, end, num, numread;
	float  c;
	FILE** fp = (FILE**)calloc(numOfFiles+1, sizeof(FILE*));
	int*   results = (int*)calloc(numOfFiles, sizeof(int*));
	char   *s[MAXFILESPERMITTEDFORPARTITION];
	char   resultsDir[100];
	char   generatorDir[NUMOFGENERATORS][20] = {"AlgorithmTesting", "G-SHA-1",
					"LCG", "BBS", "MS", "MODEXP", "QCG1", "QCG2", "CCG", "XOR",
					"ANSI-X9.17", "G-DES"};
	char   testNames[5][50] = {"cumulative-sums", "nonperiodic-templates",
					"random-excursions", "random-excursions-variant",
					"serial"};

	for ( i=0; i<=MAXFILESPERMITTEDFORPARTITION; i++ )
		s[i] = (char*)calloc(100, sizeof(char));

	sprintf(resultsDir, "experiments/%s/%s/results", generatorDir[option],
		testNames[category]);
	if ( DISPLAY_OUTPUT_CHANNELS )
		fprintf(output, "OPEN FILE:  %s\n", resultsDir);

	if ( (fp[numOfFiles] = fopen(resultsDir,"r")) == NULL ) {
		fprintf(output, "%s", resultsDir);
		fprintf(output, " -- file not found. Exiting program.\n");
		return;
	}

	for ( i=0; i<numOfFiles; i++ ) {
		if (i < 10)
			sprintf(s[i], "experiments/%s/%s/data%1d", generatorDir[option],
				testNames[category], i+1);
		else if (i < 100)
			sprintf(s[i], "experiments/%s/%s/data%2d", generatorDir[option],
				testNames[category], i+1);
		else
			sprintf(s[i], "experiments/%s/%s/data%3d", generatorDir[option],
				testNames[category], i+1);
		if ( DISPLAY_OUTPUT_CHANNELS )
			fprintf(output, "OPEN = %s\n", s[i]);
	}
	numread = 0;
	m = (numOfFiles+19) / 20;
	for ( i=0; i<numOfFiles; i++ ) {
		if ( (fp[i] = fopen(s[i],"w")) == NULL ) {
			fprintf(output, "%s", s[i]);
			fprintf(output, " -- file not found. Exiting program.\n");
			return;
		}
		fclose(fp[i]);
	}

	for ( num=0; num<numOfSequences; num++ ) {
		for ( k=0; k<m; k++ ) { 		/* FOR EACH BATCH */

			start = k*20;		/* BOUNDARY SEGMENTS */
			end = k*20+19;
			if ( k == (m-1) )
				end = numOfFiles-1;

			if ( PARTITION )
				fprintf(output, "k = %d start = %d end = %d\n", k, start, end);

			for ( i=start; i<=end; i++ ) {		/* OPEN FILE */
				if ( (fp[i] = fopen(s[i],"a")) == NULL ) {
					printf("%s",s[i]);
					printf(" -- file not found. Exiting program.\n");
					exit(-1);
				}
				if ( PARTITION )
					fprintf(output, "Open file %s\n", s[i]);
			}

			for ( j=start; j<=end; j++ ) {		/* POPULATE FILE */
				fscanf(fp[numOfFiles], "%f", &c);
				fprintf(fp[j], "%f\n", c);
				numread++;
				if ( PARTITION )
					fprintf(output, "NUMREAD = %d\n", numread);
			}

			for ( i=start; i<=end; i++ ) {		/* CLOSE FILE */
				fclose(fp[i]);
				if ( PARTITION )
					fprintf(output, "Close file %s\n", s[i]);
			}
		}
	}

	fclose(fp[numOfFiles]);
	for ( i=0; i<MAXNUMOFTEMPLATES; i++ )
		free(s[i]);

	return;
}

void postProcessResults(int option)
{
	int    i, k, randomExcursionSampleSize, generalSampleSize;
	int    case1, case2, numOfFiles = 2;
	double passRate;
	char   s[100];
	char   generatorDir[NUMOFGENERATORS][20] = {"AlgorithmTesting", "G-SHA-1",
					"LCG", "BBS", "MS", "MODEXP", "QCG1", "QCG2", "CCG", "XOR",
					"ANSI-X9.17", "G-DES"};
	char   testNames[NUMOFTESTS+1][50] = {" ", "frequency", "block-frequency",
					"cumulative-sums", "runs", "longest-run", "rank", "fft",
					"nonperiodic-templates", "overlapping-templates", "universal",
					"apen", "random-excursions", "random-excursions-variant",
					"serial", "lempel-ziv", "linear-complexity"};

	for ( i=1; i<=NUMOFTESTS; i++ ) {		/* FOR EACH TEST */

		if ( testVector[i] == 1 ) {

			/* SPECIAL CASES -- HANDLING MULTIPLE FILES FOR A SINGLE TEST */

			if ( ((i ==  3) && testVector[ 3]) || ((i ==  8) && testVector[ 8]) ||
				 ((i == 12) && testVector[12]) || ((i == 13) && testVector[13]) || 
				 ((i == 14) && testVector[14]) ) {

				if ( (i == 8) && testVector[8] )
					numOfFiles = MAXNUMOFTEMPLATES;
				else if ( (i == 12) && testVector[12] )
					numOfFiles = 8;
				else if ( (i == 13) && testVector[13] ) 
					numOfFiles = 18;
				else
					numOfFiles = 2;
				for ( k=0; k<numOfFiles; k++ ) {
					if ( k < 10 )
						sprintf(s, "experiments/%s/%s/data%1d", generatorDir[option],
							testNames[i], k+1);
					else if ( k < 100 )
						sprintf(s, "experiments/%s/%s/data%2d", generatorDir[option],
							testNames[i], k+1);
					else
						sprintf(s, "experiments/%s/%s/data%3d", generatorDir[option],
							testNames[i], k+1);
					generalSampleSize = computeMetrics(s,i);
					if ( (i == 12) || (i == 13) ) 
						randomExcursionSampleSize = generalSampleSize;
				}
			}
			else {
				sprintf(s, "experiments/%s/%s/results", generatorDir[option],
					testNames[i]);
				generalSampleSize = computeMetrics(s,i);
			}
		}
	}

	fprintf(post, "\n\n- - - - - - - - - - - - - - - - - - - - - - - - - - - -");
	fprintf(post, "- - - - - - - - - - - - -\n");

	case1 = 0;
	case2 = 0;

	if ( testVector[12] || testVector[13] )
		case2 = 1;

	for ( i=1; i<=NUMOFTESTS; i++ ) {
		if ( testVector[i] && (i != 12) && (i != 13) ) {
			case1 = 1;
			break;
		}
	}

	if ( case1 ) {
		passRate = 0.99-3.0*sqrt(0.01*(1.0-ALPHA)/(double)generalSampleSize);
		fprintf(post, "The minimum pass rate for each statistical test with ");
		fprintf(post, "the exception of the random\nexcursion (variant) test ");
		fprintf(post, "is approximately = %f for a sample size ",passRate);
		fprintf(post, "= %d\nbinary sequences.\n\n", generalSampleSize);
	}

	if ( case2 ) {
		passRate =.99-3.*sqrt(.01*(1.-ALPHA)/(double)randomExcursionSampleSize);
		fprintf(post, "The minimum pass rate for the random excursion ");
		fprintf(post, "(variant) test is approximately\n%f for a ", passRate);
		fprintf(post, "sample size = %d binary sequences.\n\n", 
			randomExcursionSampleSize);
	}

	fprintf(post, "For further guidelines construct a probability table using ");
	fprintf(post, "the MAPLE program\nprovided in the addendum section of the ");
	fprintf(post, "documentation.\n");
	fprintf(post, "- - - - - - - - - - - - - - - - - - - - - - - - - - - -");
	fprintf(post, "- - - - - - - - - - - - -\n");

	return;
}

int computeMetrics(char* s, int test)
{
	int    j, pos, count, sampleSize, expCount;
	int    freqPerBin[10] = {0,0,0,0,0,0,0,0,0,0};
	double *A, *T, chi2, proportion, uniformity;
	float  c;
	FILE*  fp;
	char   testNames[NUMOFTESTS+1][50] = {" ", "Frequency", "Block-Frequency",
				"Cusum", "Runs", "Long-Run", "Rank", "FFT", "Aperiodic-Template", 
				"Periodic-Template", "Universal", "Apen", "Random-Excursion", 
				"Random-Excursion-V", "Serial", "Lempel-Ziv", "Linear-Complexity"}; 

	if ( DISPLAY_OUTPUT_CHANNELS )
		fprintf(output, "OPEN = %s\n", s);

	if ( (fp = fopen(s,"r")) == NULL) {
		fprintf(output, "%s", s);
		fprintf(output, " -- file not found. Exiting program.\n");
		return 0;
	}

	A = (double*)calloc(tp.numOfBitStreams, sizeof(double));
	if ( A == NULL ) {
		fprintf(output, "Final Analysis Report aborted due to insufficient workspace\n");
		fflush(output);
		return 0;
	}

	/* Compute Metric 1: Proportion of Passing Sequences */

	count = 0; 		
	sampleSize = tp.numOfBitStreams;

	if ( (test == 12) || (test == 13) ) { /* Special Case: Random Excursion Tests */
		T = (double*)calloc(tp.numOfBitStreams,sizeof(double));
		if ( T == NULL ) {
			fprintf(output, "Final Analysis Report aborted due to insufficient workspace\n");
			fflush(output);
			return 0;
		}
		for ( j=0; j<sampleSize; j++ ) {
			fscanf(fp, "%f", &c);
			if ( (double)c > 0.000000 ) {
				T[count] = c;
				count++;
			}   
		}
		free(A);
		A = (double*)calloc(count, sizeof(double));
		for ( j=0; j<count; j++ )
			A[j] = T[j];

		sampleSize = count;
		count = 0;
		for ( j=0; j<sampleSize; j++ )
			if ( A[j] < ALPHA )
				count++;
		free(T);
	}
	else {
		for ( j=0; j<sampleSize; j++ ) {
			fscanf(fp, "%f", &c);
			if ( c < ALPHA )
				count++;
			A[j] = c;
		}
	}
	proportion = 1.0-(double)count/sampleSize;

	/* Compute Metric 2: Histogram */

	qsort((void*)A, sampleSize, sizeof(double), (void *)cmp);
	for ( j=0; j<sampleSize; j++ ) {
		pos = (int)floor(A[j]*10);
		if ( pos == 10 )
			pos--;
		freqPerBin[pos]++;
	}
	chi2 = 0.0;
	expCount = sampleSize/10;
	for ( j=0; j<10; j++ )
		chi2 += pow(freqPerBin[j]-expCount,2)/expCount;
	uniformity = igamc(9.0/2.0,chi2/2.0);

	for ( j=0; j<10; j++ )			/* DISPLAY RESULTS */
		fprintf(post, "%3d ", freqPerBin[j]);

	if ( uniformity < 0.0001 )
		fprintf(post, " %f * ", uniformity);
	else
		fprintf(post, " %f   ", uniformity);

	if ( proportion < 0.96 )
		fprintf(post, "%6.4f *  %s\n", proportion, testNames[test]);
	else
		fprintf(post, "%6.4f    %s\n", proportion, testNames[test]);

	fflush(post);
	fclose(fp);
	free(A);

	return sampleSize;
}
#endif