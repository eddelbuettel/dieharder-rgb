#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"
#include "mconf.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                              R U N S  T E S T 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void Runs(int n)
{
	int    i, state, *r;
	double argument, pi, V_n_obs, tau;
	double p_value, product, sum;
	char   assignment[7];
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("Runs.txt", "a");

	start = clock();
#endif
	
	if ( (r = (int *)calloc(n, sizeof(int))) == NULL ) {
		fprintf(stats[TESTS_RUNS],"\t\tRUNS TEST:  Insufficient space for work array,");
		fprintf(stats[TESTS_RUNS]," test aborted!\n");
		fprintf(results[TESTS_RUNS], "0.000000\n"); fflush(results[TESTS_RUNS]);
		fprintf(pvals, "0.000000 "); fflush(pvals);
	}
	else {
		sum = 0.0;
		for(i = 0; i < n; i++)
			sum += (int)epsilon[i].b;
		pi = sum/n;
		tau = 2.0/sqrt(n);
		if (fabs(pi - 0.5) < tau) {
			for(i = 0; i < n-1; i++) {
				if ((int)epsilon[i].b == (int)epsilon[i+1].b)
					r[i] = 0;
				else
					r[i] = 1;
			}
			V_n_obs = 0;
			for(i = 0; i < n-1; i++)
				V_n_obs += r[i];
			V_n_obs++;
			product = pi * (1.e0 - pi);
			argument = fabs(V_n_obs - 2.e0*n*product)/(2.e0*sqrt(2.e0*n)*product);
			p_value = erfc(argument);
			if ( RUNS ) { 
				fprintf(stats[TESTS_RUNS], "\t\t\t\tRUNS TEST\n");
				fprintf(stats[TESTS_RUNS], "\t\t------------------------------------------\n");
				fprintf(stats[TESTS_RUNS], "\t\tCOMPUTATIONAL INFORMATION:\n");
				fprintf(stats[TESTS_RUNS], "\t\t------------------------------------------\n");
				fprintf(stats[TESTS_RUNS], "\t\t(a) Pi                        = %f\n", pi);
				fprintf(stats[TESTS_RUNS], "\t\t(b) V_n_obs (Total # of runs) = %d\n", (int)V_n_obs);
				fprintf(stats[TESTS_RUNS], "\t\t(c) V_n_obs - 2 n pi (1-pi)\n");
				fprintf(stats[TESTS_RUNS], "\t\t    -----------------------   = %f\n", argument);
				fprintf(stats[TESTS_RUNS], "\t\t      2 sqrt(2n) pi (1-pi)\n");
				fprintf(stats[TESTS_RUNS], "\t\t------------------------------------------\n");
				if ( isNegative(p_value) || isGreaterThanOne(p_value) )
					fprintf(stats[TESTS_RUNS], "WARNING:  P_VALUE IS OUT OF RANGE.\n");
				}
			if (p_value < ALPHA) {				    /* INTERPRETATION */
				strcpy(assignment,"FAILURE");
				state = 0;
			}
			else {
				strcpy(assignment,"SUCCESS");
				state = 1;
			}
			fprintf(stats[TESTS_RUNS],"%s\t\tp_value = %f\n\n", assignment, p_value);
			}
		else {
			if (RUNS) {
				fprintf(stats[TESTS_RUNS],"\t\t\t\tRUNS TEST\n");
				fprintf(stats[TESTS_RUNS],"\t\t------------------------------------------\n");
				fprintf(stats[TESTS_RUNS],"\t\tPI ESTIMATOR CRITERIA NOT MET! PI = %1e\n", pi);
			}
			strcpy(assignment,"REJECTION");
			p_value = 0.0;
			state = 0;
		}
		fprintf(results[TESTS_RUNS], "%f\n", p_value); fflush(results[TESTS_RUNS]);
		fprintf(grid, "%d", state); fflush(grid);
		fprintf(pvals, "%f ", p_value); fflush(pvals);

		if ( p_value < tp.minimumP )
			tp.minimumP = p_value;
		if ( !_isnan(p_value) )
			tp.lnSum += log(p_value);
		tp.df++;

		fflush(stats[TESTS_RUNS]);
		free(r);
	}

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
