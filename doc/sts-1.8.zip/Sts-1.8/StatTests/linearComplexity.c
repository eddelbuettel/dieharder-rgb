#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"
#include "mconf.h"

void LinearComplexity(int M, int n)
{
	int       i, ii, j, d, N;
	int       L, m, N_, state, parity, sign;
	double    p_value, T_, mean;
	char      assignment[35];
	int       K = 6;
	double    pi[7]={0.01047,0.03125,0.12500,0.50000,0.25000,0.06250,0.020833};
	double    nu[7], chi2;
	BitField  *T, *P, *B_, *C;

#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("LinComp.txt", "a");

	start = clock();
#endif
	
	N = (int)floor(n/M);
	if ( ((B_ = (BitField*) calloc(M,sizeof(BitField))) == NULL) ||
		 ((C  = (BitField*) calloc(M,sizeof(BitField))) == NULL) ||
		 ((P  = (BitField*) calloc(M,sizeof(BitField))) == NULL) ||
		 ((T  = (BitField*) calloc(M,sizeof(BitField))) == NULL) ) {
		printf("Insufficient Memory for Work Space:: Linear Complexity Test\n");
		fflush(stdout);
		if ( B_!= NULL )
			free(B_);
		if ( C != NULL )
			free(C);
		if ( P != NULL )
			free(P);
		if ( T != NULL )
			free(T);
		return;
	}

	if ( LINEAR_COMPLEXITY ) {
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "-----------------------------------------------------\n");
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "\tL I N E A R  C O M P L E X I T Y\n");
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "-----------------------------------------------------\n");
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "\tM (substring length)     = %d\n", M);
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "\tN (number of substrings) = %d\n", N);
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "-----------------------------------------------------\n");
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "        F R E Q U E N C Y                            \n");
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "-----------------------------------------------------\n");
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "  C0   C1   C2   C3   C4   C5   C6    CHI2    P-value\n");
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "-----------------------------------------------------\n");
		if ( n%M != 0 ) 
			fprintf(stats[TESTS_LINEAR_COMPLEXITY], "\tNote: %d bits were discarded!\n", n%M);
	}
	for( i=0; i<K+1; i++ )
		nu[i] = 0.00;
	for( ii=0; ii<N; ii++ ) {

		for( i=0; i<M; i++ ) {
			B_[i].b = 0;
			C[i].b = 0;
			T[i].b = 0;
			P[i].b = 0;
		}

		L = 0;
		m = -1;
		d = 0;
		C[0].b = 1;
		B_[0].b = 1;

		/* DETERMINE LINEAR COMPLEXITY */
		N_ = 0;
		while( N_ < M ) {
			d = (int)epsilon[ii*M+N_].b;
			for( i=1; i<=L; i++ )
				d += (int)C[i].b*(int)epsilon[ii*M+N_-i].b;
			d = d%2;
			if ( d == 1 ) {
				for( i=0; i<M; i++ ) {
					T[i].b = C[i].b;
					P[i].b = 0;
				}
				for( j=0; j<M; j++ )
					if ( B_[j].b == 1 )
						P[j+N_-m].b = 1;
				for( i=0; i<M; i++ )
					C[i].b = (C[i].b + P[i].b)%2;
				if ( L <= N_/2 ) {
					L = N_ + 1 - L;
					m = N_;
					for( i=0; i<M; i++ )
						B_[i].b = T[i].b;
				}
			}
			N_++;
		}
		if ( (parity = (M+1)%2) == 0 ) 
			sign = -1;
		else 
			sign = 1;
		mean = M/2. + (9.+sign)/36. - 1./pow(2,M) * (M/3. + 2./9.);
		if ( (parity = M%2) == 0 ) 
			sign = 1;
		else 
			sign = -1;
		T_ = sign * (L - mean) + 2./9.;

		if ( T_ <= -2.5 )
			nu[0]++;
		else if ( T_ > -2.5 && T_ <= -1.5 )
			nu[1]++;
		else if ( T_ > -1.5 && T_ <= -0.5 )
			nu[2]++;
		else if ( T_ > -0.5 && T_ <= 0.5 )
			nu[3]++;
		else if ( T_ > 0.5 && T_ <= 1.5 )
			nu[4]++;
		else if ( T_ > 1.5 && T_ <= 2.5 )
			nu[5]++;
		else
			nu[6]++;
	}
	chi2 = 0.00;
	for( i=0; i<K+1; i++ ) 
		fprintf(stats[TESTS_LINEAR_COMPLEXITY], "%4d ",(int)nu[i]);
	for( i=0; i<K+1; i++ )
		chi2 += pow(nu[i]-N*pi[i],2)/(N*pi[i]);
	p_value = igamc(K/2.0,chi2/2.0);
	if ( p_value < ALPHA ) {				    /* INTERPRETATION */
		strcpy(assignment,"FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment,"SUCCESS");
		state = 1;
	}
	fprintf(stats[TESTS_LINEAR_COMPLEXITY], "%9.6f%9.6f\n", chi2, p_value); fflush(stats[TESTS_LINEAR_COMPLEXITY]);
	fprintf(results[TESTS_LINEAR_COMPLEXITY], "%f\n", p_value); fflush(results[TESTS_LINEAR_COMPLEXITY]);
	fprintf(grid, "%d", state); fflush(grid);
	fprintf(pvals, "%f ", p_value); fflush(pvals);

	if ( p_value < tp.minimumP )
		tp.minimumP = p_value;
	if ( !_isnan(p_value) )
		tp.lnSum += log(p_value);
	tp.df++;

	free(B_);
	free(P);
	free(C);
	free(T);

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
