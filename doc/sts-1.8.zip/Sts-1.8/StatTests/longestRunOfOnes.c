/* got rid of unused 'k' */

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"
#include "mconf.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                      L O N G E S T  R U N S  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void LongestRunOfOnes(int n)
{
	double run, v_n_obs, p_value, sum, chi2;
	int    N, i, j, state;
	char   assignment[7];

#if LONG_RUNS_CASE_8 == 1
	unsigned int nu[4] = {0, 0, 0, 0};
	double pi[4] = {0.21484375, 0.3671875, 0.23046875, 0.1875};
	double k[4] = {1, 2, 3, 8};
	double K = 3;
	int M = 8;
#elif LONG_RUNS_CASE_128 == 1
	double pi[6] = {0.1174035788, 0.242955959, 0.249363483, 0.17517706,
					0.1027010710, 0.112398847};
	double k[6] = {4, 5, 6, 7, 8, 9};
	double K = 5;
	unsigned int nu[6] = {0, 0, 0, 0, 0, 0};
	int M = 128;
#elif LONG_RUNS_CASE_10000 == 1
	double pi[7] = {0.0882, 0.2092, 0.2483, 0.1933, 0.1208, 0.0675, 0.0727};
	double K = 6;
	unsigned int nu[7] = {0, 0, 0, 0, 0, 0, 0};
	int M = 10000;
#endif

#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("LongRuns.txt", "a");

	start = clock();
#endif
	
	N = (int)floor(n/M);
	for(i = 0; i < N; i++)  {
		v_n_obs = 0.e0;
		run = 0.e0;
		for(j = i*M; j < (i+1)*M; j++) {
			if ((int)epsilon[j].b == 1) {
				run++;
				v_n_obs = MAX(v_n_obs, run); 
			}
			else 
				run = 0.e0;
		}
#if LONG_RUNS_CASE_8 == 1
		switch((int)v_n_obs) {
		case 0:
		case 1:
			nu[0]++;
			break;
		case 2:
			nu[1]++;
			break;
		case 3:
			nu[2]++;
			break;
		default:
			nu[3]++;
			break;
		}
#elif LONG_RUNS_CASE_128 == 1
		if ( (int)v_n_obs <= 4 )
			nu[0]++;
		else
			switch((int)v_n_obs) {
			case 5:
				nu[1]++;
				break;
			case 6:
				nu[2]++;
				break;
			case 7:
				nu[3]++;
				break;
			case 8:
				nu[4]++;
				break;
			default:
				nu[5]++;
				break;
			}
#elif LONG_RUNS_CASE_10000 == 1
		if ( (int)v_n_obs <= 10 )
			nu[0]++;
		else
			switch((int)v_n_obs) {
			case 11:
				nu[1]++;
				break;
			case 12:
				nu[2]++;
				break;
			case 13:
				nu[3]++;
				break;
			case 14:
				nu[4]++;
				break;
			case 15:
				nu[5]++;
				break;
			default:
				nu[6]++;
				break;
			}
#endif
	}
	chi2 = 0.0;					/* Compute Chi Square */
	sum = 0;
	for(i = 0; i < K+1; i++) {
		chi2 += pow((double)nu[i] - (double)N*pi[i],2)/((double)N*pi[i]);
		sum += nu[i];
	}
	p_value = igamc(K/2.,chi2/2.);
	/*p_value = gammq(K/2.,chi2/2.);*/
	if (LONG_RUNS) {
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t\t  LONGEST RUNS OF ONES TEST\n");
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\tCOMPUTATIONAL INFORMATION:\n");
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t(a) N (# of substrings)  = %d\n", (int)N);
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t(b) M (Substring Length) = %d\n", (int)M);
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t(c) Chi^2                = %f\n", chi2);
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t      F R E Q U E N C Y\n");
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t---------------------------------------------\n");
	}
	if (LONG_RUNS && LONG_RUNS_CASE_8) {
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t  <=1     2     3    >=4   P-value  Assignment");
		fprintf(stats[TESTS_LONGEST_RUNS], "\n\t\t %3d %3d %3d  %3d ",nu[0],nu[1],nu[2],nu[3]);
	}
	else if (LONG_RUNS && LONG_RUNS_CASE_128) {
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t<=4  5  6  7  8  >=9 P-value  Assignment");
		fprintf(stats[TESTS_LONGEST_RUNS], "\n\t\t %3d %3d %3d %3d %3d  %3d ",nu[0],nu[1],nu[2], nu[3], nu[4], nu[5]);
	}
	else if (LONG_RUNS && LONG_RUNS_CASE_10000) {
		fprintf(stats[TESTS_LONGEST_RUNS], "\t\t<=10  11  12  13  14  15 >=16 P-value  Assignment");
		fprintf(stats[TESTS_LONGEST_RUNS], "\n\t\t %3d %3d %3d %3d %3d %3d  %3d ",nu[0],nu[1],nu[2], nu[3], nu[4], nu[5], nu[6]);
	}
	if ( isNegative(p_value) || isGreaterThanOne(p_value) )
		fprintf(stats[TESTS_LONGEST_RUNS], "WARNING:  P_VALUE IS OUT OF RANGE.\n");
	if ( p_value < ALPHA ) {				    /* INTERPRETATION */
		strcpy(assignment,"FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment,"SUCCESS");
		state = 1;
	}
	fprintf(stats[TESTS_LONGEST_RUNS], "%f  %s\n\n", p_value, assignment); fflush(stats[TESTS_LONGEST_RUNS]);
	fprintf(results[TESTS_LONGEST_RUNS], "%f\n", p_value); fflush(results[TESTS_LONGEST_RUNS]);
	fprintf(grid, "%d", state); fflush(grid);
	fprintf(pvals, "%f ", p_value); fflush(pvals);

	if ( p_value < tp.minimumP )
		tp.minimumP = p_value;
	if ( !_isnan(p_value) )
		tp.lnSum += log(p_value);
	tp.df++;

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
