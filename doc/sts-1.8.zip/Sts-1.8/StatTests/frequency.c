#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "mconf.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                          F R E Q U E N C Y  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void Frequency(int n)
{
	int    i, state;
	double f, s_obs, p_value, sum;
	double sqrt2 = 1.41421356237309504880;
	char   assignment[7];
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("Frequency.txt", "a");

	start = clock();
#endif
	
	sum = 0.0;
	for( i=0; i<n; i++ )
		sum += 2*(int)epsilon[i].b-1;
	s_obs = fabs(sum)/sqrt(n);
	f = s_obs/sqrt2;
	p_value = erfc(f);

	if ( p_value < tp.minimumP )
		tp.minimumP = p_value;
	if ( !_isnan(p_value) )
		tp.lnSum += log(p_value);
	tp.df++;

	if ( FREQUENCY ) {
		fprintf(stats[TESTS_FREQUENCY], "\t\t\t      FREQUENCY TEST\n");
		fprintf(stats[TESTS_FREQUENCY], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_FREQUENCY], "\t\tCOMPUTATIONAL INFORMATION:\n");
		fprintf(stats[TESTS_FREQUENCY], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_FREQUENCY], "\t\t(a) The nth partial sum = %d\n", (int)sum);
		fprintf(stats[TESTS_FREQUENCY], "\t\t(b) S_n/n               = %f\n", sum/n);
		fprintf(stats[TESTS_FREQUENCY], "\t\t---------------------------------------------\n");
	}
	if ( p_value < ALPHA ) { /* INTERPRETATION */
		strcpy(assignment,"FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment,"SUCCESS");
		state = 1;
	}
	fprintf(stats[TESTS_FREQUENCY], "%s\t\tp_value = %f\n\n", assignment, p_value); fflush(stats[TESTS_FREQUENCY]);
	fprintf(results[TESTS_FREQUENCY], "%f\n", p_value); fflush(results[TESTS_FREQUENCY]);
	fprintf(grid, "%d", state); fflush(grid);
	fprintf(pvals, "%f ", p_value); fflush(pvals);

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
