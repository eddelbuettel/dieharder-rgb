#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "mconf.h"
#include "special-functions.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
		    C U M U L A T I V E  S U M S  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void CumulativeSums(int n)
{
	int    i, k, state, start, finish, mode;
	double p_value, cusum, z, sum, sum1, sum2;
	char   assignment[7];
	
#ifdef GEN_TIMING_INFO
	clock_t tstart, tfinish;
	FILE	*fp;
	fp = fopen("Cusum.txt", "a");

	tstart = clock();
#endif
	
	for( mode=0; mode<2; mode++ ) { /* mode = {0,1}  => {forward,reverse} */
		sum = 0.0;
		cusum = 1;

		if ( mode == 0 )
			for( i=0; i<n; i++ ) {
				sum += 2*(int)epsilon[i].b - 1;
				cusum = MAX(cusum, fabs(sum));
			}
		else if (mode == 1)
			for( i=n-1; i>=0; i-- ) {
				sum += 2*(int)epsilon[i].b - 1;
				cusum = MAX(cusum, fabs(sum));
			}
		z = cusum;

		sum1 = 0.0;
		start = (-n/(int)z+1)/4;
		finish = (n/(int)z-1)/4;
		for( k=start; k<=finish; k++ )
			sum1 += (normal((4*k+1)*z/sqrt(n))-normal((4*k-1)*z/sqrt(n)));

		sum2 = 0.0;
		start = (-n/(int)z-3)/4;
		finish = (n/(int)z-1)/4;
		for( k=start; k<=finish; k++ )
			sum2 += (normal((4*k+3)*z/sqrt(n))-normal((4*k+1)*z/sqrt(n)));
		p_value = 1.0 - sum1 + sum2;
		if ( CUSUM ) {
			if ( mode == 0 )
				fprintf(stats[TESTS_CUM_SUMS], "\t\t      CUMULATIVE SUMS (FORWARD) TEST\n");
			if ( mode == 1 ) 
				fprintf(stats[TESTS_CUM_SUMS], "\t\t      CUMULATIVE SUMS (REVERSE) TEST\n");
			fprintf(stats[TESTS_CUM_SUMS], "\t\t-------------------------------------------\n");
			fprintf(stats[TESTS_CUM_SUMS], "\t\tCOMPUTATIONAL INFORMATION:\n");
			fprintf(stats[TESTS_CUM_SUMS], "\t\t-------------------------------------------\n");
			fprintf(stats[TESTS_CUM_SUMS], "\t\t(a) The maximum partial sum = %d\n",(int)cusum);
			fprintf(stats[TESTS_CUM_SUMS], "\t\t-------------------------------------------\n");
		}
		if ( isNegative(p_value) || isGreaterThanOne(p_value) )
			fprintf(stats[TESTS_CUM_SUMS], "\t\tWARNING:  P_VALUE IS OUT OF RANGE\n");
		if ( p_value < ALPHA ) { /* INTERPRETATION */
			strcpy(assignment,"FAILURE");
			state = 0; 
		}
		else {
			strcpy(assignment,"SUCCESS");
			state = 1; 
		}
		fprintf(stats[TESTS_CUM_SUMS], "%s\t\tp_value = %f\n\n", assignment, p_value); fflush(stats[TESTS_CUM_SUMS]);
		fprintf(results[TESTS_CUM_SUMS], "%f\n", p_value); fflush(results[TESTS_CUM_SUMS]);
		fprintf(grid, "%d", state); fflush(grid);
		fprintf(pvals, "%f ", p_value); fflush(pvals);

		if ( p_value < tp.minimumP )
			tp.minimumP = p_value;
		if ( !_isnan(p_value) )
			tp.lnSum += log(p_value);
		tp.df++;
	}

#ifdef GEN_TIMING_INFO
	tfinish = clock();
	fprintf(fp, "%d\n", tfinish - tstart);
	fclose(fp);
#endif

	return;
}
