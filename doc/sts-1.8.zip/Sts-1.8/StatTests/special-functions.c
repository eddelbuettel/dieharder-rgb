#include <stdio.h>
#include <math.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                     S P E C I A L  F U N C T I O N S 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
double derfc(double x)
{ double f = 1 - derf_(&x);
  return(f);
}
*/

extern double erf ( double x );

double normal(double x)
{
	double arg, result, sqrt2=1.414213562373095048801688724209698078569672;

	if (x > 0) {
		arg = x/sqrt2;
		result = 0.5 * ( 1 + erf(arg) );
	}
	else {
		arg = -x/sqrt2;
		result = 0.5 * ( 1 - erf(arg) );
	}

	return(result);
}

double normal2(double a)
{
	return (1.0-0.5*erfc(a/sqrt(2.0)));
}
