#include <stdio.h> 
#include <math.h> 
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"
#include "mconf.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
            R A N D O M  E X C U R S I O N S  V A R I A N T  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void RandomExcursionsVariant(int n)
{
	int    i, p, J, x, state, constraint;
	double p_value;
	int    stateX[18] = {-9, -8, -7, -6, -5, -4, -3, -2, -1,
						 1, 2, 3, 4, 5, 6, 7, 8, 9};
	char   assignment[7];
	int    count;
	int*   S_k;
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("RndExcVar.txt", "a");

	start = clock();
#endif
	
	if ( (S_k = (int *) calloc(n,sizeof(int))) == NULL ) {
		fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\tRANDOM EXCURSIONS VARIANT: ");
		fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "Insufficent memory allocated.\n");
	}
	else {
		J = 0;
		S_k[0] = 2*(int)epsilon[0].b - 1;
		for( i=1; i<n; i++ ) {
			S_k[i] = S_k[i-1] + 2*epsilon[i].b - 1;
			if ( S_k[i] == 0 )
				J++;
		}
		if ( S_k[n-1] != 0 )
			J++;

		if ( RANDOM_EXCURSIONS_VARIANT ) {
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t\tRANDOM EXCURSIONS VARIANT TEST\n");
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t--------------------------------------------\n");
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\tCOMPUTATIONAL INFORMATION:\n");
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t--------------------------------------------\n");
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t(a) Number Of Cycles (J) = %d\n", J);
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t(b) Sequence Length (n)  = %d\n", n);
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t--------------------------------------------\n");
		}
		constraint = (int)MAX(0.005*pow(n,0.5),500);
		if ( J < constraint ) {
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\n\t\tWARNING:  TEST NOT APPLICABLE.  THERE ARE ");
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "AN\n\t\t\t  INSUFFICIENT NUMBER OF CYCLES.\n");
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t---------------------------------------------");
			fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\n");
			for( i=0; i<18; i++ ) {
				fprintf(results[TESTS_RANDOM_EXCUR_VAR], "%f\n", 0.0);
				fprintf(grid, "%d", 0); fflush(grid);
				fprintf(pvalsRndExcVar, "0.000000 "); fflush(pvalsRndExcVar);
			}
		}
		else {
			for( p=0; p<=17; p++ ) {
				x = stateX[p];
				count = 0;
				for( i=0; i<n; i++ )
					if ( S_k[i] == x )
						count++;
				p_value = erfc(fabs(count-J)/(sqrt(2.*J*(4.*fabs(x)-2))));

				if ( p_value < ALPHA ) {
					strcpy(assignment,"FAILURE");
					state = 0;
				}
				else { 
					strcpy(assignment,"SUCCESS");
					state = 1;
				}
				if ( isNegative(p_value) || isGreaterThanOne(p_value) )
					fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\t\t(b) WARNING: P_VALUE IS OUT OF RANGE.\n");
				fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "%s\t\t(x = %2d) Total visits = %4d; p-value = %f\n",
					assignment, x, count, p_value); fflush(stats[TESTS_RANDOM_EXCUR_VAR]);
				fprintf(results[TESTS_RANDOM_EXCUR_VAR], "%1e\n", p_value); fflush(results[TESTS_RANDOM_EXCUR_VAR]);
				fprintf(grid, "%d", state); fflush(grid);
				fprintf(pvalsRndExcVar, "%f ", p_value); fflush(pvalsRndExcVar);

				if ( p_value < tp.minimumP )
					tp.minimumP = p_value;
				if ( !_isnan(p_value) )
					tp.lnSum += log(p_value);
				tp.df++;
			}
		}
	}
	fprintf(stats[TESTS_RANDOM_EXCUR_VAR], "\n");
	free(S_k);

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
