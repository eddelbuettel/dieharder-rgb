#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"
#include "mconf.h"


double psi2(int m, int n);

void Serial(int m, int n)
{
	int    state;
	char   assignment[7];
	double p_value1, p_value2, psim0, psim1, psim2, del1, del2;
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("Serial.txt", "a");

	start = clock();
#endif
	
	psim0 = psi2(m, n);
	psim1 = psi2(m-1, n);
	psim2 = psi2(m-2, n);
	del1 = psim0 - psim1;
	del2 = psim0 - 2.0*psim1 + psim2;
	p_value1 = igamc(pow(2,m-1)/2,del1/2.0);
	p_value2 = igamc(pow(2,m-2)/2,del2/2.0);
	fprintf(stats[TESTS_SERIAL], "\t\t\t       SERIAL TEST\n");
	fprintf(stats[TESTS_SERIAL], "\t\t---------------------------------------------\n");
	fprintf(stats[TESTS_SERIAL], "\t\t COMPUTATIONAL INFORMATION:		  \n");
	fprintf(stats[TESTS_SERIAL], "\t\t---------------------------------------------\n");
	fprintf(stats[TESTS_SERIAL], "\t\t(a) Block length    (m) = %d\n", m);
	fprintf(stats[TESTS_SERIAL], "\t\t(b) Sequence length (n) = %d\n", n);
	fprintf(stats[TESTS_SERIAL], "\t\t(c) Psi_m               = %f\n", psim0);
	fprintf(stats[TESTS_SERIAL], "\t\t(d) Psi_m-1             = %f\n", psim1);
	fprintf(stats[TESTS_SERIAL], "\t\t(e) Psi_m-2             = %f\n", psim2);
	fprintf(stats[TESTS_SERIAL], "\t\t(f) Del_1               = %f\n", del1);
	fprintf(stats[TESTS_SERIAL], "\t\t(g) Del_2               = %f\n", del2);
	fprintf(stats[TESTS_SERIAL], "\t\t---------------------------------------------\n");

	if ( p_value1 < ALPHA ) {
		strcpy(assignment,"FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment,"SUCCESS");
		state = 1;
	}
	fprintf(stats[TESTS_SERIAL], "%s\t\tp_value1 = %f\n", assignment, p_value1);
	fprintf(results[TESTS_SERIAL], "%f\n", p_value1); fflush(results[TESTS_SERIAL]);
	fprintf(grid, "%d", state); fflush(grid);
	fprintf(pvals, "%f ", p_value1); fflush(pvals);

	if ( p_value1 < tp.minimumP )
		tp.minimumP = p_value1;
	if ( !_isnan(p_value1) )
		tp.lnSum += log(p_value1);
	tp.df++;

	if (p_value2 < ALPHA) {
		strcpy(assignment,"FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment,"SUCCESS");
		state = 1;
	}
	fprintf(stats[TESTS_SERIAL], "%s\t\tp_value2 = %f\n\n", assignment, p_value2); fflush(stats[TESTS_SERIAL]);
	fprintf(results[TESTS_SERIAL], "%f\n", p_value2); fflush(results[TESTS_SERIAL]);
	fprintf(grid, "%d", state); fflush(grid);
	fprintf(pvals, "%f ", p_value2); fflush(pvals);

	if ( p_value2 < tp.minimumP )
		tp.minimumP = p_value2;
	if ( !_isnan(p_value2) )
		tp.lnSum += log(p_value2);
	tp.df++;

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}

double psi2(int m, int n)
{
	int            i, j, k, powLen;
	double         sum, numOfBlocks;
	unsigned int*  P;

	if ( (m == 0) || (m == -1) )
		return 0.0;
	numOfBlocks = n;
	powLen = (int)pow(2,m+1)-1;
	if ( (P = (unsigned int*)calloc(powLen,sizeof(unsigned int)))== NULL ) {
		fprintf(stats[TESTS_SERIAL], "Serial Test:  Insufficient memory available.\n");
		fflush(stats[TESTS_SERIAL]);
		return 0;
	}
	for( i=1; i<powLen-1; i++ )
		P[i] = 0;	  /* INITIALIZE NODES */
	for( i=0; i<numOfBlocks; i++ ) {		 /* COMPUTE FREQUENCY */
		k = 1;
		for( j=0; j<m; j++ ) {
			if ( epsilon[(i+j)%n].b == 0 )
				k *= 2;
			else if ( epsilon[(i+j)%n].b == 1 )
				k = 2*k+1;
		}
		P[k-1]++;
	}
	/* DISPLAY FREQUENCY */
	sum = 0.0;
	for( i=(int)pow(2,m)-1; i<(int)pow(2,m+1)-1; i++ )
		sum += pow(P[i],2);
	sum = (sum * pow(2,m)/(double)n) - (double)n;
	free(P);

	return sum;
}