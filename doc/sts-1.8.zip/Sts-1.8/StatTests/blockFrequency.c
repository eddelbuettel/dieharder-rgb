#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "special-functions.h"
#include "mconf.h"
#include "cephes-protos.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                    B L O C K  F R E Q U E N C Y  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void BlockFrequency(int m, int n)
{
	int    i, j, N, state;
	double blockSum, arg1, arg2, p_value;
	double sum, pi, v, chi_squared;
	char   assignment[7];
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("BlkFreq.txt", "a");

	start = clock();
#endif
	
	N = (int)floor((double)n/(double)m); 		/* # OF SUBSTRING BLOCKS      */
	sum = 0.0;

	for( i=0; i<N; i++ ) {			/* N=10000 FOR EACH SUBSTRING BLOCK   */
		pi = 0.0;
		blockSum = 0.0;
		for( j=0; j<m; j++ ) 		/* m=100 COMPUTE The "i"th Pi Value */	 
			blockSum += epsilon[j+i*m].b;
		pi = (double)blockSum/(double)m;
		v = pi - 0.5;
		sum += v*v;
	}
	chi_squared = 4.0 * m * sum;

	arg1 = (double) N/2.e0;
	arg2 = chi_squared/2.e0;
	if ( BLOCK_FREQUENCY ) {
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t\tBLOCK FREQUENCY TEST\n");
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\tCOMPUTATIONAL INFORMATION:\n");
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t(a) Chi^2           = %f\n", chi_squared);
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t(b) # of substrings = %d\n", N);
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t(c) block length    = %d\n", m);
		if ( n % m ) 
			fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t(d) Note: %d bits were discarded.\n", n%m);
		fprintf(stats[TESTS_BLOCK_FREQUENCY], "\t\t---------------------------------------------\n");
	}
	p_value = igamc(arg1,arg2);
	/*p_value = gammq(arg1,arg2);*/
	if (p_value < ALPHA) {				    /* INTERPRETATION */
		strcpy(assignment,"FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment,"SUCCESS");
		state = 1;
	}
	fprintf(stats[TESTS_BLOCK_FREQUENCY], "%s\t\tp_value = %f\n\n", assignment, p_value); fflush(stats[TESTS_BLOCK_FREQUENCY]);
	fprintf(results[TESTS_BLOCK_FREQUENCY], "%f\n", p_value); fflush(results[TESTS_BLOCK_FREQUENCY]);
	fprintf(grid, "%d", state); fflush(grid);
	fprintf(pvals, "%f ", p_value); fflush(pvals);

	if ( p_value < tp.minimumP )
		tp.minimumP = p_value;
	if ( !_isnan(p_value) )
		tp.lnSum += log(p_value);
	tp.df++;

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
