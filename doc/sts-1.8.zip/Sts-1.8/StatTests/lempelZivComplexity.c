#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
               L E M P E L  Z I V  C O M P R E S S I O N  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

int LempelZivCompression(int n)
{
	int			W;	/* Number of words */
	int			i, j, k, prev_I, powLen, max_len, state, nOrig;
	int			done = 0;
	double		p_value, mean, variance;
	char		assignment[15];    
	BitField	*P;
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("LempelZiv.txt", "a");

	start = clock();
#endif

	W = 0;
	nOrig = n;
	k = (int)(log(n)/log(2)+6);
	powLen = (int)pow(2, k);
	fprintf(stats[15], "\t\t\t  LEMPEL-ZIV COMPRESSION TEST\n");
	fprintf(stats[15], "\t\t-----------------------------------------\n");
	if ( (P = (BitField*)calloc(powLen, sizeof(BitField))) == NULL ) {
		fprintf(stats[15], "\t\tLempel-Ziv Compression has been aborted,\n");    
		fprintf(stats[15], "\t\tdue to insufficient workspace!\n");
	}
	else {
		for( i=0; i<powLen; i++ ) 
			P[i].b = 0;
		i = 0;
		max_len = 0;
		while( i <= n-1 ) {
			done = 0;
			j = 1;
			prev_I = i;
			while( !done ) {
				if ( 2*j+1 <= powLen ) {
					if ( (int)epsilon[i].b == 0 ) {
						if ( P[2*j].b == 1 ) {
							j *= 2;
						}
						else {
							P[2*j].b = 1;
							done = 1;
						}
					}
					else {
						if ( P[2*j+1].b == 1 ) {
							j = 2*j+1;
						}
						else {
							P[2*j+1].b = 1;
							done = 1;
						}
					}
					i++;
					if ( i > n-1 ) {
						done = 1;
					}
					if ( done ) {
						W++;
						max_len = MAX(max_len, i-prev_I);
					}
				}
				else {
					fprintf(stats[15], "\t\tWARNING: Segmentation Violation Imminent.");
					fprintf(stats[15], "\n\t\t\t Lempel-Ziv Compression Terminated.\n");
					fprintf(stats[15], "\t\t-----------------------------------------\n");
					fflush(stats[15]);
					done = 1;
					i = n;
				}
			}
		}
		switch( n ) {
		case 100000:
			mean = 8782.500000; 
			variance = 11.589744;
			break;
		case 200000:
			mean = 16292.1000;
			variance = 21.4632;
			break;
		case 400000:
			mean = 30361.9500;
			variance = 58.7868;
			break;
		case 600000:
			mean = 43787.5000;
			variance = 70.1579;
			break;
		case 800000:
			mean = 56821.9500;
			variance = 67.4184;
			break;
		case 1000000:
			/* Updated Mean and Variance 10/26/99 */
			mean = 69588.20190000;
			variance = 73.23726011;
			/* Previous Mean and Variance
			mean = 69586.250000;
			variance = 70.448718;
			*/
			break;
		case 5000000:
			mean = 303156.9;
			variance = 266.1341;
			//fp = fopen("W-obs-5000000.txt", "a");
			//fprintf(fp, "Wobs: %d\n", W);
			//fclose(fp);
			break;
		case 10000000:
			mean = 574227.482;
			variance = 447.2809059;
			//fp = fopen("W-obs.txt", "a");
			//fprintf(fp, "Wobs: %d\n", W);
			//fclose(fp);
			break;
		case 100000000:
			mean = 574227.482;
			variance = 447.2809059;
//			fp1 = fopen("W-obs-100000000.txt", "a");
//			fprintf(fp1, "%d\n", W);
//			fclose(fp1);
			break;
		default:
			break;
		}
		p_value = 0.5*erfc((mean-W)/pow(2.0*variance,0.5));

		if ( LEMPEL_ZIV ) {
			fprintf(stats[15], "\t\tCOMPUTATIONAL INFORMATION:\n");
			fprintf(stats[15], "\t\t-----------------------------------------\n");
			fprintf(stats[15], "\t\t(a) W (# of words) = %d\n", W);
			if ( (nOrig%1000000) != 0 )
				fprintf(stats[15], "\t\t(b) Bits Discarded = %d\n",nOrig%1000000);
			fprintf(stats[15], "\t\t-----------------------------------------\n");
		}
		if ( p_value < ALPHA ) {
			strcpy(assignment,"FAILURE");
			state = 0;
		}
		else {
			strcpy(assignment,"SUCCESS");
			state = 1;
		}
		fprintf(stats[15], "%s\t\tp_value = %f\n\n", assignment, p_value);
		fprintf(results[15], "%f\n", p_value);
		fprintf(grid, "%d", state);
		fflush(stats[15]);
		fflush(results[15]);
		fflush(grid);
		free(P);
	}

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return W;
}