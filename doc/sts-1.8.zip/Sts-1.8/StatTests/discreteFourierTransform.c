#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "utilities1.h"
#include "special-functions.h"
#include "mconf.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         D I S C R E T E  F O U R I E R  T R A N S F O R M  T E S T 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void  __ogg_fdrffti(int n, double* wsave, double* ifac);
void  __ogg_fdrfftf(int n, double* X, double* wsave, double* ifac);

void DiscreteFourierTransform(int n)
{
	double   p_value, upperBound, percentile, *m, *X;
	int      i, count, state;
	double   N_l, N_o, d;
	char     assignment[10];

#if SAVE_FFT_PARAMETERS == 1
	FILE*    fourierPoints, *magnitude;
#endif

	double*  wsave, *ifac;
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("DFFT.txt", "a");

	start = clock();
#endif
  
#if SAVE_FFT_PARAMETERS == 1
	if ( ((fourierPoints = fopen("fourierPoints","w")) == NULL) || 
		 ((magnitude = fopen("magnitude","w")) == NULL) ) {
		fprintf(stats[TESTS_DFFT],"\t\tDFT:  Files fourierPoints and magnitude could not ");
		fprintf(stats[TESTS_DFFT],"be opened.\n");
	}
	else {
#endif
		if ( ((X = (double*) calloc(n,sizeof(double))) == NULL) ||
			 ((wsave = (double *)calloc(2*n+15,sizeof(double))) == NULL) ||
			 ((ifac = (double *)calloc(15,sizeof(double))) == NULL) ||
			 ((m = (double*)calloc(n/2+1, sizeof(double))) == NULL) ) {
			fprintf(stats[TESTS_DFFT], "\t\tUnable to allocate working arrays for the DFT.\n");
			fflush(stats[TESTS_DFFT]);
			if( X != NULL )
				free(X);
			if( wsave != NULL )
				free(wsave);
			if( ifac != NULL )
				free(ifac);
			if( m != NULL )
				free(m);
		}
		else {
			for( i=0; i<n; i++ )
				X[i] = 2*(int)epsilon[i].b - 1;

			__ogg_fdrffti(n, wsave, ifac);		    /* INITIALIZE WORK ARRAYS */
			__ogg_fdrfftf(n, X, wsave, ifac);	    /* APPLY FORWARD FFT */

			m[0] = sqrt(X[0]*X[0]);	    /* COMPUTE MAGNITUDE */

#if SAVE_FFT_PARAMETERS == 1
			fprintf(magnitude,"%6d %12.10f\n", 0, m[0]);
			fprintf(fourierPoints,"f[%6d] = %12.10f + %12.10f I\n",0,X[0],0.e+00);
#endif
			for( i=0; i<n/2; i++ ) {	   	    /* DISPLAY FOURIER POINTS */
				m[i+1] = sqrt( pow(X[2*i+1],2) + pow(X[2*i+2],2) ); 
#if SAVE_FFT_PARAMETERS == 1
				fprintf(fourierPoints, "f[%6d] = %12.10f + %12.10f I\n", i+1, X[2*i+1],-X[2*i+2]);
				fprintf(magnitude, "%6d %12.10f\n", i+1, m[i+1]);
#endif
			}
			count = 0;				       /* CONFIDENCE INTERVAL */
			//upperBound = sqrt(3*n);
			upperBound = sqrt(2.995732274*n);
			for( i=0; i<n/2; i++ )
				if ( m[i] < upperBound )
					count++;
			percentile = (double)count/(n/2)*100;
			N_l = (double) count;       /* number of peaks less than h = sqrt(3*n) */
			N_o = (double) 0.95*n/2.;
			//d = (N_l - N_o)/sqrt(n/2.*0.95*0.05);
			d = (N_l - N_o)/sqrt(n/4.0*0.95*0.05);
			p_value = erfc(fabs(d)/sqrt(2.));
			if ( DFT ) {
				fprintf(stats[TESTS_DFFT], "\t\t\t\tFFT TEST\n");
				fprintf(stats[TESTS_DFFT], "\t\t-------------------------------------------\n");
				fprintf(stats[TESTS_DFFT], "\t\tCOMPUTATIONAL INFORMATION:\n");
				fprintf(stats[TESTS_DFFT], "\t\t-------------------------------------------\n");
				fprintf(stats[TESTS_DFFT], "\t\t(a) Percentile = %f\n", percentile);
				fprintf(stats[TESTS_DFFT], "\t\t(b) N_l        = %f\n", N_l);
				fprintf(stats[TESTS_DFFT], "\t\t(c) N_o        = %f\n", N_o);
				fprintf(stats[TESTS_DFFT], "\t\t(d) d          = %f\n", d);
				fprintf(stats[TESTS_DFFT], "\t\t-------------------------------------------\n");
			}
			if ( p_value<ALPHA ) {				    /* INTERPRETATION */
				strcpy(assignment,"FAILURE");
				state = 0;
			}
			else {
				strcpy(assignment,"SUCCESS");
				state = 1;
			}
			fprintf(stats[TESTS_DFFT],"%s\t\tp_value = %f\n\n", assignment, p_value); fflush(stats[TESTS_DFFT]);
			fprintf(results[TESTS_DFFT], "%f\n", p_value); fflush(results[TESTS_DFFT]);
			fprintf(grid, "%d", state); fflush(grid);
			fprintf(pvals, "%f ", p_value); fflush(pvals);

			if ( p_value < tp.minimumP )
				tp.minimumP = p_value;
			if ( !_isnan(p_value) )
				tp.lnSum += log(p_value);
			tp.df++;

			free(X);
			free(wsave);
			free(ifac);
			free(m);
		}
#if SAVE_FFT_PARAMETERS == 1
	fclose(fourierPoints);
	fclose(magnitude);
	}
#endif

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
