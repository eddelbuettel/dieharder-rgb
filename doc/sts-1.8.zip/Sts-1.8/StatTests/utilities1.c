
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                            U T I L I T I E S
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "utilities1.h"
#include "special-functions.h"
#include "mconf.h"

extern double lgam ( double x );

double Pr(int u, double eta)
{
	int    l;
	double sum, p;

	if (u == 0)
		p = exp(-eta);
	else {
		sum = 0.0;
		for(l = 1; l <= u; l++)
			sum += exp(-eta-u*log(2)+l*log(eta)-lgam(l+1)+lgam(u)-lgam(l)-
					lgam(u-l+1));
	/*sum += exp(-eta-u*log(2)+l*log(eta)-gammln(l+1)+gammln(u)-gammln(l)-
	gammln(u-l+1));*/
		p = sum;
	}

	return p;
}

void induceBias(int n)
{
	int i, j, num, n0, n1;

	j = 0;
	while (j < floor(n-20)/40) {
		j++;
		num = 40*j-1;
		epsilon[num].b = 0;
		epsilon[num+20].b = 1;
	}
	n0 = 0;
	n1 = 0;
	for(i=0; i < n; i++) {
		if (epsilon[i].b == 0) 
			n0++;
		else 
			n1++;
	}
	fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n", n, n0, n1);
	fflush(output);

	return;
}

void
ahtopb (char *ascii_hex, BYTE *p_binary, int bin_len)
{
	BYTE	wbyte, wbyte2;
	int		i; 
	
	for ( i=0; i<bin_len; i++ ) {
        wbyte = ascii_hex[i * 2];
	    if (wbyte > 'F')
	        wbyte -= 0x20;   
	    if (wbyte > '9')
	        wbyte -= 7;      
	    wbyte -= '0';   
	    wbyte2 = wbyte << 4;

	    wbyte = ascii_hex[i * 2 + 1];
	    if (wbyte > 'F')
			wbyte -= 0x20;
        if (wbyte > '9')
            wbyte -= 7;   
        wbyte -= '0';
		wbyte2 += wbyte;

#ifdef LITTLE_ENDIAN
		p_binary[((i%2)==0)? i+1 : i-1] = wbyte2; 
#else
        p_binary[i] = wbyte2; 
#endif
	}
}