#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "utilities1.h"
#include "special-functions.h"
#include "mconf.h"
#include "cephes-protos.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
                A P P R O X I M A T E  E N T R O P Y   T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void ApproximateEntropy(int m, int n)
{
	int           i, j, k, r, blockSize, seqLength;
	int           powLen, index, state;
	double        sum, numOfBlocks, ApEn[2], apen, chi_squared, p_value;
	unsigned int* P;
	char          assignment[7];
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("Apen.txt", "a");

	start = clock();
#endif
	
#if SAVE_APEN_PARAMETERS == 1
	FILE		*x_coord, *y_coord;  
	x_coord = fopen("abscissaValues", "w");
	y_coord = fopen("ordinateValues", "w");

	if ( x_coord == NULL ) {
		printf("file \" abscissaValues\" could not be opened.\n");
		exit(-1);
	}
	if ( y_coord == NULL ) {
		printf("file \" ordinateValues\" could not be opened.\n");
		exit(-1);
	}
#endif

	if ( APEN ) {
		fprintf(stats[TESTS_APEN], "\t\t\tAPPROXIMATE ENTROPY TEST\n");
		fprintf(stats[TESTS_APEN], "\t\t--------------------------------------------\n");
	}
	seqLength = n;
#if SAVE_APEN_PARAMETERS == 1
	for( seqLength=m+1; seqLength<=n; seqLength += SEQ_LENGTH_STEP_INCREMENTS ) {
		fprintf(x_coord, "%d\n", seqLength);
		fflush(x_coord);
#endif
	r = 0;
	if ( APEN ) {
		fprintf(stats[TESTS_APEN], "\t\tCOMPUTATIONAL INFORMATION:\n");
		fprintf(stats[TESTS_APEN], "\t\t--------------------------------------------\n");
		fprintf(stats[TESTS_APEN], "\t\t(a) m (block length)    = %d\n", m);
	}
	for( blockSize=m; blockSize<=m+1; blockSize++ ) {
		if (blockSize == 0) {
			ApEn[0] = 0.00;
			r++;
		}
		else {
			numOfBlocks = (double)seqLength;
			powLen = (int)pow(2,blockSize+1)-1;
			if ( (P = (unsigned int*)calloc(powLen,sizeof(unsigned int)))== NULL ){
				fprintf(stats[TESTS_APEN], "ApEn:  Insufficient memory available.\n");
				fflush(stats[TESTS_APEN]);
				return;
			}
			for( i=1; i<powLen-1; i++ )
				P[i] = 0;
			for( i=0; i<numOfBlocks; i++ ) { /* COMPUTE FREQUENCY */
				k = 1;
				for( j=0; j<blockSize; j++ ) {
					if ( (int)epsilon[(i+j)%seqLength].b == 0 )
						k *= 2;
					else if ( (int)epsilon[(i+j)%seqLength].b == 1 )
						k = 2*k+1;
				}
				P[k-1]++;
			}
			/* DISPLAY FREQUENCY */
			sum = 0.0;
			index = (int)pow(2,blockSize)-1;
			for( i=0; i<(int)pow(2,blockSize); i++ ) {
				if ( P[index] > 0 )
					sum += P[index]*log(P[index]/numOfBlocks);
				index++;
			}
			sum /= numOfBlocks;
			ApEn[r] = sum;
			r++;
			free(P);
		}
	}
	apen = ApEn[0] - ApEn[1];

#if SAVE_APEN_PARAMETERS == 1
	fprintf(y_coord, "%10.15f\n", log(2) - apen);
	fflush(y_coord);
#endif

	chi_squared = 2.0*seqLength*(log(2) - apen);
	p_value = igamc(pow(2,m-1),chi_squared/2.);
	/*p_value = gammq(pow(2,m-1),chi_squared/2.);*/
	if ( APEN ) {
		fprintf(stats[TESTS_APEN], "\t\t(b) n (sequence length) = %d\n", seqLength);
		fprintf(stats[TESTS_APEN], "\t\t(c) Chi^2               = %f\n", chi_squared);
		fprintf(stats[TESTS_APEN], "\t\t(d) Phi(m)	       = %f\n", ApEn[0]);
		fprintf(stats[TESTS_APEN], "\t\t(e) Phi(m+1)	       = %f\n", ApEn[1]);
		fprintf(stats[TESTS_APEN], "\t\t(f) ApEn                = %f\n", apen);
		fprintf(stats[TESTS_APEN], "\t\t(g) Log(2)              = %f\n", log(2.0));
		fprintf(stats[TESTS_APEN], "\t\t--------------------------------------------\n");
	}
	if ( p_value < ALPHA ) {
		strcpy(assignment, "FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment, "SUCCESS");
		state = 1;
	}
	if ( m > (int)(log(seqLength)/log(2)-5) ) {
		fprintf(stats[TESTS_APEN], "\t\tNote: The blockSize = %d exceeds recommended", m);
		fprintf(stats[TESTS_APEN], "\n\t\tvalues = %d; results are inaccurate!\n", MAX(1,(int)(log(seqLength)/log(2)-5)));
		fprintf(stats[TESTS_APEN], "\t\t--------------------------------------------\n");
	}
	fprintf(stats[TESTS_APEN], "%s\t\tp_value = %f\n\n", assignment, p_value); fflush(stats[TESTS_APEN]);
	fprintf(results[TESTS_APEN], "%f\n", p_value); fflush(results[TESTS_APEN]);
	fprintf(grid, "%d", state); fflush(grid);
	fprintf(pvals, "%f ", p_value); fflush(pvals);

	if ( p_value < tp.minimumP )
		tp.minimumP = p_value;
	if ( !_isnan(p_value) )
		tp.lnSum += log(p_value);
	tp.df++;

#if SAVE_APEN_PARAMETERS == 1
	}
	fclose(x_coord);
	fclose(y_coord);
#endif

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
