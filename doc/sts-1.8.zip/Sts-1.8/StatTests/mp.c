/*
 * file: mp.c
 *
 *
 * DESCRIPTION
 *
 * These functions comprise a multi-precision integer arithmetic
 * and discrete function package.
 *
 *
 * INTEGER FORMAT 
 *
 * Multi-precision integers are represented using arrays of digits,
 * where a digit is the user defined type DIGIT, arranged in a High-low
 * ordering where the most significant digit is stored in the
 * first (lowest addressed) element of the array and the least significant
 * digit is stored in the last (highest addressed) element of the array.
 * **NOTE that the ordering of the bytes within a DIGIT is architecture
 * dependent.
 *
 * The routines given here make the assumption that a DIGIT is a 16-bit
 * word (2 bytes), which on most C compilers is the type "unsigned short".
 * This facilitates word X word multiplication which yields a 32-bit word
 * result (4 bytes), which on most C compilers is the type "unsigned long".
 * This library defines the type DBLWORD to represent 32-bit words.
 *
 * LIMITATIONS
 *
 * Currently few C compilers support a 64-bit integral type which is 
 * unfortunate since many machine architectures have hardware support for
 * performing 32-bit X 32-bit multiplication.  Thus, in order to remain as
 * portable as possible within the  bounds of the C language, this library
 * is limited to 16-bit X 16-bit multiplication which is not optimal for
 * most modern architectures.
 * 
 *
 *
 */

#include 	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<ctype.h>
#include	<time.h>
#include	"mp.h"
#include	"dsa.h"

static BYTE	DP[32], DQ[32];
static BYTE	CP[32], CQ[32];
static BYTE	RAM[256];

//#define DEBUG_PARMS

/*****************************************
** bzero - Fill array with zero's        *
**                                       *
** Parameters:                           *
**                                       *
**  x      Address of array x            *
**  l      Length of array in bytes      *
**                                       *
******************************************/ 
void bzero(BYTE *x, int l)
{
	while (l--)
		x[l] = 0;
	}


/*****************************************
** bcopy - Copy one array into another   *
**                                       *
** Parameters:                           *
**                                       *
**  x      Address of array x            *
**  y      Address of array y            *
**  l      Amount of bytes to copy       *
**                                       *
******************************************/ 
void bcopy(BYTE *x, BYTE *y, int l)
{	
	while (l--)
		y[l] = x[l];
	}


/*****************************************
** eqzero - Test if array all zeros      *
**                                       *
** Returns TRUE (1) if array all zeros,  *
** otherwise FALSE (0)                   *
**                                       *
** Parameters:                           *
**                                       *
**  x      Address of array x            *
**  l      Length of array x in bytes    *
**                                       *
******************************************/ 
int eqzero(BYTE *x, int l)
{
	while ( l-- )
		if ( x[l] != 0 )
			return 0;

	return 1;
}


/*****************************************
** equal - Test if arrays are equal      *
**                                       *
** Returns TRUE (1) if array all zeros,  *
** otherwise FALSE (0)                   *
**                                       *
** Parameters:                           *
**                                       *
**  x      Address of array x            *
**  y      Address of array y            *
**  l      Length of array x,y in bytes  *
**                                       *
******************************************/ 
int equal(BYTE *x, BYTE *y, int l)
{
	while ( l-- )
		if ( x[l] != y[l] )
			return 0;

	return 1;
}


/*****************************************
** greater - Test if x > y               *
**                                       *
** Returns TRUE (1) if x greater than y, *
** otherwise FALSE (0).                  *
**                                       *
** Parameters:                           *
**                                       *
**  x      Address of array x            *
**  y      Address of array y            *
**  l      Length both x and y in bytes  *
**                                       *
******************************************/ 
int greater(BYTE *x, BYTE *y, int l)
{
	int		i;

	for ( i=0; i<l; i++ )
		if ( x[i] != y[i] )
			break;

	if ( i == l )
		return 0;

	if ( x[i] > y[i] )
		return 1;

	return 0;
}


/*****************************************
** less - Test if x < y                  *
**                                       *
** Returns TRUE (1) if x less than y,    *
** otherwise FALSE (0).                  *
**                                       *
** Parameters:                           *
**                                       *
**  x      Address of array x            *
**  y      Address of array y            *
**  l      Length both x and y in bytes  *
**                                       *
******************************************/ 
int less(BYTE *x, BYTE *y, int l)
{
	int		i;

	for ( i=0; i<l; i++ )
		if ( x[i] != y[i] )
			break;

	if ( i == l ) {
		return 0;
	}

	if ( x[i] < y[i] ) {
		return 1;
	}

	return 0;
}


/*****************************************
** bshl - shifts array left              *
**                  by one bit.          *
**                                       *	
** x = x * 2                             *
**                                       *
** Parameters:                           *	
**                                       *
**  x      Address of array x            *
**  l      Length array x in bytes       *
**                                       *
******************************************/ 
BYTE bshl(BYTE *x, int l)
{
	BYTE	*p;
	int		c1, c2;

	p = x + l - 1;
	c1 = 0;
	c2 = 0;
	while ( p != x ) {
		if ( *p & 0x80 )
			c2 = 1;
		*p <<= 1;  /* shift the word left once (ls bit = 0) */
		if ( c1 )
			*p |= 1;
		c1 = c2;
		c2 = 0;
		p--;
	}

	if ( *p & 0x80 )
		c2 = 1;
	*p <<= 1;  /* shift the word left once (ls bit = 0) */
	if ( c1 )
		*p |= (DIGIT)1;

	return (BYTE)c2;
}


/*****************************************
** bshr - shifts array right             *
**                   by one bit.         *
**                                       *	
** x = x / 2                             *
**                                       *
** Parameters:                           *	
**                                       *
**  x      Address of array x            *
**  l      Length array x in bytes       *	
**                                       *
******************************************/
void bshr(BYTE *x, int l)	
{
	BYTE	*p;
	int		c1,c2;

	p = x;
	c1 = 0;
	c2 = 0;
	while ( p != x+l-1 ) {
		if ( *p & 0x01 )
			c2 = 1;
		*p >>= 1;  /* shift the word right once (ms bit = 0) */
		if ( c1 )
			*p |= 0x80;
		c1 = c2;
		c2 = 0;
		p++;
	}

	*p >>= 1;  /* shift the word right once (ms bit = 0) */
	if ( c1 )
		*p |= 0x80;
}


/*****************************************
** Random - Generate random integer      *
**                                       *
** A = 0 < RANDOM INTEGER < T            * 
**                                       *
** Parameters:                           *	
**                                       *
**  A      Address of the result         *
**  T      Address of the modulus        *
**                                       *
**  NOTE:  A MUST be L bytes in length   *
**                                       *
******************************************/
void Random(BYTE *A, BYTE *T, int L)
{
	int		i;

	do {
		for ( i=0; i<L; i++ )
			A[i] = (BYTE) (rand() >> 4);
		c2LH(A, L);

//		printf("before mod\n");
//		printBstr("A is ", A, L);
//		printBstr("T is ", T, L);
//		fflush(stdout);
		Mod(A, L, T, L);
//		printBstr("A is ", A, L);
//		printf("after mod\n");
	} while ( eqzero(A, L) );
}

void RandomOdd(BYTE *A, BYTE *T, int L)
{
	int		i;

	do {
		for (i=0;i<L;i++)
			A[i] = (BYTE)(rand() >> 4);

		/* make odd */
		A[L-1] |= 0x01;
		Mod(A, L, T, L);
	} while ( eqzero(A, L) );
}


/*****************************************
** Mult - Multiply two integers          *
**                                       *
** A = B * C                             *
**                                       *
** Parameters:                           *	
**                                       *
**  A      Address of the result         *
**  B      Address of the multiplier     *
**  C      Address of the multiplicand   *
**  LB      Length of B in bytes         *
**  LC      Length of C in bytes         *
**                                       *
**  NOTE:  A MUST be LB+LC in length     *
**                                       *
******************************************/
int Mult(BYTE *A, BYTE *B, int LB, BYTE *C, int LC)
{
	int		i, j, k, LA;
	DIGIT	result;

	LA = LB + LC;

	for ( i=LB-1; i>=0; i-- ) {
		result = 0;
		for ( j=LC-1; j>=0; j-- ) {
			k = i+j+1;
			result = (DIGIT)A[k] + ((DIGIT)(B[i] * C[j])) + (result >> 8);
			A[k] = (BYTE)result;
			}
		A[--k] = (BYTE)(result >> 8);
	}

	return 0;
}

//#define DEBUG_MODSQR
void ModSqr(BYTE *A, BYTE *B, int LB, BYTE *M, int LM)
{
#ifdef DEBUG_MODSQR
printBstr("ModSqr-in: B is ", B, LM);
printBstr("ModSqr-in: M is ", M, LM);
fflush(stdout);
#endif
	Square(A, B, LB);
#ifdef DEBUG_MODSQR
printBstr("Sqr-out: A is ", A, 2*LB);
fflush(stdout);
#endif
	Mod(A, 2*LB, M, LM);
#ifdef DEBUG_MODSQR
printBstr("ModSqr-out: A is ", A, 2*LM);
fflush(stdout);
#endif
	}

//#define DEBUG_MODMULT
void ModMult(BYTE *A, BYTE *B, int LB, BYTE *C, int LC, BYTE *M, int LM)
{
#ifdef DEBUG_MODMULT
printBstr("ModMult-in: B is ", B, LB);
printBstr("ModMult-in: C is ", C, LC);
printBstr("ModMult-in: M is ", M, LM);
#endif
	Mult(A, B, LB, C, LC);
#ifdef DEBUG_MODMULT
	printBstr("Mult-out: A is ", A, LB+LC);
#endif
	Mod(A, (LB+LC), M, LM);
#ifdef DEBUG_MODMULT
printBstr("ModMult-out: A is ", A, LB+LC);
#endif
	}


/*****************************************
** smult - Multiply array by a scalar.   *
**                                       *
** A = b * C                             *
**                                       *
** Parameters:                           *	
**                                       *
**  A      Address of the result         *
**  b      Scalar (1 DIGIT)              *
**  C      Address of the multiplicand   *
**  L      Length of C in bytes          *
**                                       *
**  NOTE:  A MUST be L+1 in length       *
**                                       *
******************************************/
void smult(BYTE *A, BYTE b, BYTE *C, int L)
{
	int		i;
	DIGIT	result;

	result = 0;
	for ( i=L-1; i>0; i-- ) {
		result = A[i] + ((DIGIT)b * C[i]) + (result >> 8);
		A[i] = (BYTE)(result & 0xff);
		A[i-1] = (BYTE)(result >> 8);
	}
}


/*****************************************
** Square() - Square an integer          *
**                                       *
** A = B^2                               *
**                                       *
** Parameters:                           *
**                                       *
**  A      Address of the result         *
**  B      Address of the operand        *
**  L      Length of B in bytes          *
**                                       *
**  NOTE:  A MUST be 2*L in length       *
**                                       *
******************************************/
void Square(BYTE *A, BYTE *B, int L)
{
	Mult(A, B, L, B, L);
}


/*****************************************
** ModExp - Modular Exponentiation       *
**                                       *
** A = B ** C (MOD M)                    *
**                                       *	
** Parameters:                           *	
**                                       *
**  A      Address of result             *
**  B      Address of mantissa           *
**  C      Address of exponent           *
**  M      Address of modulus            *
**  LB     Length of B in bytes          *
**  LC     Length of C in bytes          *
**  LM     Length of M in bytes          *
**                                       *
**  NOTE: The integer B must be less     *
**        than the modulus M.      	 *
**  NOTE: A must be at least 3*LM        *
**        bytes long.  However, the      *
**        result stored in A will be     *
**        only LM bytes long.            *
******************************************/
//#define DEBUG_MODEXP
void ModExp(BYTE *A, BYTE *B, int LB, BYTE *C, int LC, BYTE *M, int LM)
{
	BYTE	wmask;
	int		bits;

#ifdef DEBUG_MODEXP
printBstr("ModExp-in: B is ", B, LB);
printBstr("ModExp-in: C is ", C, LC);
printBstr("ModExp-in: M is ", M, LM);
printf("LB is <%d>, LC is <%d>, LM is <%d>\n", LB, LC, LM);
fflush(stdout);
#endif
	bits = LC*8;
	wmask = 0x80;

	A[LM-1] = 1;

	//printf("bits is <%d>\n", bits);
	while ( !sniff_bit(C,wmask) ) {
		wmask >>= 1;
		bits--;
		if ( !wmask ) {
			wmask = 0x80;
			C++;
		}
	}

	while ( bits-- ) {
#ifdef DEBUG_MODEXP
		printf("bits is <%d>\n", bits);
		printBstr("A is ", A, LM);
		fflush(stdout);
#endif
		bzero(A+LM, LM*2);

		/* temp = A*A (MOD M) */
		ModSqr(A+LM, A,LM,  M,LM);

		/* A = lower L bytes of temp */
		bcopy(A+LM*2, A,LM);
		bzero(A+LM, 2*LM);

		if ( sniff_bit(C,wmask) ) {
			bzero(A+LM, (LM+LB));
			ModMult(A+LM, B,LB, A,LM,  M,LM);       /* temp = B * A (MOD M) */
			bcopy(A+LM+(LM+LB)-LM, A, LM);  /* A = lower LM bytes of temp */
			bzero(A+LM, 2*LM);
		}
 
		wmask >>= 1;
		if ( !wmask ) {
			wmask = 0x80;
			C++;
		}
	}
#ifdef DEBUG_MODEXP
printBstr("ModExp-out: A is ", A, 3*LM);
fflush(stdout);
#endif
}


/* DivMod:
 *
 *   computes:
 *         quot = x / n
 *         rem = x % n
 *   returns:
 *         length of "quot"
 *
 *  len of rem is lenx+1
 */
//#define DEBUG_MOD
//#define DEBUG_MOD2
int DivMod(BYTE *x, int lenx, BYTE *n, int lenn, BYTE *quot, BYTE *rem)
{
	BYTE	*tx, *tn, *ttx, *ts, bmult[1];
	int		i, shift, lgth_x, lgth_n, t_len, lenq;
	DIGIT	tMSn, mult;
	ULONG	tMSx;
	int		count=0, underflow;
#ifdef DEBUG_MOD
FILE *fp;
fp = fopen("atest2.txt", "w");
#endif

	tx = x;
	tn = n;
#ifdef DEBUG_MOD
	fprintBstr(fp, "DivMod: X is ", tx, lenx); fflush(stdout);
	fprintBstr(fp, "DivMod: N is ", tn, lenn); fflush(stdout);
#endif
	
	/* point to the MSD of n  */
	for ( i=0, lgth_n=lenn; i<lenn; i++, lgth_n-- ) {
		if ( *tn )
			break;
		tn++;
	}
	if ( !lgth_n )
		return 0;
	
	/* point to the MSD of x  */
	for ( i=0, lgth_x=lenx; i<lenx; i++, lgth_x-- ) {
		if ( *tx )
			break;
		tx++;
	}
	if ( !lgth_x )
		return 0;

	if ( lgth_x < lgth_n )
		lenq = 1;
	else
		lenq = lgth_x - lgth_n + 1;
	bzero(quot, lenq);
	
	/* Loop while x > n,  WATCH OUT if lgth_x == lgth_n */
	while ( (lgth_x > lgth_n) || ((lgth_x == lgth_n) && !less(tx, tn, lgth_n)) ) {
#ifdef DEBUG_MOD
		if ( count++ > 130 ) {
			fprintf(fp, "leaving DIVMOD early\n"); fflush(stdout);
			fclose(fp);
			return 0;
		}
		fprintf(fp, "X length is <%d>\n", lgth_x); fflush(stdout);
		fprintBstr(fp, "top loop: X is ", tx, lgth_x); fflush(stdout);
#endif
		
		shift = 1;
		//if ( (*tx > *tn) && ((*tn != 0x01) || (lgth_n == 1)) ) {
		if ( lgth_n == 1 ) {
			if ( *tx < *tn ) {
				tMSx = (DIGIT) (((*tx) << 8) | *(tx+1));
				tMSn = *tn;
				shift = 0;
			}
			else {
				tMSx = *tx;
				tMSn = *tn;
			}
		}
		else if ( lgth_n > 1 ) {
			tMSx = (DIGIT) (((*tx) << 8) | *(tx+1));
			tMSn = (DIGIT) (((*tn) << 8) | *(tn+1));
			if ( (tMSx < tMSn) || ((tMSx == tMSn) && less(tx, tn, lgth_n)) ) {
				tMSx = (tMSx << 8) | *(tx+2);
				shift = 0;
			}
		}
		else {
			tMSx = (DIGIT) (((*tx) << 8) | *(tx+1));
			tMSn = *tn;
			shift = 0;
		}

		mult = (DIGIT) (tMSx / tMSn);
#ifdef DEBUG_MOD
		fprintf(fp, "tMSx is <%04x>\n", tMSx); fflush(stdout);
		fprintf(fp, "tMSn is <%04x>\n", tMSn); fflush(stdout);
		fprintf(fp, "mult is <%04x>\n", mult); fflush(stdout);
#endif
		if ( mult > 0xff )
			mult = 0xff;
		bmult[0] = mult & 0xff;

		ts = rem;
		do {
#ifdef DEBUG_MOD2
			fprintBstr(fp, "tn is ", tn, lgth_n); fflush(stdout);
			fprintBstr(fp, "bmult is ", bmult, 1); fflush(stdout);
#endif
			bzero(ts, lgth_x+1);
			Mult(ts, tn, lgth_n, bmult, 1);
#ifdef DEBUG_MOD2
			fprintBstr(fp, "mult-out1: ts is ", ts, lgth_x+1); fflush(stdout);
			fprintBstr(fp, "quot-after mult is ", quot, lenq); fflush(stdout);
#endif

			underflow = 0;
			if ( shift ) {
				if ( ts[0] != 0 )
					underflow = 1;
				else {
					for ( i=0; i<lgth_x; i++ )
						ts[i] = ts[i+1];
					ts[lgth_x] = 0x00;
				}
#ifdef DEBUG_MOD2
				fprintBstr(fp, "shifting: ts is ", ts, lgth_x+1); fflush(stdout);
#endif
			}
			if ( greater(ts, tx, lgth_x) || underflow ) {
				bmult[0]--;
				underflow = 1;
			}
			else
				underflow = 0;
		} while ( underflow );
#ifdef DEBUG_MOD
		fprintf(fp, "final bmult value is <%02x>\n", bmult[0]); fflush(stdout);
		fprintBstr(fp, "before sub: ts is ", ts, lgth_x); fflush(stdout);
		fprintBstr(fp, "quot-before sub is ", quot, lenq); fflush(stdout);
#endif
		sub(tx, lgth_x, ts, lgth_x);

		if ( shift )
			quot[lenq - (lgth_x - lgth_n) - 1] = bmult[0];
		else
			quot[lenq - (lgth_x - lgth_n)] = bmult[0];
		
		ttx = tx;
		t_len = lgth_x;
		for ( i=0, lgth_x=t_len; i<t_len; i++, lgth_x-- ) {
			if ( *ttx )
				break;
			ttx++;
		}
		tx = ttx;
#ifdef DEBUG_MOD2
		fprintf(fp, "lgth_x is <%d>\n", lgth_x); fflush(stdout);
		fprintBstr(fp, "bottom loop: X is ", tx, lgth_x); fflush(stdout);
		fprintBstr(fp, "quot is ", quot, lenq); fflush(stdout);
#endif
	}
	bzero(rem, lenn);
	if ( lgth_x )
		bcopy(tx, rem+lenn-lgth_x, lgth_x);

#ifdef DEBUG_MOD
	fprintBstr(fp, "quot is ", quot, lenq); fflush(stdout);
	fprintBstr(fp, "rem is ", rem, lenn); fflush(stdout);
	fclose(fp);
#endif
	return lenq;
}


/* 
 * Mod - Computes an integer modulo another integer
 *
 * x = x (mod n)
 *
 */
void Mod(BYTE *x, int lenx, BYTE *n, int lenn)
{
	BYTE	quot[MAXPLEN+1], rem[2*MAXPLEN+1];

	bzero(quot, sizeof(quot));
	bzero(rem, sizeof(rem));
	if ( DivMod(x, lenx, n, lenn, quot, rem) ) {
//		fprintBstr(fp, "in Mod: quot is ", quot, MAXPLEN+1);
//		fprintBstr(fp, "in Mod: rem is ", rem, lenn);
//		fprintBstr(fp, "in Mod: x-before bzero is ", x, lenx);
		bzero(x, lenx);
//		fprintBstr(fp, "in Mod: x-after bzero is ", x, lenx); fflush(stdout);
//		fprintf(fp, "lenx is <%d>, lenn is <%d>\n", lenx, lenn);
		bcopy(rem, x+lenx-lenn, lenn);
//		fprintBstr(fp, "in Mod: x-after copy is ", x, lenx); fflush(stdout);
	}
}

/* 
 * Div - Computes the integer division of two numbers
 *
 * x = x / n
 *
 */
void Div(BYTE *x, int lenx, BYTE *n, int lenn)
{
	BYTE	quot[MAXPLEN+1], rem[2*MAXPLEN+1];
	int		lenq;

	bzero(quot, sizeof(quot));
	bzero(rem, sizeof(rem));
	if ( lenq = DivMod(x, lenx, n, lenn, quot, rem) ) {
		bzero(x, lenx);
		bcopy(quot, x+lenx-lenq, lenq);
	}
}


int InvPrimeField(BYTE *Kinv, BYTE *K, int lenk, BYTE *Q, int lenq)
{
	BYTE	Qminus2[MAXQLEN], Two[MAXQLEN];

	bcopy(Q, Qminus2, lenq);
	bzero(Two, lenq);
	Two[lenq-1] = 0x02;
	sub(Qminus2, lenq, Two, lenq);

	bzero(Kinv, lenk*3);
	ModExp(Kinv, K, lenk, Qminus2, lenq, Q, lenq);
	return 0;
}

int	InvExtEuclid(BYTE *D, BYTE *Ain, BYTE *Bin, int len)
{
	BYTE	A[MAXQLEN], B[MAXQLEN], X[MAXQLEN], Y[MAXQLEN],
			X1[MAXQLEN], Y1[MAXQLEN], X2[MAXQLEN], Y2[MAXQLEN],
			Q[2*MAXQLEN], R[MAXQLEN], Temp[2*MAXQLEN], Zero[MAXQLEN];
	int		counter = 0;

	bzero(D, len);
	bzero(X, len);
	bzero(Y, len);
	if ( eqzero(Bin, len) ) {
		bcopy(Ain, D, len);
		X[len-1] = 0x01;
		return 0;
	}

	bzero(X1, len);
	bzero(Y1, len);
	bzero(X2, len);
	bzero(Y2, len);
	X2[len-1] = 0x01;
	Y1[len-1] = 0x01;

	bcopy(Ain, A, len);
	bzero(B, len);
	bcopy(Bin, B, len);
	bzero(Zero, len);
	while ( greater(B, Zero, len) ) {
		bcopy(A, Q, len);
		Div(Q, len, B, len);
		bzero(Temp, len*2);
		Mult(Temp, Q, len, B, len);
		bcopy(A, R, len);
		sub(R, len, Temp+len, len);

		bzero(Temp, len*2);
		Mult(Temp, Q, len, X1, len);
		Mod(Temp, 2*len, Ain, len);
		bcopy(X2, X, len);
		sub(X, len, Temp+len, len);
		if ( less(X2, X, len) )
			add(X, len, Ain, len);
		
		bzero(Temp, len*2);
		Mult(Temp, Q, len, Y1, len);
		Mod(Temp, 2*len, Ain, len);
		bcopy(Y2, Y, len);
		sub(Y, len, Temp+len, len);
		if ( less(Y2, Y, len) )
			add(Y, len, Ain, len);

		bcopy(B, A, len);
		bcopy(R, B, len);
		bcopy(X1, X2, len);
		bcopy(X, X1, len);
		bcopy(Y1, Y2, len);
		bcopy(Y, Y1, len);
	}

	bcopy(Y2, D, len);
	return 0;
}

/*  ExtEuclidAlg:
		Ain, Bin:	The two input values.  Ain must be >= Bin (not the length
					but the acutal value)
		Dout:		Returns the GCD(Ain, Bin)
		Xout, Yout:	For the most part these are junk.  If Dout == 1 then
					Yout = Bin^-1 (mod Ain).  That Yout = Inv(Bin) mod Ain.
		len:		The length of all of Ain, Bin, Dout, Xout, and Yout in bytes.
*/
int	ExtEuclidAlg(BYTE *Ain, BYTE *Bin, BYTE *Dout, BYTE *Xout, BYTE *Yout, int len)
{
	BYTE	A[MAXPLEN], B[MAXPLEN], Temp[2*MAXPLEN], Zero[MAXPLEN],
			X1[MAXPLEN], Y1[MAXPLEN], X2[MAXPLEN], Y2[MAXPLEN],
			Q[2*MAXPLEN], R[MAXPLEN];
	int		counter = 0;

	bzero(Dout, len);
	bzero(Xout, len);
	bzero(Yout, len);
	if ( eqzero(Bin, len) ) {
		bcopy(Ain, Dout, len);
		Xout[len-1] = 0x01;
		return 0;
	}

	bzero(X1, len);
	bzero(Y1, len);
	bzero(X2, len);
	bzero(Y2, len);
	X2[len-1] = 0x01;
	Y1[len-1] = 0x01;

	bzero(A, len);
	bcopy(Ain, A, len);
	bzero(B, len);
	bcopy(Bin, B, len);
	bzero(Zero, len);
	while ( greater(B, Zero, len) ) {
		bcopy(A, Q, len);
		Div(Q, len, B, len);
		bzero(Temp, len*2);
		Mult(Temp, Q, len, B, len);
		bcopy(A, R, len);
		sub(R, len, Temp+len, len);

		bzero(Temp, len*2);
		Mult(Temp, Q, len, X1, len);
		Mod(Temp, 2*len, Ain, len);
		bcopy(X2, Xout, len);
		sub(Xout, len, Temp+len, len);
		if ( less(X2, Xout, len) )
			add(Xout, len, Ain, len);
		
		bzero(Temp, len*2);
		Mult(Temp, Q, len, Y1, len);
		Mod(Temp, 2*len, Ain, len);
		bcopy(Y2, Yout, len);
		sub(Yout, len, Temp+len, len);
		if ( less(Y2, Yout, len) )
			add(Yout, len, Ain, len);

		bcopy(B, A, len);
		bcopy(R, B, len);
		bcopy(X1, X2, len);
		bcopy(Xout, X1, len);
		bcopy(Y1, Y2, len);
		bcopy(Yout, Y1, len);
	}

	bcopy(A, Dout, len);
	bcopy(X2, Xout, len);
	bcopy(Y2, Yout, len);

	return 0;
}


/*****************************************
** sub - Subtract two integers           *
**                                       *
** A = A - B                             *
**                                       *
**                                       *
** Parameters:                           *	
**                                       *
**  A      Address of subtrahend integer *
**  B      Address of subtractor integer *
**  L      Length of A and B in bytes    *
**                                       *
**  NOTE: In order to save RAM, B is     *
**        two's complemented twice,      *
**        rather than using a copy of B  *
**                                       *
******************************************/
void sub(BYTE *A, int LA, BYTE *B, int LB)
{
	BYTE	*tb;
#ifdef DEBUG_PARMS
printBstr("Sub-in: A is ", A, LA);
printBstr("Sub-in: B is ", B, LB);
#endif

	tb = (BYTE *)calloc(LA, 1);
	bcopy(B, tb, LB);
	negate(tb, LB);

	/* Add negative B to A (to do the subtraction) */
	add(A, LA, tb, LA);

	FREE(tb);

#ifdef DEBUG_PARMS
printBstr("Sub-out: A is ", A, LA);
#endif
}


/*****************************************
** negate - Negate an integer            *
**                                       *
** A = -A                                *
**                                       *
**                                       *
** Parameters:                           *	
**                                       *
**  A      Address of integer to negate  *
**  L      Length of A in bytes          *
**                                       *
******************************************/
int negate(BYTE *A, int L)
{
	int		i, tL;
	DIGIT	accum;

#ifdef DEBUG_PARMS
printBstr("Negate-in: A is ", A, L);
#endif
	/* Take one's complement of A */
	for ( i=0; i<L; i++ )
		A[i] = ~(A[i]);

	/* Add one to get two's complement of A */
	accum = 1;
	tL = L-1;
	while ( accum && (tL >= 0) ) {
		accum += A[tL];
		A[tL--] = (BYTE)(accum & 0xff);
		accum = accum >> 8;
	}

#ifdef DEBUG_PARMS
printBstr("Negate-out: A is ", A, L);
#endif
	return accum;
}


/*
 * add()
 *
 * A = A + B
 *
 * LB must be <= LA
 *
 */
BYTE add(BYTE *A, int LA, BYTE *B, int LB)
{
	int		i, indexA, indexB;
	DIGIT	accum;

#ifdef DEBUG_PARMS
printBstr("Add-in: A is ", A, LA);
printBstr("Add-in: B is ", B, LB);
#endif
	indexA = LA - 1; 	/* LSD of result */
	indexB = LB - 1; 	/* LSD of B */

	accum = 0;
	for ( i = 0; i < LB; i++ ) {
		accum += A[indexA];
		accum += B[indexB--];
		A[indexA--] = (BYTE)(accum & 0xff);
		accum = accum >> 8;
	}

	if ( LA > LB )
		while ( accum  && (indexA >= 0) ) {
			accum += A[indexA];
			A[indexA--] = (BYTE)(accum & 0xff);
			accum = accum >> 8;
		}

#ifdef DEBUG_PARMS
printBstr("Add-out: A is ", A, LA);
#endif
	return (BYTE)accum;
}


/*
 * IsPrime() - Test for primality
 *
 * Implementation of probabalistic algorithm
 * given in Appendix 2 of the DSS.
 * 
 *
 * Returns 1 if W (an L byte integer) is prime
 * otherwise a 0 is returned
 *
 * Each iteration reduces the probability of error
 * by 1/4.  (Eg.  50 iterations gives a error 
 * probability of 1/4^50)
 *
 * PSEUDOCODE:
 *
 * INPUTS: W - ODD INTEGER TO BE TESTED
 *         L - LENGTH OF W IN BYTES
 *
 * N = 50
 * WMIN1 = W - 1
 * P = 2
 * A = 1
 *
 * DO
 *   A = A + 1
 *   P = P * 2
 *   X = WMIN1 MOD P
 * WHILE (X = 0)
 *
 * P = P/2
 * A = A-1
 * M = WMIN1 DIV P 
 * 
 * FOR (I = 1 TO N)
 * BEGIN
 *   B = RANDOM INTEGER IN (1,W)
 *   J = 0
 *   Z = B^M MOD W
 *   IF (J = 0 AND Z = 1) OR (Z = WMIN1)
 *	CONTINUE
 *STEP6:
 *   IF (J > 0 AND Z = 1) 
 *      RETURN(FALSE)
 *   J = J + 1
 *   IF (J < A)
 *      Z = Z^2 MOD W
 *      GOTO STEP5
 *   RETURN(FALSE)
 * END
 *
 * RETURN(TRUE)
 *
 */
//#define DEBUG_ISPRIME
int IsPrime(BYTE *W, int L, int iter)
{
	static BYTE	M[3*MAXPLEN],
				P[3*MAXPLEN],
				X[3*MAXPLEN],
				B[3*MAXPLEN],
				Z[3*MAXPLEN],
				WMIN1[3*MAXPLEN],
				ONE[3*MAXPLEN],
				JUNK[3*MAXPLEN];
	int		i, n=iter, a=1, j;

#ifdef DEBUG_ISPRIME
FILE *fp;
fp = fopen("atest9.txt", "w");

fprintf(fp, "enter IsPrime()\n"); fflush(fp);
#endif
	bzero(ONE, L);
	ONE[L-1] = 1;

	bzero(P, L);
	P[L-1] = 2;

	bcopy(W, WMIN1, L);
	sub(WMIN1, L, ONE, L);

	bzero(X, L);
	bzero(M, L);
	bzero(B, L);
	bzero(Z, 3*L);
	bzero(JUNK, 2*L);

	do {
		a++;
		bshl(P, L);
		bcopy(WMIN1, X, L);
		Mod(X, L, P, L);
#ifdef DEBUG_ISPRIME
fprintf(fp, "in first loop\n"); fflush(fp);
#endif
	} while ( eqzero(X,L) );

	bshr(P, L);

	a--;

	bcopy(WMIN1, X, L);
	Div(X, L, P, L);
	bcopy(X, M, L);

	/* DOUBLE CHECK MOD, DIV, MULT, AND ADD FOR DEBUGGING*/
	bzero(JUNK, 2*L);

	Mult(JUNK, P, L, M, L);
	add(JUNK, 2*L, ONE, L);

	for ( i=0; i<n; i++ ) {
#ifdef DEBUG_ISPRIME
fprintf(fp, "i is <%d>\n", i); fflush(fp);
#endif
		/* step 3 */
		Random(B, W, L);

		/* step 4 */
		j=0;
		bzero(Z, 3*L);

#ifdef DEBUG_ISPRIME
fprintf(fp, "Before Mod Exp\n"); fflush(fp);
#endif
		ModExp(Z, B,L, M,L, W,L);
#ifdef DEBUG_ISPRIME
fprintf(fp, "After Mod Exp\n"); fflush(fp);
#endif

		/* step 5 */
		do {
#ifdef DEBUG_ISPRIME
fprintf(fp, "Do loop\n"); fflush(fp);
#endif
			if ( ( (j == 0) && equal(Z, ONE, L)) ||
				equal(Z, WMIN1, L) ) {
				break;  /* out of the do-while loop */
			}

			/* step 6 */
			if ( j>0 && equal(Z, ONE, L) ) {
				return 0; /* NOT PRIME */
			}

			/* step 7 */
			j++;

			if (j < a) {
				bzero(JUNK, 2*L);
				ModSqr(JUNK, Z, L, W, L);
				bcopy(JUNK+L, Z, L);

				continue;  /* the do-while loop  */
			}

			return 0; /* NOT PRIME */

		} while ( 1 );
	}

	return 1; /* IS PRIME */
}


void GenPrime(int datetime, BYTE *Q, int len)
{
	BYTE	N[44],
			U[64],
			L[64],
			T[66],
			ONE[sizeof(DIGIT)],
			ONE_[64],
			TWO[sizeof(DIGIT)];

	int		result;

	bzero(ONE_,64);
	ONE_[63] = 1;
	bzero(ONE,sizeof(DIGIT));
	ONE[sizeof(DIGIT)-1] = (BYTE)0x01;
	bzero(TWO,sizeof(DIGIT));
	TWO[sizeof(DIGIT)-1] = (BYTE)0x02;

	/* Generate N, a len byte random integer in [L,U) to be tested for primality*/
	srand(datetime);
  
	/* L = 2^(len*8-2) */
	bzero(L, len);
	L[0] = (BYTE)0x40;

	/* U = 2^(len*8-1) */
	bzero(U, len);
	U[0] = (BYTE)0x80;

	/* step 1 */
	Random(N, U, len);
	while ( less(N, L, len) )
		Random(N, U, len);

	/* step2&3: Set T = 2N + 1 */
	bcopy(N, T, len);
	result = bshl(T,len);
	add(T, len, ONE, sizeof(DIGIT));

	/* step4 */
step4:
	if (result=IsPrime(T, len, 40))
		/* set Q = T */
		bcopy(T, Q, len);
	else {
		add(T, len, TWO, sizeof(DIGIT));
		goto step4;
		}
	} /* end GenPrime */


/**************************************************************************

        This is a simplified version of the Chinese Remainder Theorem as
        it is applied to only to values, say, p and q which are generally
        primes (hence the requirement of relative primeness of inputs is
        assured). 

	It is the version which applies directly to the alleged optimal
        decryption in RSA.

	Inputs : p, q, qinv, res mod p = dp   and   res mod q = dq.
        Returns : res mod n.

	Assumptions : 
 	       * The lengths of p and q (and hence dp and dq) are assumed to be the 
                 same. So the length of n is twice the lengths of p,q.
	       * res is located at RAM[0].

	Note : The values of dp and dq are altered by the function.

***************************************************************************/
void CRT(BYTE *res, BYTE *c, BYTE *p, BYTE *q, BYTE *u, BYTE *d,
		 BYTE *dpm1, BYTE *dqm1, int lenn)
{
	int		lenp;

	lenp = lenn/2;

	/* Compute C mod P and C mod Q. */
	bcopy(c, res, lenn);
	Mod(res, lenn, p, lenp);
	bcopy(&res[lenp], CP, lenp);
	bcopy(c, res, lenn);
	Mod(res, lenn, q, lenp);
	bcopy(&res[lenp], CQ, lenp);

	/* Compute the values DP = CP^dpm1 mod p and DQ = CQ^dqm1 mod q */
	bzero(res,3*lenp);
	ModExp(res, CP, lenp, dpm1, lenp, p, lenp);
	bcopy(res, DP, lenp);
	bzero(res,3*lenp);
	ModExp(res, CQ, lenp, dqm1, lenp, q, lenp);
	bcopy(res, DQ, lenp);

	/* Compute DQ mod p and store in res. */
	bcopy(DQ,res,lenp);
	Mod(res, lenp, p, lenp);

	/* Compute DP - DQ mod p. Store in res + lenn. */
	if ( less(DP, res, lenp) ) {
		bcopy(p,res + lenn,lenp);
		sub(res + lenn, lenp, res, lenp);
		add(res + lenn, lenp, DP, lenp);
		}
	else {
		bcopy(DP, res + lenn, lenp);
		sub(res + lenn, lenp, res, lenp);
		}

	/* Compute u*(DP-DQ mod p) mod p.
	   Result at res + lenp. */
	bzero(res, lenn);	
	ModMult(res, u, lenp, res + lenn, lenp, p, lenp);

	/* Compute q*(u*(DP-DQ mod p)). */
	bcopy(res + lenp, res + lenn, lenp);
	bzero(res,lenn);
	Mult(res, q, lenp, res + lenn, lenp);

	/* Compute x. */
	add(res, lenn, DQ, lenp);
	} /* END CRT */


/*****************************************
** xor - xor one array into another      *
**                                       *
** Parameters:                           *
**                                       *
**  x      Address of array x            *
**  y      Address of array y            *
**  l      Amount of bytes to copy       *
**                                       *
******************************************/
void xor(BYTE *A, BYTE *x, BYTE *y, int l)
{
	while (l--)
		A[l] = x[l] ^ y[l];
}


void printBstr(char *S, BYTE *A, int L)
{
	int		i;

	printf("%s", S);

	for ( i=0; i<L; i++ ) {
//		if ( i && !(i % 4) )
//			printf(" ");
		printf("%02x", A[i]);
	}
	if ( L == 0 )
		printf("00");
	printf("\n");
}


void fprintBstr(FILE *fp, char *S, BYTE *A, int L)
{
	int		i;

	fprintf(fp, "%s", S);

	for ( i=0; i<L; i++ ) {
//		if ( i && !(i % 4) )
//			fprintf(fp, " ");
		fprintf(fp, "%02x", A[i]);
	}
	if ( L == 0 )
		fprintf(fp, "00");
	fprintf(fp, "\n");
}

void sprintBstr(char *S, BYTE *A, int L)
{
	int		i;
	char	digbuf[3];

	*S = '\0';

	for (i=0; i<L; i++) {
       	sprintf(digbuf, "%02x", A[i]);
		strncat(S, digbuf, 2);
	}
	if ( L == 0 )
		strncat(S, "00", 2);
}


void printInt(char *S, BYTE *A, int L)
{
	BYTE	Ten[1], *B;
	char	str[HEXTODECSTRLEN];
	int		sindex;

	sindex = HEXTODECSTRLEN-1;
	str[sindex--] = '\0';

	Ten[0] = 0x0a;
	B = (BYTE *)calloc(L, 1);

	printf("%s", S);

	do {
		bcopy(A, B, L);
		Mod(B, L, Ten, 1);
		str[sindex--] = B[L-1] + '0';
		Div(A, L, Ten, 1);
	} while ( (sindex >= 0) && !eqzero(A, L) );
	printf("%s\n", str+sindex+1);
}


void fprintInt(FILE *fp, char *S, BYTE *A, int L)
{
	BYTE	Ten[1], *B;
	char	str[HEXTODECSTRLEN];
	int		sindex;

	sindex = HEXTODECSTRLEN-1;
	str[sindex--] = '\0';

	Ten[0] = 0x0a;
	B = (BYTE *)calloc(L, 1);

	fprintf(fp, "%s", S);

	do {
		bcopy(A, B, L);
		Mod(B, L, Ten, 1);
		str[sindex--] = B[L-1] + '0';
		Div(A, L, Ten, 1);
	} while ( (sindex >= 0) && !eqzero(A, L) );
	fprintf(fp, "%s\n", str+sindex+1);
}


void freadnum(FILE *fp, BYTE *A, int L)
{
	int i;
	unsigned int b;

	for ( i=0; i<L; i++ ) {
		fscanf(fp, "%2x", &b);
		A[i] = (BYTE)b;
	}
}


/*******************************************************/
/** bshrULONG - shifts array right by one bit.         */
/**                                                    */
/** x = x / 2                                          */
/**                                                    */
/** Parameters:                                        */
/**                                                    */
/**  x      Address of array x                         */
/**  len    Length array x in ULONGs                   */
/*******************************************************/
void bshrULONG(ULONG *x, int len)
{
	ULONG	*p;
	int		c1,c2;

	p = x;
	c1 = 0;
	c2 = 0;
	while (p != x+len-1) {
		if (*p & (ULONG)LSBITNULONG)
			c2 = 1;
		*p >>= 1;  /* shift the word right once (ms bit = 0) */
		if (c1)
			*p |= (ULONG)MSBITNULONG;
		c1 = c2;
		c2 = 0;
		p++;
		}
	*p >>= 1;  /* shift the word right once (ms bit = 0) */
	if (c1)
		*p |= (ULONG)MSBITNULONG;
	}


void ROT_WORD64(WORD64 retval, WORD64 X, int Y)
{
	int		dist;

	if ( Y <= 32 ) {
		retval[0] = ((X[0]>>Y) | (X[1] << (32-Y)));
		retval[1] = ((X[1]>>Y) | (X[0] << (32-Y)));
		}
	else {
		dist = 64 - Y;
		retval[0] = ((X[0]<<dist) | (X[1]>>(32-dist)));
		retval[1] = ((X[1]<<dist) | (X[0]>>(32-dist)));
		}
	}

void add_WORD64(WORD64 X, WORD64 Y)
{
	if ( (X[1] + Y[1]) < X[1] )
		X[0]++;
	X[1] += Y[1];
	X[0] += Y[0];
	}


/**********************************************************************/
/*  Performs byte reverse for PC based implementation (little endian) */
/*     len in ULONGs                                                  */
/**********************************************************************/
void byteReverse64(WORD64 *buffer, int len)
{
	ULONG	value;
	int		count;

	for( count = 0; count < len; count++ ) {
		value = ( buffer[ count ][0] << 16 ) | ( buffer[ count ][0] >> 16 );
		buffer[ count ][0] = ( ( value & 0xFF00FF00L ) >> 8 ) | ( ( value & 0x00FF00FFL ) << 8 );
		value = ( buffer[ count ][1] << 16 ) | ( buffer[ count ][1] >> 16 );
		buffer[ count ][1] = ( ( value & 0xFF00FF00L ) >> 8 ) | ( ( value & 0x00FF00FFL ) << 8 );
		}
	}

/**********************************************************************/
/*  Performs byte reverse for PC based implementation (little endian) */
/**********************************************************************/
void byteReverse(ULONG *buffer, int byteCount)
{
	ULONG value;
	int count;

	byteCount /= sizeof( ULONG );
	for( count = 0; count < byteCount; count++ ) {
		value = ( buffer[ count ] << 16 ) | ( buffer[ count ] >> 16 );
		buffer[ count ] = ( ( value & 0xFF00FF00L ) >> 8 ) | ( ( value & 0x00FF00FFL ) << 8 );
		}
	}

void ROTL_ULONGS(ULONG *buffer, int wordcount)
{
	int		i;
	ULONG	temp;

	temp = buffer[0];
	for ( i=0; i<wordcount-1; i++ )
		buffer[i] = buffer[i+1];
	buffer[wordcount-1] = temp;
	}


int   getbitsize(BYTE *val, int bitlen)
{
	int		i, high_bit;
	BYTE	mask;

	for ( i=0; i<bitlen; i++ ) {
		if ( (i % 8) == 0 )
			mask = 0x01;
		else
			mask <<= 1;
		if ( val[i/8] & mask )
			high_bit = i+1;
	}

	return high_bit;
}

void initMP(MP *mp)
{
	mp->bitlen = 0;
	mp->size = 0;
	mp->val = NULL;
}

void allocMP(MP *mp, int bitlen)
{
	mp->bitlen = bitlen;
	mp->size = (bitlen+7)/8;
	if ( mp->val )
		free(mp->val);
	mp->val = (BYTE *)calloc(mp->size, 1);
}

void freeMP(MP *mp)
{
	mp->bitlen = 0;
	mp->size = 0;
	FREE(mp->val);
}

void GenRand(BYTE *val, int len)
{
	int		i;
	time_t	hld_time;

	if ( len == 0 )
		val[0] = 0x00;
	else {
		/* Seed the random-number generator with current time so that
		 * the numbers will be different every time we run.    */
		hld_time = time(NULL);
		srand(hld_time^rand());

		for (i=0; i<len; i++)
			val[i] = rand() & 0xff;
	}
}

char *time_str()
{
	struct tm *newtime;
    time_t long_time;
	
    time( &long_time );
    newtime = localtime( &long_time );

	return asctime(newtime);
}


void c2LH(BYTE *n, int l)
{
	BYTE	TEMP;
	int		i;

	for (i=0;i<l;i+=2) {
		TEMP=n[i+1];
		n[i+1]=n[i];
		n[i]=TEMP;
	}
}


void cLONG2DIGITS(DIGIT *n)
{
	DIGIT temp;

	temp=n[0];
	n[0]=n[1];
	n[1]=temp;
}


void cDIGITS2LONG(DIGIT *n)
{
	DIGIT temp;

	temp=n[0];
	n[0]=n[1];
	n[1]=temp;
}

/*
** ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
*/
int FindMarker(FILE *infile, char *marker)
{
	char	line[50];
	int		i, len;

	len = strlen(marker);

	for ( i=0; i<len; i++ )
		if ( (line[i] = fgetc(infile)) == EOF )
			return 0;
	line[len] = '\0';

	while ( 1 ) {
		if ( !strncmp(line, marker, len) )
			return 1;

		for ( i=0; i<len-1; i++ )
			line[i] = line[i+1];
		if ( (line[len-1] = fgetc(infile)) == EOF )
			return 0;
		line[len] = '\0';
	}

	/* shouldn't get here */
	return 0;
}

/*
** ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
*/
int ReadHex(FILE *infile, BYTE *A, int Length, char *str)
{
/*
	char	ch1, ch2;
	int		j;

	if ( FindMarker(infile, str) )
		for ( j=0; j<Length; j++ ) {
			if ( (ch1 = fgetc(infile)) == EOF )
				return 0;
			if ( (ch2 = fgetc(infile)) == EOF )
				return 0;
			A[j] = ((ASCII2BIN(ch1) << 4) & 0xf0) | (ASCII2BIN(ch2) & 0x0f);
		}
	else
		return 0;

	return 1;
*/
	int		i, ch, started;
	BYTE	ich;

	bzero(A, Length);
	started = 0;
	if ( FindMarker(infile, str) )
		while ( (ch = fgetc(infile)) != EOF ) {
			if ( !isxdigit(ch) ) {
				if ( !started ) {
					if ( ch == '\n' )
						break;
					else
						continue;
				}
				else
					break;
			}
			started = 1;
			if ( (ch >= '0') && (ch <= '9') )
				ich = ch - '0';
			else if ( (ch >= 'A') && (ch <= 'F') )
				ich = ch - 'A' + 10;
			else if ( (ch >= 'a') && (ch <= 'f') )
				ich = ch - 'a' + 10;
			
			for ( i=0; i<Length-1; i++ )
				A[i] = (A[i] << 4) | (A[i+1] >> 4);
			A[Length-1] = (A[Length-1] << 4) | ich;
		}
	else
		return 0;

	return 1;

}

/*
** ALLOW TO READ DECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
*/
int ReadInt(FILE *infile, BYTE *A, int Length, char *str)
{
	char	ch;
	BYTE	Ten[2], Tmp[2], *Mem;

	/* set Ten to the value of 10 */
	bzero(Ten, 2);
	Ten[1] = 0x0a;

	bzero(A, Length);
	bzero(Tmp, 2);
	Mem = (BYTE *)malloc(Length+2);
	if ( FindMarker(infile, str) )
		while ( (ch = fgetc(infile)) != EOF ) {
			if ( !isdigit(ch) )
				break;
			Tmp[1] = ch - '0';
			bzero(Mem, Length+2);
			Mult(Mem, A, Length, Ten, 2);
			add(Mem, Length+2, Tmp, 2);
			bcopy(Mem+2, A, Length);
		}
	else
		return 0;

	return 1;
}


/* computes n = (2^e)*a1 */
int expmult(BYTE *n, int LN)
{
	int zerocnt = 0;

	while ((n[LN-1] & 0x01) == 0) {
		zerocnt++; 
		bshr(n,LN); //n>>1
	}

	return(zerocnt);
}

/* This routine is designed to handle N of integral bytes*/
int Jacobi(BYTE *aorig, int lenA, BYTE *norig, int lenN)
{
	int	e, s;
	MP	One, a, n;


	initMP(&(a));
	allocMP(&a,lenA*8);
	bcopy (aorig, a.val, a.size);

	initMP(&(n));
	allocMP(&n,lenN*8);
	bcopy (norig, n.val, n.size);
	/* first step is to reduce a mod n so that 0 <= a < n*/
	Mod(a.val, a.size, n.val, n.size);
	
	initMP(&One);
	allocMP(&One, a.bitlen);
	One.val[One.size-1] = 0x01;
	if ( equal( a.val, One.val, a.size) )
		return(1);
	freeMP(&One);

	initMP(&One);
	allocMP(&One, n.bitlen);
	One.val[One.size-1] = 0x01;
	if ( equal( n.val, One.val, n.size) )
		return(1);
	freeMP(&One);

	if ( eqzero( a.val,a.size))
		return(0);

	e = expmult(a.val, a.size); //a will be a1 on return
	/* on return e = number of trailing zeros
	             a = a1 = number left after shifting number over e times
				 example 8 = 1000 so e = 3 and a1 = 1
				 */

	/* if e is even set s = 1*/
	if ( e % 2 == 0)
		s = 1;
	else { /*if n=1mod8 or n=7mod8, set s = 1*/
		if ( ((n.val[n.size-1]%8) == 0x01) || ((n.val[n.size-1]%8) == 0x07) )
			s = 1;
		else {   /*if n=3mod8 or n=5mod8, set s = -1*/
			if ( ((n.val[n.size-1]%8) == 0x03) || ((n.val[n.size-1]%8) == 0x05) )
				s = -1;
		}
	}

	/*if n=3mod4 and a1=3mod4, set s = -s*/
	if ( ((n.val[n.size-1] % 4) == 3) && ((a.val[a.size-1] % 4) == 3) )
		s=-s;

	/*n  becomes n1  n1=n mod a1*/
	Mod(n.val, n.size,  a.val, a.size);

	return(s * (Jacobi(n.val, n.size, a.val, a.size)));
}


/* This routine is designed to handle N of integral bytes*/
int LucasPrime(BYTE *N, int lenN)
{
	MP		D, K, U, V, temp, newU, newV;
	BYTE	TWO[1];
	int		maxlenbit, i, r, Jacobi_answ, num, flag;
	
	int		Dsign = 0;	// 0 = positive, 1 = negative

	maxlenbit = (lenN+1)*8;

	TWO[0] = 0x02;

	num = 1; //result of Jacobi(-1/N).  Initialize to 1
	flag = FALSE;

	//Morrie calls this the correction factor
	//if sign = 1 (neg), check to see:
	//  if n = 1 mod 4, (-1/n) = 1
	//  if n = 3 mod 4, (-1/n) = -1
	//  run jacobi,  get an answer, multiply it by 1 or -1
	if ( (N[lenN-1] % 4) == 1 )
		num = 1;
	else if ( (N[lenN-1] % 4) == 3 )
		num = -1;
	else	// shouldn't ever get here
		return -1;

	/*Initialize D*/
	initMP(&(D));
	allocMP(&D, maxlenbit);
	D.val[maxlenbit/8-1] = (BYTE)0x05;  //initialize
	Dsign = 0; //positive
	do {
		printf("value of D.size = %d\n", D.size);
		printf("value of lenN = %d\n", lenN);

		Mod(D.val, D.size, N, lenN);  // almost always just returns
		if ( Dsign == 0 )
			Jacobi_answ = Jacobi(D.val, D.size, N, lenN);
		else
			Jacobi_answ = Jacobi(D.val, D.size, N, lenN) * num;

		//if answ == -1, it's good.  If it equals 0, stop processing here
		//and process below (it's a composite number), if it's 1, do the processing
		//in this loop
		if ( (Jacobi_answ == -1) || (Jacobi_answ == 0) ) //we want it to equal to -1
			flag = TRUE; //meaning done
		else
			//add 2, change the sign
			//if sign = 0 (positive),
			// run jacobi, get answer.
			do {
				add (D.val, D.size, TWO, 1);
				Dsign = Dsign ^ 1;
			} while ( equal(D.val, N, D.size) );
	} while (flag == FALSE);

	if (Jacobi_answ == 0)
		return -1;

/* if D is negative add the value of N to it to make it positive.  This will eliminate
   the need for negative numbers in all the calculations
*/
	if ( Dsign == 1 ) {
		initMP(&temp);
		allocMP(&temp, lenN*8);
		bcopy(N, temp.val, lenN);
		sub(temp.val, temp.size, D.val, lenN);
		bcopy(temp.val, D.val, lenN);
		freeMP(&temp);
	}

	//Initialize all variables used prior to and in the for loop
	initMP(&(K));
	allocMP(&K, maxlenbit);
	initMP(&(U));
	allocMP(&U, maxlenbit);
	initMP(&(V));
	allocMP(&V, maxlenbit);
	

	//Calculate K = N + 1
	K.val[K.size-1] = 0x01;
	add (K.val, K.size, N, lenN);
	r = K.bitlen; 
	while  ( (K.val[0] & 0x80) != 0x80 ) {
		--r;
		bshl(K.val, K.size);
	}
	bshl(K.val, K.size); //because loop is suppose to start at the r-1th bit.
	//set u = 1
	U.val[U.size-1] = 0x01;

	//set v = 1
	V.val[V.size-1] = 0x01;

	for ( i=r-1; i>=0; i-- ) {
		// set U 
		initMP(&(newU));
		allocMP(&newU, U.bitlen+V.bitlen);
		ModMult(newU.val, U.val, U.size, V.val, V.size, N, lenN);
		//set V
		initMP(&(newV));
		allocMP(&newV, V.bitlen);
		calv1(newV, U, V, D, N, lenN);

		bcopy(newV.val, V.val, newV.size);
		freeMP(&newV);
		//now set U to new value of U since V has been calculated with old u
		bcopy (newU.val+U.size, U.val, U.size);

		freeMP(&newU);

		//Check to see if Kj = 1. If so compute U and V further
		if ( (K.val[0] & 0x80) == 0x80 ) // if the bit associated with the value of i is
										 // 1 do the following:
			ProcessUVagain(U, V, D, N, lenN);
		bshl(K.val, K.size); 
	}

	freeMP(&K);
	freeMP(&V);
	freeMP(&D);
	if ( eqzero(U.val, U.size) ) {
		freeMP(&U);
		return 0;
	}
	else {
		freeMP(&U);
		return -1;
	}
}

void ProcessUVagain(MP U, MP V, MP D, BYTE *N, int lenN)
{
	MP DU, DUplusV, UplusV, newU;

	//CALCULATE U
	initMP(&(UplusV));
	allocMP(&UplusV, U.bitlen+8);
	//Calculate U+V

	bcopy(U.val, UplusV.val + 1, U.size);
	add(UplusV.val,UplusV.size, V.val, V.size);

	//Determine if U+V is divisible by 2.  If not add N to U+V
	if ( UplusV.val[UplusV.size-1] % 2 )	// odd
		add (UplusV.val, UplusV.size, N, lenN);

	bshr(UplusV.val, UplusV.size);

	Mod(UplusV.val, UplusV.size, N, lenN);

	//Copy answer of U in newU");
	initMP(&(newU));
	allocMP(&newU, U.bitlen);
	bcopy(UplusV.val+1, newU.val, UplusV.size);
	freeMP(&UplusV);

	//Calculate DU
	initMP(&(DU));
	allocMP(&DU, D.bitlen+U.bitlen);
	Mult(DU.val, D.val, D.size, U.val, U.size);

	//Calculate DU+V
	initMP(&(DUplusV));
	allocMP(&DUplusV, DU.bitlen);

	bcopy(DU.val, DUplusV.val, DUplusV.size);
	add(DUplusV.val, DUplusV.size, V.val, V.size);

	//CHECK
	freeMP(&DU);

	//if DUplusV ! div by 2 add N to it and then divide
	if ( DUplusV.val[DUplusV.size-1] % 2 )	// odd
		add (DUplusV.val, DUplusV.size, N, lenN);

	bshr(DUplusV.val, DUplusV.size);

	Mod(DUplusV.val, DUplusV.size, N, lenN);

	bcopy(DUplusV.val+U.size, V.val, V.size);
	freeMP(&DUplusV);

	bcopy(newU.val, U.val, newU.size);
	freeMP(&newU);
}

void calv1(MP newV, MP U, MP V, MP D, BYTE *N, int lenN)
{
	MP	V2, U2, DU2, DU2plusV2;

	//Calculate V2
	initMP(&(V2));
	allocMP(&V2, 2*V.bitlen);
	Square(V2.val, V.val, V.size);

	//Calculate U2
	initMP(&(U2));
	allocMP(&U2, 2*U.bitlen);
	Square(U2.val, U.val, U.size);

	//Calculate D*U2
	initMP(&(DU2));
	allocMP(&DU2, D.bitlen+U2.bitlen);
	Mult(DU2.val, D.val, D.size, U2.val, U2.size);
	freeMP(&U2);

	//Calculate DU2plusV2
	initMP(&(DU2plusV2));
	allocMP(&DU2plusV2, DU2.bitlen);
	bcopy(DU2.val, DU2plusV2.val, DU2.size);
	add(DU2plusV2.val, DU2plusV2.size, V2.val, V2.size);
	freeMP(&DU2);
	freeMP(&V2);

	//if DU2plusV2 not div by 2, add N to it and then divide
	if ( DU2plusV2.val[DU2plusV2.size-1] % 2 )
		add (DU2plusV2.val, DU2plusV2.size, N, lenN);

	bshr(DU2plusV2.val, DU2plusV2.size);

	Mod(DU2plusV2.val, DU2plusV2.size, N, lenN);
	bcopy(DU2plusV2.val+(DU2plusV2.size-newV.size), newV.val, newV.size);

	//CHECK
	freeMP(&DU2plusV2);
}
