#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <float.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "utilities1.h"
#include "special-functions.h"
#include "mconf.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
               O V E R L A P P I N G  T E M P L A T E  T E S T
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void OverlappingTemplateMatchings(int m, int n)
{
	int    i, k, match, state;
	double W_obs, eta, sum, chi2;
	double p_value, lambda;
	char   assignment[15];
	int    M, N, j, K = 5;
	unsigned int nu[6] = {0,0,0,0,0,0};
	double pi[6] = {0.143783,0.139430,0.137319,0.124314,0.106209,0.348945};
	/*  double U[6] = {0,1,2,3,4}; */
	
#ifdef GEN_TIMING_INFO
	clock_t start, finish;
	FILE	*fp;
	fp = fopen("Overlapping.txt", "a");

	start = clock();
#endif
	
	M = 1032;
	N = (int)floor(n/M);

	if ( (templates = (BitField*)calloc(m,sizeof(BitField))) == NULL ) {
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t    OVERLAPPING TEMPLATE OF ALL ONES TEST\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t---------------------------------------------\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\tTEMPLATE DEFINITION:  Insufficient memory,");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], " Overlapping Template Matchings test aborted!\n");
		state = 0;
	}
	else
		for( i=0; i<m; i++ )
			templates[i].b = 1;

	lambda = (double)(M-m+1)/pow(2,m);
	eta = lambda/2.0;
	sum = 0.0;
	for( i=0; i<K; i++ ) {			/* Compute Probabilities */
		pi[i] = Pr(i,eta);
		sum += pi[i];
	}
	pi[K] = 1 - sum;

	for( i=0; i<N; i++ ) {
		W_obs = 0;
		for( j=0; j<M-m+1; j++ ) {
			match = 1;
			for( k=0; k<m; k++ )
				if ( (int)templates[k].b != (int)epsilon[i*M+j+k].b )
					match = 0;
			if ( match == 1 )
				W_obs++;
		}
		if ( W_obs <= 4 )
			nu[(int)W_obs]++;
		else
			nu[K]++;
	}
	sum = 0;
	chi2 = 0.0;                                   /* Compute Chi Square */
	for( i=0; i<K+1; i++ ) {
		chi2 += pow((double)nu[i] - (double)N*pi[i],2)/((double)N*pi[i]);
		sum += nu[i];
	}
	p_value = igamc(K/2.,chi2/2.);
	/*p_value = gammq(K/2.,chi2/2.);*/

	if (PERIODIC_TEMPLATES) {
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t    OVERLAPPING TEMPLATE OF ALL ONES TEST\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t-----------------------------------------------\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\tCOMPUTATIONAL INFORMATION:\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t-----------------------------------------------\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t(a) n (sequence_length)      = %d\n", n);
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t(b) m (block length of 1s)   = %d\n", m);
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t(c) M (length of substring)  = %d\n", M);
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t(d) N (number of substrings) = %d\n", N);
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t(e) lambda [(M-m+1)/2^m]     = %f\n", lambda);
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t(f) eta                      = %f\n", eta);
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t-----------------------------------------------\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t   F R E Q U E N C Y\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t  0   1   2   3   4 >=5   Chi^2   P-value  Assignment\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t-----------------------------------------------\n");
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "\t\t%3d %3d %3d %3d %3d %3d  %f ",nu[0],nu[1],nu[2],	nu[3], nu[4],nu[5],chi2);
	}
	if ( isNegative(p_value) || isGreaterThanOne(p_value) )
		fprintf(stats[TESTS_OVERLAPPING_TEMPL], "WARNING:  P_VALUE IS OUT OF RANGE.\n");
	if ( p_value < ALPHA ) {				    /* INTERPRETATION */
		strcpy(assignment,"FAILURE");
		state = 0;
	}
	else {
		strcpy(assignment,"SUCCESS");
		state = 1;
	}
	free(templates);
	fprintf(stats[TESTS_OVERLAPPING_TEMPL], "%f %s\n\n", p_value, assignment); fflush(stats[TESTS_OVERLAPPING_TEMPL]);
	fprintf(results[TESTS_OVERLAPPING_TEMPL], "%f\n", p_value); fflush(results[TESTS_OVERLAPPING_TEMPL]);
	fprintf(grid, "%d", state); fflush(grid);

	if ( p_value < tp.minimumP )
		tp.minimumP = p_value;
	if ( !_isnan(p_value) )
		tp.lnSum += log(p_value);
	tp.df++;

#ifdef GEN_TIMING_INFO
	finish = clock();
	fprintf(fp, "%d\n", finish - start);
	fclose(fp);
#endif

	return;
}
