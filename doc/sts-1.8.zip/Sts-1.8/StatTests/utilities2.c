#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "config.h"
#include "utilities1.h"
#include "utilities2.h"
#include "generators1.h"
#include "generators2.h"

/* function declarations from generator3.h */

int displayGeneratorOptions()
{
	int option = 0;

	printf("________________________________________");
	printf("________________________________________\n\n");
	printf("\t\t     G E N E R A T O R  O P T I O N S \n");
	printf("________________________________________");
	printf("________________________________________\n\n");
	printf("\t[00] Input File\t\t\t[01] G Using SHA-1\n");
	printf("\t[02] Linear Congruential\t[03] Blum-Blum-Shub\n");
	printf("\t[04] Micali-Schnorr\t\t[05] Modular Exponentiation\n");
	printf("\t[06] Quadratic Congruential I\t[07] Quadratic Congruential II\n");
	printf("\t[08] Cubic Congruential\t\t[09] XOR\n");
	printf("\t[10] ANSI X9.17 (3-DES)\t\t[11] G Using DES\n");
	printf("________________________________________");
	printf("________________________________________\n\n");
	printf("\tOPTION ----> "); scanf("%d",&option);

	return option;
}

void chooseTests()
{
	int i;

	displayTests();
	printf("\n\n\n");
	printf("________________________________________");
	printf("________________________________________\n\n");
	printf("\t\t\t     INSTRUCTIONS\n");
	printf("\tEnter 0 if you DO NOT want to apply all of the\n");
	printf("\tstatistical tests to each sequence and 1 if you DO. \n");
	printf("________________________________________");
	printf("________________________________________\n\n");
	printf("\tEnter Choice:  ");
	scanf("%d",&testVector[0]);
	printf("\n");
	if ( testVector[0] == 1 )
		for( i=1; i <= NUMOFTESTS; i++ )
			testVector[i] = 1;
	else {
		displayTests();
		printf("________________________________________");
		printf("________________________________________\n\n");
		printf("\t\t\t     INSTRUCTIONS\n");
		printf("\tEnter a 0 or 1 to indicate whether or not the numbered\n");
		printf("\tstatistical test should be applied to each sequence.  \n");
		printf("\tFor example, 1111111111111111 applies every test to \n");
		printf("\teach sequence.\n");
		printf("________________________________________");
		printf("________________________________________\n");
		printf("\t\t\t    1234567891111111\n");
		printf("\t\t\t             0123456\n");
		printf("\t\t\t    ");
		for (i = 1; i <= NUMOFTESTS; i++) 
			scanf("%1d", &testVector[i]);
		printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	}

	return;
}

void displayTests()
{
	printf("________________________________________");
	printf("________________________________________\n\n");
	printf("\t\t      S T A T I S T I C A L  T E S T S\n");
	printf("________________________________________");
	printf("________________________________________\n\n");
	printf("   [01] Frequency\t\t\t");
	printf("   [02] Block Frequency\n");
	printf("   [03] Cumulative Sums\t\t\t");
	printf("   [04] Runs\n");
	printf("   [05] Longest Run of Ones\t\t");
	printf("   [06] Rank\n");
	printf("   [07] Discrete Fourier Transform\t");
	printf("   [08] Nonperiodic Template Matchings\n");
	printf("   [09] Overlapping Template Matchings\t");
	printf("   [10] Universal Statistical\n");
	printf("   [11] Approximate Entropy\t\t");
	printf("   [12] Random Excursions\n");
	printf("   [13] Random Excursions Variant\t");
	printf("   [14] Serial\n");
	printf("   [15] Lempel-Ziv Complexity\t\t");
	printf("   [16] Linear Complexity\n");

	return;
}

void fixParameters()
{
	if (testVector[2] == 1) {
		printf("\tEnter Block Frequency Test block length:  "); 
		scanf("%d",&tp.blockFrequencyBlockLength);
	}
	if (testVector[8] == 1) {
		printf("\tEnter NonOverlapping Template Test Block Length:  "); 
		scanf("%d", &tp.nonOverlappingTemplateBlockLength);
	}
	if (testVector[9] == 1) {
		printf("\tEnter Overlapping Template Test Block Length:  "); 
		scanf("%d", &tp.overlappingTemplateBlockLength);
	}
	if (testVector[10] == 1) {
		printf("\tEnter Universal Test Block Length:  "); 
		scanf("%d", &tp.universalBlockLength);
		printf("\tEnter Universal Test Number Of Initialization Steps:  "); 
		scanf("%d", &tp.universalNumberInitializationSteps);
	}
	if (testVector[11] == 1) {
		printf("\tEnter Approximate Entropy Test Block Length:  "); 
		scanf("%d", &tp.approximateEntropyBlockLength);
	}
	if (testVector[14] == 1) {
		printf("\tEnter Serial Test Block Length:  "); 
		scanf("%d", &tp.serialBlockLength);
	}
	if (testVector[16] == 1) {
		printf("\tEnter Linear Complexity Test Subsequence Length:  "); 
		scanf("%d", &tp.linearComplexitySequenceLength);
	}

	return;
}

int convertToBits(BYTE *x, int numBits, int tp_n, int *n0, int *n1, int *bitsRead)
{
	int		i, j, bit, done;
	BYTE	mask;

	done = 0;
	for ( i=0; i<(numBits+7)/8; i++ ) {
		mask = 0x80;
		for ( j=0; j<8 && !done; j++ ) {
			bit = (x[i] & mask) ? 1 : 0;
			if ( bit == 0 ) 
				(*n0)++;
			else 
				(*n1)++;
			epsilon[(int)*bitsRead].b = bit;
			(*bitsRead)++;
			if ( (int)*bitsRead == tp_n ) {
				done = 1;
				break;
			}
			mask >>= 1;
		}
	}

	return done;
}

/*
int convertToBits(BYTE* x, int n, int* n0, int* n1, int* bitsRead, int offset, 
                  int num32BitIntegers)
{
	int      i, bit, done;
	BYTE     *T;
	unsigned long  c, displayMask = 1 << 31;
	unsigned long A;

	T = (BYTE*) calloc(9,sizeof(BYTE));
	done = 0;
	for( i=0; (i<num32BitIntegers) && !done; i++ ) {
		sprintf(T,"%02x%02x%02x%02x",x[4*i+offset],x[4*i+offset+1],
		x[4*i+offset+2], x[4*i+offset+3]);
		//printf("T = %s\n", T);
		A = strtoul(T,(char**)NULL,16);
		for(c = 1; c <= 32; c++) {
			if (A & displayMask)
				bit = 1;
			else
				bit = 0;
			A <<= 1;
			if (bit == 0) 
				(*n0)++;
			else 
				(*n1)++;
			epsilon[(int)*bitsRead].b = bit;
			(*bitsRead)++;
			if ((int)*bitsRead == n) {
				done = 1;
				break;
			}
		}
	}
	free(T);

	return done;
}
*/
