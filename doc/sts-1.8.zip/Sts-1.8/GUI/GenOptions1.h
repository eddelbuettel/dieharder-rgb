#if !defined(AFX_GENOPTIONS1_H__515D32AE_8A99_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_GENOPTIONS1_H__515D32AE_8A99_11D6_8735_00045A48D764__INCLUDED_

#include <direct.h>
#define BITS 0
#define HEX  1

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GenOptions1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGenOptions1 dialog

class CGenOptions1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CGenOptions1)

// Construction
public:

	int		ReuseAvailable();
	int		getGeneratorNum();
	CString getGenerator();
	int		getRegeneratorNum();
	bool	m_isInputFileSelected;
	int		m_inputModeNum;
	int		reuse;

	CGenOptions1();
	~CGenOptions1();

// Dialog Data
	//{{AFX_DATA(CGenOptions1)
	enum { IDD = IDD_GenOptions1 };
	CButton		m_SaveData;
	CButton		m_Radio_Generators;
	CButton		m_radioRegenerate;
	CStatic		m_inputMode_static;
	CComboBox	m_inputMode;
	CButton		m_browse;
	CString		m_inputFile;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CGenOptions1)
	public:
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	//{{AFX_MSG(CGenOptions1)
	virtual BOOL OnInitDialog();
	afx_msg void OnBUTTONBrowse();
	afx_msg void OnRadioModularExp();
	afx_msg void OnRadioLinearCongr();
	afx_msg void OnRadioBbs();
	afx_msg void OnRadioMicaliSchnorr();
	afx_msg void OnRadioQuadraticI();
	afx_msg void OnRadioQuadraticIi();
	afx_msg void OnRadioCubicCongr();
	afx_msg void OnRadioXor();
	afx_msg void OnRadioAnsi();
	afx_msg void OnRadioGdes();
	afx_msg void OnRadioInputFile();
	afx_msg void OnRadioRegenerate();
	afx_msg void OnRadioReuse();
	afx_msg void OnRadioSha1();
	afx_msg void OnRadioSha224();
	afx_msg void OnRadioSha256();
	afx_msg void OnRadioSha384();
	afx_msg void OnRadioSha512();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GENOPTIONS1_H__515D32AE_8A99_11D6_8735_00045A48D764__INCLUDED_)
