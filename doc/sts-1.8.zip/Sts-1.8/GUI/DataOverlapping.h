#if !defined(AFX_DATAOVERLAPPING_H__00E168A6_B7AC_4490_8F04_6A2376433505__INCLUDED_)
#define AFX_DATAOVERLAPPING_H__00E168A6_B7AC_4490_8F04_6A2376433505__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataOverlapping.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataOverlapping dialog

class CDataOverlapping : public CDialog
{
// Construction
public:
	CDataOverlapping(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataOverlapping)
	enum { IDD = IDD_DataOverlapping };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataOverlapping)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataOverlapping)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATAOVERLAPPING_H__00E168A6_B7AC_4490_8F04_6A2376433505__INCLUDED_)
