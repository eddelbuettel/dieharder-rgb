#if !defined(AFX_DATADFFT_H__729FECEA_B124_4579_8930_0092CC819DE3__INCLUDED_)
#define AFX_DATADFFT_H__729FECEA_B124_4579_8930_0092CC819DE3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataDFFT.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataDFFT dialog

class CDataDFFT : public CDialog
{
// Construction
public:
	CDataDFFT(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataDFFT)
	enum { IDD = IDD_DataDFFT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataDFFT)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataDFFT)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATADFFT_H__729FECEA_B124_4579_8930_0092CC819DE3__INCLUDED_)
