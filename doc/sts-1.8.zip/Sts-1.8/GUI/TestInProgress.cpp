// TestInProgress.cpp : implementation file
//

#include "stdafx.h"
#include <math.h>
#include <stdlib.h>
#include "StsGui.h"
#include "TestInProgress.h"
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "generators1.h"
//#include "generators2.h"
#include "generators3.h"
#include "utilities1.h"
#include "utilities2.h"
#include "sts.h"
#include "mp.h"
#include "rng.h"
#include "cephes-protos.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	OUTPUT_DATA

double igami(double a, double y0);

/////////////////////////////////////////////////////////////////////////////
// CTestInProgress dialog


CTestInProgress::CTestInProgress(CWnd* pParent /*=NULL*/)
	: CDialog(CTestInProgress::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestInProgress)
	//}}AFX_DATA_INIT
}


void CTestInProgress::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestInProgress)
	DDX_Control(pDX, IDC_FREQ_PROG, m_Freq_Prog);
	DDX_Control(pDX, IDC_BLOCKFREQ_PROG, m_BlockFreq_Prog);
	DDX_Control(pDX, IDC_CUMSUM_PROG, m_CumSum_Prog);
	DDX_Control(pDX, IDC_RUNS_PROG, m_Runs_Prog);
	DDX_Control(pDX, IDC_LONGRUNS_PROG, m_LongRuns_Prog);
	DDX_Control(pDX, IDC_RANK_PROG, m_Rank_Prog);
	DDX_Control(pDX, IDC_DFFT_PROG, m_DFFT_Prog);
	DDX_Control(pDX, IDC_NONPERIODICTEMP_PROG, m_NonPerTemp_Prog);
	DDX_Control(pDX, IDC_OVERLAPPINGTEMP_PROG, m_OverlapTemp_Prog);
	DDX_Control(pDX, IDC_UNIVERSAL_PROG, m_Universal_Prog);
	DDX_Control(pDX, IDC_APEN_PROG, m_Apen_Prog);
	DDX_Control(pDX, IDC_RNDEXCURSION_PROG, m_RndExcursion_Prog);
	DDX_Control(pDX, IDC_RNDEXCURSIONVAR_PROG, m_RndExcursionVar_Prog);
	DDX_Control(pDX, IDC_SERIAL_PROG, m_Serial_Prog);
	DDX_Control(pDX, IDC_LINCOMPLEX_PROG, m_LinComplex_Prog);
	DDX_Control(pDX, ID_RUNTESTS, m_RunTests);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestInProgress, CDialog)
	//{{AFX_MSG_MAP(CTestInProgress)
	ON_BN_CLICKED(ID_RUNTESTS, OnRunTests)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestInProgress message handlers

void CTestInProgress::OnRunTests() 
{
	int		i;
	char	streamFile[250], filename[250];
	FILE	*inf_fp;
	
	// Updating listbox info
	m_pGenOptions->UpdateData(TRUE);
	m_pTestSelection->UpdateData(TRUE);

	/*
	m_pTestSelection->m_lenSequences.GetLine(0, str, 10);
	tp.n = atoi(str);
	m_pTestSelection->m_numSequences.GetLine(0, str, 10);
	tp.numOfBitStreams = atoi(str);
	tp.blockFrequencyBlockLength = 10;
	tp.nonOverlappingTemplateBlockLength = 10;
	tp.overlappingTemplateBlockLength = 10;
	tp.universalBlockLength = 6;
	tp.universalNumberInitializationSteps = 640;
	tp.approximateEntropyBlockLength = 5;
	tp.serialBlockLength = 5;
	tp.linearComplexitySequenceLength = 5000;
	*/

	// test paramters (if applicable)
	mFreqCtr = 0;
	if ( testVector[TESTS_FREQUENCY] ) {
		m_Freq_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_Freq_Prog.SetRange(0, 1);
		m_Freq_Prog.SetPos(1);
	}

	mBlkFreqCtr = 0;
	if ( testVector[TESTS_BLOCK_FREQUENCY] ) {
//		tp.blockFrequencyBlockLength =
//			atoi(m_pTestSelection->m_pParamTab->getBFQCYBlockLen());
		m_BlockFreq_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_BlockFreq_Prog.SetRange(0, 1);
		m_BlockFreq_Prog.SetPos(1);
	}

	mCumSumCtr = 0;
	if ( testVector[TESTS_CUM_SUMS] ) {
		m_CumSum_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_CumSum_Prog.SetRange(0, 1);
		m_CumSum_Prog.SetPos(1);
	}

	mRunsCtr = 0;
	if ( testVector[TESTS_RUNS] ) {
		m_Runs_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_Runs_Prog.SetRange(0, 1);
		m_Runs_Prog.SetPos(1);
	}

	mLongRunsCtr = 0;
	if ( testVector[TESTS_LONGEST_RUNS] ) {
		m_LongRuns_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_LongRuns_Prog.SetRange(0, 1);
		m_LongRuns_Prog.SetPos(1);
	}

	mRankCtr = 0;
	if ( testVector[TESTS_RANK] ) {
		m_Rank_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_Rank_Prog.SetRange(0, 1);
		m_Rank_Prog.SetPos(1);
	}

	mDFFTCtr = 0;
	if ( testVector[TESTS_DFFT] ) {
		m_DFFT_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_DFFT_Prog.SetRange(0, 1);
		m_DFFT_Prog.SetPos(1);
	}

	mNonPerTempCtr = 0;
	if ( testVector[TESTS_NONPERIODIC_TEMPL] ) {
//		tp.nonOverlappingTemplateBlockLength =
//			atoi(m_pTestSelection->m_pParamTab->getNonPTemplLen());
		m_NonPerTemp_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_NonPerTemp_Prog.SetRange(0, 1);
		m_NonPerTemp_Prog.SetPos(1);
	}
	
	mOverlapTempCtr = 0;
	if ( testVector[TESTS_OVERLAPPING_TEMPL] ) {
//		tp.overlappingTemplateBlockLength =
//			atoi(m_pTestSelection->m_pParamTab->getOverLappingTemplLen());
		m_OverlapTemp_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_OverlapTemp_Prog.SetRange(0, 1);
		m_OverlapTemp_Prog.SetPos(1);
	}

	mUniversalCtr = 0;
	if ( testVector[TESTS_UNIVERSAL] ) {
//		tp.universalBlockLength =
//			atoi(m_pTestSelection->m_pParamTab->getUniversalBlockLen());
//		tp.universalNumberInitializationSteps =
//			atoi(m_pTestSelection->m_pParamTab->getUniversalNumBlocks());
		m_Universal_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_Universal_Prog.SetRange(0, 1);
		m_Universal_Prog.SetPos(1);
	}

	mApenCtr = 0;
	if ( testVector[TESTS_APEN] ) {
//		tp.approximateEntropyBlockLength =
//			atoi(m_pTestSelection->m_pParamTab->getAPENBlockLen());
		m_Apen_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_Apen_Prog.SetRange(0, 1);
		m_Apen_Prog.SetPos(1);
	}
	
	mRndExcursionCtr = 0;
	if ( testVector[TESTS_RANDOM_EXCURSIONS] ) {
		m_RndExcursion_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_RndExcursion_Prog.SetRange(0, 1);
		m_RndExcursion_Prog.SetPos(1);
	}

	mRndExcursionVarCtr = 0;
	if ( testVector[TESTS_RANDOM_EXCUR_VAR] ) {
		m_RndExcursionVar_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_RndExcursionVar_Prog.SetRange(0, 1);
		m_RndExcursionVar_Prog.SetPos(1);
	}

	mSerialCtr = 0;
	if ( testVector[TESTS_SERIAL] ) {
//		tp.serialBlockLength =
//			atoi(m_pTestSelection->m_pParamTab->getSerialBlockLen());
		m_Serial_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_Serial_Prog.SetRange(0, 1);
		m_Serial_Prog.SetPos(1);
	}
	
	mLinComplexCtr = 0;
	if ( testVector[TESTS_LINEAR_COMPLEXITY] ) {
//		tp.linearComplexitySequenceLength =
//			atoi(m_pTestSelection->m_pParamTab->getLinearCmplBlockLen());
		m_LinComplex_Prog.SetRange(0, tp.numOfBitStreams);
	}
	else {
		m_LinComplex_Prog.SetRange(0, 1);
		m_LinComplex_Prog.SetPos(1);
	}

/*
	if ( ((output = fopen("stats", "w")) == NULL) ||
		 ((post = fopen("finalAnalysisReport", "w")) == NULL) ||
		 ((grid = fopen("grid", "w")) == NULL) ||
		 ((pvals = fopen("pvals", "w")) == NULL) ||
		 ((pvalsRndExc = fopen("pvalsRndExc", "w")) == NULL) ||
		 ((pvalsRndExcVar = fopen("pvalsRndExcVar", "w")) == NULL) ) {
*/

	tp.generator = m_pGenOptions->getGeneratorNum();
	
	if ( tp.generator == 0 ) {
		strcpy(streamFile, m_pGenOptions->m_inputFile);
		if ( m_pGenOptions->m_isInputFileSelected )
			tp.datamode = m_pGenOptions->m_inputModeNum;
	}
	else
		strcpy(streamFile, generatorDir[tp.generator]);

	sprintf(filename, "%s.inf", generatorDir[tp.generator]);
	if ( (inf_fp = fopen(filename, "w")) == NULL )
		MessageBox("couldn't open INF file for output", "File Error", MB_OK);
	else {
		fprintf(inf_fp, "Generator=%d\n", tp.generator);
		fprintf(inf_fp, "DataMode=%d\n", tp.datamode);
		fprintf(inf_fp, "LenSeq=%d\n", tp.n);
		fprintf(inf_fp, "NumSeq=%d\n", tp.numOfBitStreams);
		fprintf(inf_fp, "BlkFreqBlkLen=%d\n", tp.blockFrequencyBlockLength);
		fprintf(inf_fp, "AperiodicBlkLen=%d\n", tp.nonOverlappingTemplateBlockLength);
		fprintf(inf_fp, "OverlappingBlkLen=%d\n", tp.overlappingTemplateBlockLength);
		fprintf(inf_fp, "UnivBlkLen=%d\n", tp.universalBlockLength);
		fprintf(inf_fp, "UnivSteps=%d\n", tp.universalNumberInitializationSteps);
		fprintf(inf_fp, "ApenBlkLen=%d\n", tp.approximateEntropyBlockLength);
		fprintf(inf_fp, "SerialBlkLen=%d\n", tp.serialBlockLength);
		fprintf(inf_fp, "LinCompSeqLen=%d\n", tp.linearComplexitySequenceLength);
		
		if ( testVector[TESTS_ALL] || testVector[TESTS_FREQUENCY] ) {
			fprintf(inf_fp, "Frequence=TRUE\n");
		}
		else
			fprintf(inf_fp, "Frequence=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_BLOCK_FREQUENCY] ) {
			fprintf(inf_fp, "BlockFrequence=TRUE\n");
		}
		else
			fprintf(inf_fp, "BlockFrequence=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_CUM_SUMS] ) {
			fprintf(inf_fp, "CuSum=TRUE\n");
		}
		else
			fprintf(inf_fp, "CuSum=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_RUNS] ) {
			fprintf(inf_fp, "Runs=TRUE\n");
		}
		else
			fprintf(inf_fp, "Runs=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_LONGEST_RUNS] ) {
			fprintf(inf_fp, "LongRuns=TRUE\n");
		}
		else
			fprintf(inf_fp, "LongRuns=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_RANK] ) {
			fprintf(inf_fp, "Rank=TRUE\n");
		}
		else
			fprintf(inf_fp, "Rank=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_DFFT] ) {
			fprintf(inf_fp, "DFFT=TRUE\n");
		}
		else
			fprintf(inf_fp, "DFFT=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_NONPERIODIC_TEMPL] ) {
			fprintf(inf_fp, "NonPeriodic=TRUE\n");
		}
		else
			fprintf(inf_fp, "NonPeriodic=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_OVERLAPPING_TEMPL] ) {
			fprintf(inf_fp, "Overlapping=TRUE\n");
		}
		else
			fprintf(inf_fp, "Overlapping=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_UNIVERSAL] ) {
			fprintf(inf_fp, "Universal=TRUE\n");
		}
		else
			fprintf(inf_fp, "Universal=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_APEN] ) {
			fprintf(inf_fp, "Apen=TRUE\n");
		}
		else
			fprintf(inf_fp, "Apen=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_RANDOM_EXCURSIONS] ) {
			fprintf(inf_fp, "RandomExcursions=TRUE\n");
		}
		else
			fprintf(inf_fp, "RandomExcursions=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_RANDOM_EXCUR_VAR] ) {
			fprintf(inf_fp, "RandomExcursionsVar=TRUE\n");
		}
		else
			fprintf(inf_fp, "RandomExcursionsVar=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_SERIAL] ) {
			fprintf(inf_fp, "Serial=TRUE\n");
		}
		else
			fprintf(inf_fp, "Serial=FALSE\n");

		if ( testVector[TESTS_ALL] || testVector[TESTS_LINEAR_COMPLEXITY] ) {
			fprintf(inf_fp, "LinearComplexity=TRUE\n");
		}
		else
			fprintf(inf_fp, "LinearComplexity=FALSE\n");

		fclose(inf_fp);
	}

	if ( openOutputStreams(tp.generator) )
		MessageBox("Skipping the generation of data", "ERROR", MB_OK);
	else {
		invokeTestSuite(tp.generator, streamFile);

		fclose(output);
		fclose(grid);
		fclose(pvals);
		fclose(pvalsRndExc);
		fclose(pvalsRndExcVar);
		if ( testVector[TESTS_ALL] || testVector[TESTS_NONPERIODIC_TEMPL] ) 
			for ( i=0; i<NUMAPERIODICFILES; i++ )
				fclose(pvalsAperiodic[i]);

		for( i=0; i<NUMOFTESTS; i++ ) {
			if ( stats[i] != NULL )
				fclose(stats[i]);
			if ( results[i] != NULL )
				fclose(results[i]);
		}
		if ( testVector[TESTS_ALL] || testVector[TESTS_CUM_SUMS] )
			partitionResultFile(2, tp.numOfBitStreams, tp.generator, TESTS_CUM_SUMS);
		if ( testVector[TESTS_ALL] || testVector[TESTS_NONPERIODIC_TEMPL] ) 
			partitionResultFile(MAXNUMOFTEMPLATES, tp.numOfBitStreams, tp.generator, TESTS_NONPERIODIC_TEMPL);
		if ( testVector[TESTS_ALL] || testVector[TESTS_RANDOM_EXCURSIONS] )
			partitionResultFile(8, tp.numOfBitStreams, tp.generator, TESTS_RANDOM_EXCURSIONS);
		if ( testVector[TESTS_ALL] || testVector[TESTS_RANDOM_EXCUR_VAR] )
			partitionResultFile(18, tp.numOfBitStreams, tp.generator, TESTS_RANDOM_EXCUR_VAR);
		if ( testVector[TESTS_ALL] || testVector[TESTS_SERIAL] )
			partitionResultFile(2, tp.numOfBitStreams, tp.generator, TESTS_SERIAL);

		fprintf(post,"-----------------------------------------------");
		fprintf(post,"-------------------------------\n");
		fprintf(post,"RESULTS FOR THE UNIFORMITY OF P-VALUES AND THE ");
		fprintf(post,"PROPORTION OF PASSING SEQUENCES\n");
		fprintf(post,"-----------------------------------------------");
		fprintf(post,"-------------------------------\n\n");
		fprintf(post,"-----------------------------------------------");
		fprintf(post,"-------------------------------\n");
		fprintf(post," C1  C2  C3  C4  C5  C6  C7  C8  C9 C10");
		fprintf(post,"  P-VALUE  PROPORTION  STATISTICAL TEST\n");
		fprintf(post,"-----------------------------------------------");
		fprintf(post,"-------------------------------\n");
		postProcessResults(tp.generator);
		fclose(post);
	}

	CDialog::OnOK();
}

void CTestInProgress::invokeTestSuite(int option, char *streamFile)
{
	fprintf(output, "_________________________________________________");
	fprintf(output, "_______________________________\n\n");
	if ( option == 0 )
		fprintf(output, "\t\tFILE = %s\t  ALPHA = %6.4f", strrchr(streamFile, '\\')+1, ALPHA);
	else
		fprintf(output, "\t\tFILE = %s\t  ALPHA = %6.4f", streamFile, ALPHA);
	fprintf(output, "\n________________________________________________");
	fprintf(output, "________________________________\n\n");
	fflush(output);
#ifndef STS_GUI
	if ( option != 0 )
		printf("\n\t\tStatistical Testing In Progress.........\n");
#endif
	switch(option) {
		case 0:
			fileBasedBitStreams(&streamFile);
			break;
		case 1:
			SHA(160, 112);
			break;
		case 2:
			SHA(224, 112);
			break;
		case 3:
			SHA(256, 128);
			break;
		case 4:
			SHA(384, 192);
			break;
		case 5:
			SHA(512, 256);
			break;
		case 6:
			lcg();
			break;
		case 7:
			bbs();
			break;
		case 8:
			micali_schnorr();
			break;
		case 9:
			quadRes1();
			break;
		case 10:
			quadRes2();
			break;
		case 11:
			cubicRes();
			break;
		case 12:
			exclusiveOR();
			break;
		case 13:
			ANSI();
			break;
		case 14:
			DES(); 
			break;
		case 15:
			modExp();
			break;
		/* INTRODUCE NEW PSEUDO RANDOM NUMBER GENERATORS HERE */
		default:
#ifndef STS_GUI
			printf("Error in invokeTestSuite!\n");
#endif
		break;
	}
#ifndef STS_GUI
	printf("\n\t\tStatistical Testing Complete!!!!!!!!!!!!\n");
#endif

	return;
}

int CTestInProgress::openOutputStreams(int option)
{
	int		i;
	char	statsDir[200];
	char	resultsDir[200];
	char	filename[200];
	int		numOfOpenFiles = 0;

	sprintf(filename, "experiments/%s/stats", generatorDir[option]);
	if ( (output = fopen(filename, "w")) == NULL )
		return 1;
	
	sprintf(filename, "experiments/%s/grid", generatorDir[option]);
	if ( (grid = fopen(filename, "w")) == NULL )
		return 1;
	
	sprintf(filename, "experiments/%s/finalAnalysisReport", generatorDir[option]);
	if ( (post = fopen(filename, "w")) == NULL )
		return 1;

	sprintf(filename, "experiments/%s/pvals", generatorDir[option]);
	if ( (pvals = fopen(filename, "w")) == NULL )
		return 1;

	sprintf(filename, "experiments/%s/pvalsRndExc", generatorDir[option]);
	if ( (pvalsRndExc = fopen(filename, "w")) == NULL )
		return 1;

	sprintf(filename, "experiments/%s/pvalsRndExcVar", generatorDir[option]);
	if ( (pvalsRndExcVar = fopen(filename, "w")) == NULL )
		return 1;

	if ( testVector[TESTS_ALL] || testVector[TESTS_NONPERIODIC_TEMPL] ) {
		for ( i=0; i<NUMAPERIODICFILES; i++ ) {
			sprintf(filename, "experiments/%s/pvalsAper%d", generatorDir[option], i);
			if ( (pvalsAperiodic[i] = fopen(filename, "w")) == NULL )
				MessageBox("couldn't open correctly", "hello", MB_OK);
		}
	}
				
	if ( testVector[TESTS_ALL] || testVector[TESTS_FREQUENCY] )
		fprintf(pvals, "  Freq   ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_BLOCK_FREQUENCY] )
		fprintf(pvals, " BlkFreq ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_CUM_SUMS] )
		fprintf(pvals, "CuSumFwd ");
		fprintf(pvals, "CuSumRev ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_RUNS] )
		fprintf(pvals, "  Runs   ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_LONGEST_RUNS] )
		fprintf(pvals, "LongRuns ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_RANK] )
		fprintf(pvals, "  Rank   ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_DFFT] )
		fprintf(pvals, "  DFFT   ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_UNIVERSAL] )
		fprintf(pvals, "  Univ   ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_APEN] )
		fprintf(pvals, "  Apen   ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_SERIAL] )
		fprintf(pvals, " Serial1 ");
		fprintf(pvals, " Serial2 ");

	if ( testVector[TESTS_ALL] || testVector[TESTS_LINEAR_COMPLEXITY] )
		fprintf(pvals, " LinComp ");

#ifdef COMBINED_PVALUES
	fprintf(pvals, "  MinP     SumLogP\n");
#else
	fprintf(pvals, "\n");
#endif

	fprintf(pvalsRndExc, " RndExc1 ");
	fprintf(pvalsRndExc, " RndExc2 ");
	fprintf(pvalsRndExc, " RndExc3 ");
	fprintf(pvalsRndExc, " RndExc4 ");
	fprintf(pvalsRndExc, " RndExc5 ");
	fprintf(pvalsRndExc, " RndExc6 ");
	fprintf(pvalsRndExc, " RndExc7 ");
	fprintf(pvalsRndExc, " RndExc8\n");
	
	fprintf(pvalsRndExcVar, " RdExVr1 ");
	fprintf(pvalsRndExcVar, " RdExVr2 ");
	fprintf(pvalsRndExcVar, " RdExVr3 ");
	fprintf(pvalsRndExcVar, " RdExVr4 ");
	fprintf(pvalsRndExcVar, " RdExVr5 ");
	fprintf(pvalsRndExcVar, " RdExVr6 ");
	fprintf(pvalsRndExcVar, " RdExVr7 ");
	fprintf(pvalsRndExcVar, " RdExVr8 ");
	fprintf(pvalsRndExcVar, " RdExVr9 ");
	fprintf(pvalsRndExcVar, "RdExVr10 ");
	fprintf(pvalsRndExcVar, "RdExVr11 ");
	fprintf(pvalsRndExcVar, "RdExVr12 ");
	fprintf(pvalsRndExcVar, "RdExVr13 ");
	fprintf(pvalsRndExcVar, "RdExVr14 ");
	fprintf(pvalsRndExcVar, "RdExVr15 ");
	fprintf(pvalsRndExcVar, "RdExVr16 ");
	fprintf(pvalsRndExcVar, "RdExVr17 ");
	fprintf(pvalsRndExcVar, "RdExVr18\n");

	for( i=1; i<=NUMOFTESTS; i++ ) {
		stats[i] = NULL;
		results[i] = NULL;
		if ( testVector[i] == 1 ) {
			sprintf(statsDir, "experiments/%s/%s/stats", generatorDir[option], testNames[i]);
			sprintf(resultsDir, "experiments/%s/%s/results", generatorDir[option], testNames[i]);
			if ( DISPLAY_OUTPUT_CHANNELS ) {
				fprintf(output, "*STATS* DIR => %s\n", statsDir);
				fprintf(output, "RESULTS DIR => %s\n", resultsDir);
				fflush(output);
			}
			/* STATISTICS LOG */
			if ( (stats[i] = fopen(statsDir, "w")) == NULL ) {
#ifdef STS_GUI
				MessageBox("ERROR: Couldn't open 'stats' file", "STS", MB_OK);
#else
				printf("ERROR: Couldn't open 'stats[%d]' file\n", i);
				fflush(stdout);
#endif
				return 1;
			}
			else
				numOfOpenFiles++;

			/* P_VALUES LOG   */
			if ( (results[i] = fopen(resultsDir, "w")) == NULL ) {
#ifdef STS_GUI
				MessageBox("ERROR: Couldn't open 'results' file", "STS", MB_OK);
#else
				printf("ERROR: Couldn't open 'results[%d]' file\n", i);
				fflush(stdout);
#endif
				return 1;
			}
			else
				numOfOpenFiles++;
		}
	}

	return 0;
}

void CTestInProgress::nist_test_suite(int option)
{
#ifdef COMBINED_PVALUES
	double	alpha, sumOfLogs, chi2;
#endif

	int		i;
	static int	counter = 0;
	char	fn[32];
	FILE	*fp_out;

	if ( m_pGenOptions->m_SaveData.GetCheck() ) {
		sprintf(fn, "experiments/%s/output%d.dat", generatorDir[option], counter/100);
		if ( (fp_out = fopen(fn, "a")) != NULL ) {
			fprintf(fp_out, "Counter is <%d>\n", counter++);
			for ( i=0; i<tp.n; i++ ) {
				if ( i && (i%64 == 0) )
					fprintf(fp_out, "\n");
				fprintf(fp_out, "%c", epsilon[i].b ? '1' : '0');
			}
			fprintf(fp_out, "\n\n================\n\n");
			fclose(fp_out);
		}
	}

	tp.df = 0;
	tp.lnSum = 0.0;
	tp.minimumP = 0.0;

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_FREQUENCY] == 1) ) {
		mFreqCtr++;
		m_Freq_Prog.SetPos(mFreqCtr);
		Frequency(tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_BLOCK_FREQUENCY] == 1) ) {
		mBlkFreqCtr++;
		m_BlockFreq_Prog.SetPos(mBlkFreqCtr);
		BlockFrequency(tp.blockFrequencyBlockLength, tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_CUM_SUMS] == 1) ) {
		mCumSumCtr++;
		m_CumSum_Prog.SetPos(mCumSumCtr);
		CumulativeSums(tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_RUNS] == 1) ) {
		mRunsCtr++;
		m_Runs_Prog.SetPos(mRunsCtr);
		Runs(tp.n); 
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_LONGEST_RUNS] == 1) ) {
		mLongRunsCtr++;
		m_LongRuns_Prog.SetPos(mLongRunsCtr);
		LongestRunOfOnes(tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_RANK] == 1) ) {
		mRankCtr++;
		m_Rank_Prog.SetPos(mRankCtr);
		Rank(tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_DFFT] == 1) ) {
		mDFFTCtr++;
		m_DFFT_Prog.SetPos(mDFFTCtr);
		DiscreteFourierTransform(tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_NONPERIODIC_TEMPL] == 1) ) {
		mNonPerTempCtr++;
		m_NonPerTemp_Prog.SetPos(mNonPerTempCtr);
		NonOverlappingTemplateMatchings(tp.nonOverlappingTemplateBlockLength, tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_OVERLAPPING_TEMPL] == 1) ) {
		mOverlapTempCtr++;
		m_OverlapTemp_Prog.SetPos(mOverlapTempCtr);
		OverlappingTemplateMatchings(tp.overlappingTemplateBlockLength, tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_UNIVERSAL] == 1) ) {
		mUniversalCtr++;
		m_Universal_Prog.SetPos(mUniversalCtr);
		Universal(tp.universalBlockLength, tp.universalNumberInitializationSteps, tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_APEN] == 1) ) {
		mApenCtr++;
		m_Apen_Prog.SetPos(mApenCtr);
		ApproximateEntropy(tp.approximateEntropyBlockLength, tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_RANDOM_EXCURSIONS] == 1) ) {
		mRndExcursionCtr++;
		m_RndExcursion_Prog.SetPos(mRndExcursionCtr);
		RandomExcursions(tp.n);
		fprintf(pvalsRndExc, "\n"); fflush(pvalsRndExc);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_RANDOM_EXCUR_VAR] == 1) ) {
		mRndExcursionVarCtr++;
		m_RndExcursionVar_Prog.SetPos(mRndExcursionVarCtr);
		RandomExcursionsVariant(tp.n);
		fprintf(pvalsRndExcVar, "\n"); fflush(pvalsRndExcVar);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_SERIAL] == 1) ) {
		mSerialCtr++;
		m_Serial_Prog.SetPos(mSerialCtr);
		Serial(tp.serialBlockLength,tp.n);
	}

	if ( (testVector[TESTS_ALL] == 1) || (testVector[TESTS_LINEAR_COMPLEXITY] == 1) ) {
		mLinComplexCtr++;
		m_LinComplex_Prog.SetPos(mLinComplexCtr);
		LinearComplexity(tp.linearComplexitySequenceLength, tp.n);
	}
	
#ifdef COMBINED_PVALUES
	/* MINIMUM P TEST */

	alpha = pow((1.-ALPHA), (1./tp.df));
	alpha = 1.-alpha;

	/*
	fprintf(post, "--- COMBINING P-VALUES ---\n");
	fprintf(post, "Minimum p method: \n");
	fprintf(post, "The minimum p-value = %f, ", tp.minimumP);
	fprintf(post, "alpha = %f.\n", alpha);
	if( tp.minimumP >= alpha ) {
		fprintf(post,"Since %f >= %f ", tp.minimumP, alpha);
		fprintf(post,"the minimum p test fails.\n\n");
	}
	else {
		fprintf(post,"Since %f < %f ", tp.minimumP, alpha);
		fprintf(post,"the minimum p test suceeds.\n\n");
	}
	*/
	if( tp.minimumP >= alpha )
		fprintf(pvals,"%f* ", tp.minimumP);
	else
		fprintf(pvals,"%f  ", tp.minimumP);

	/* SUM OF LOGS TEST */

	sumOfLogs = -2 * tp.lnSum;
	chi2 = 2.0 * igami(tp.df/2.0, 0.01);

	/*
	fprintf(post, "Sum of logs method: \n");
	fprintf(post, "The test statistic = %f, ", sumOfLogs);
	fprintf(post, "chi-square = %f.\n", chi2);
	if( sumOfLogs >= chi2 ) {
		fprintf(post, "Since %f >= %f ", sumOfLogs, chi2);
		fprintf(post, "the sum of logs test fails.\n\n");
	}
	else {
		fprintf(post, "Since %f < %f ", sumOfLogs,chi2);
		fprintf(post, "the sum of logs test suceeds.\n\n"); 
	}
	*/

	/*
	if( sumOfLogs >= chi2 )
		fprintf(pvals, "%f* ", sumOfLogs);
	else
		fprintf(pvals, "%f  ", sumOfLogs);
	*/
	if( sumOfLogs >= chi2 )
		fprintf(pvals, "%f* ", chi2);
	else
		fprintf(pvals, "%f  ", chi2);
#endif

	fprintf(grid, "\n"); fflush(grid);
	fprintf(pvals, "\n"); fflush(pvals);

	return;
}

void CTestInProgress::fileBasedBitStreams(char** streamFile)
{ 
	FILE* fp;
	int   mode;

#ifndef STS_GUI
	printf("\n\t\t[0] BITS IN ASCII FORMAT\n");
	printf("\n\t\t[1] HEX DIGITS IN BINARY FORMAT\n");
	/*printf("\n\t\t[2] HEX DIGITS IN ASCII FORMAT\n");*/
	printf("\n\t\tSelect input mode:  ");
	scanf("%1d",&mode);
	printf("\n");
#endif
	mode = m_pGenOptions->m_inputModeNum;
	if ( mode == 0 ) {
		if ( (fp = fopen(*streamFile, "r")) == NULL ) {
#ifdef STS_GUI
			MessageBox("Couldn't open input file", "fileBasedBitStreams", MB_OK);
#else
			printf("ERROR IN FUNCTION fileBasedBitStreams:  file %s ", *streamFile);
			printf("could not be opened.\n");
			fflush(stdout);
#endif
			return;
		}
		readBinaryDigitsInASCIIFormat(fp, *streamFile);
		fclose(fp);
	}
	else if ( mode == 1 ) {
		if ( (fp = fopen(*streamFile, "rb")) == NULL ) {
#ifdef STS_GUI
			MessageBox("Couldn't open input file", "fileBasedBitStreams", MB_OK);
#else
			printf("ERROR IN FUNCTION fileBasedBitStreams:  file %s ", *streamFile);
			printf("could not be opened.\n");
#endif
			return;
		}
		readHexDigitsInBinaryFormat(fp);
		fclose(fp);
	}

	return;
}

void CTestInProgress::readBinaryDigitsInASCIIFormat(FILE* fp, char* streamFile)
{
	int i, j, n0, n1, bitsRead;
	unsigned int bit;	

	if ( (epsilon = (BitField*)calloc(tp.n, sizeof(BitField))) == NULL ) {
#ifdef STS_GUI
		MessageBox("BITSTREAM DEFINITION:  Insufficient memory available.",
			"readBinaryDigitsInASCIIFormat", MB_OK);
#else
		printf("BITSTREAM DEFINITION:  Insufficient memory available.\n");
		printf("Statistical Testing Aborted!\n");
#endif
		return;
	}

#ifndef STS_GUI
	printf("\n\t\tStatistical Testing In Progress.........\n");
#endif
	for( i=0; i<tp.numOfBitStreams; i++ ) {
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		for( j=0; j<tp.n; j++ ) {
			if ( fscanf(fp, "%1d", &bit) == EOF ) {
#ifdef STS_GUI
				MessageBox("Unable to read sufficient data", "readBinaryDigitsInASCIIFormat", MB_OK);
#else
				printf("ERROR:  Insufficient data in file %s.  ", streamFile);
				printf("%d bits were read.\n", bitsRead);
				fflush(stdout);
#endif
				fclose(fp);
				return;
			}
			else {
				bitsRead++;
				if ( bit == 0 ) 
					n0++;
				else 
					n1++;
				epsilon[j].b = bit;
			}
		}
		fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
		nist_test_suite(GEN_FILE);
	}
	free(epsilon);

	return;
}

void CTestInProgress::readHexDigitsInBinaryFormat(FILE* fp)
{
	unsigned		bit;				/* BINARY DIGIT        */
	unsigned long*	buffer;
	unsigned long	c, displayMask = 1 << 31;
	int				i, k, n0, n1, bitsRead, numRead;

	if ( ((epsilon = (BitField *)calloc(tp.n,sizeof(BitField))) == NULL) ) {
#ifdef STS_GUI
#else
		printf("BITSTREAM DEFINITION:  Insufficient memory available.\n");
		fflush(stdout);
#endif
		return;
	}

	if ( ((buffer = (unsigned long*)calloc((tp.n+31)/32, sizeof(unsigned long))) == NULL) ) {
#ifdef STS_GUI
#else
		printf("BITSTREAM DEFINITION:  Insufficient memory available.\n");
#endif
		return;
	}

#ifdef STS_GUI
#else
	printf("\n\t\tStatistical Testing In Progress.........\n");
#endif
	for( k=0; k<tp.numOfBitStreams; k++ ) {
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		numRead = (tp.n + 31) / 32;
		for( i=0; i<numRead; i++ ) {
			fread(buffer,sizeof(unsigned long),1,fp);
#ifdef LITTLE_ENDIAN
			byteReverse( buffer, 4 );
#endif
			for( c=1; c<=32; c++ ) {
				if ( buffer[0] & displayMask ) {
					bit = 1;
					n1++;
				}
				else {
					bit = 0;
					n0++;
				}
				buffer[0] <<= 1;
				epsilon[bitsRead].b = bit;
				bitsRead++;
				if ( bitsRead == tp.n )
					break;
			}
		}
		fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
		fflush(output);
		nist_test_suite(GEN_FILE);
	}
	free(buffer);
	free(epsilon);

	return;
}

void CTestInProgress::partitionResultFile(int numOfFiles, int numOfSequences,
										  int option, int category)
{
	int    i, k, m, j, start, end, num, numread;
	float  c;
	FILE** fp = (FILE**)calloc(numOfFiles+1, sizeof(FILE*));
	int*   results = (int*)calloc(numOfFiles, sizeof(int*));
	char   s[MAXFILESPERMITTEDFORPARTITION][200];
	char   resultsDir[200];

	sprintf(resultsDir, "experiments/%s/%s/results", generatorDir[option],
		testNames[category]);
	if ( DISPLAY_OUTPUT_CHANNELS )
		fprintf(output, "OPEN FILE:  %s\n", resultsDir);

	if ( (fp[numOfFiles] = fopen(resultsDir,"r")) == NULL ) {
		fprintf(output, "%s", resultsDir);
		fprintf(output, " -- file not found. Exiting program.\n");
		return;
	}

	for ( i=0; i<numOfFiles; i++ ) {
		if (i < 10)
			sprintf(s[i], "experiments/%s/%s/data%1d", generatorDir[option],
				testNames[category], i+1);
		else if (i < 100)
			sprintf(s[i], "experiments/%s/%s/data%2d", generatorDir[option],
				testNames[category], i+1);
		else
			sprintf(s[i], "experiments/%s/%s/data%3d", generatorDir[option],
				testNames[category], i+1);
		if ( DISPLAY_OUTPUT_CHANNELS )
			fprintf(output, "OPEN = %s\n", s[i]);
	}

	numread = 0;
	m = (numOfFiles+19) / 20;
	for ( i=0; i<numOfFiles; i++ ) {
		if ( (fp[i] = fopen(s[i],"w")) == NULL ) {
			fprintf(output, "%s", s[i]);
			fprintf(output, " -- file not found. Exiting program.\n");
			return;
		}
		fclose(fp[i]);
	}

	for ( num=0; num<numOfSequences; num++ ) {
		for ( k=0; k<m; k++ ) { 		/* FOR EACH BATCH */

			start = k*20;		/* BOUNDARY SEGMENTS */
			end = k*20+19;
			if ( k == (m-1) )
				end = numOfFiles-1;

			if ( PARTITION )
				fprintf(output, "k = %d start = %d end = %d\n", k, start, end);

			for ( i=start; i<=end; i++ ) {		/* OPEN FILE */
				if ( (fp[i] = fopen(s[i],"a")) == NULL ) {
					printf("%s",s[i]);
					printf(" -- file not found. Exiting program.\n");
					exit(-1);
				}
				if ( PARTITION )
					fprintf(output, "Open file %s\n", s[i]);
			}

			for ( j=start; j<=end; j++ ) {		/* POPULATE FILE */
				fscanf(fp[numOfFiles], "%f", &c);
				fprintf(fp[j], "%f\n", c);
				numread++;
				if ( PARTITION )
					fprintf(output, "NUMREAD = %d\n", numread);
			}

			for ( i=start; i<=end; i++ ) {		/* CLOSE FILE */
				fclose(fp[i]);
				if ( PARTITION )
					fprintf(output, "Close file %s\n", s[i]);
			}
		}
	}
	fclose(fp[numOfFiles]);

	return;
}

void CTestInProgress::postProcessResults(int option)
{
	int		i, k, randomExcursionSampleSize, generalSampleSize;
	int		case1, case2, numOfFiles = 2;
	double	passRate;
	char	s[100];

	for ( i=1; i<=NUMOFTESTS; i++ ) {		/* FOR EACH TEST */

		if ( testVector[i] == 1 ) {

			/* SPECIAL CASES -- HANDLING MULTIPLE FILES FOR A SINGLE TEST */

			if ( ((i ==  TESTS_CUM_SUMS) && testVector[TESTS_CUM_SUMS]) ||
				 ((i ==  TESTS_NONPERIODIC_TEMPL) && testVector[TESTS_NONPERIODIC_TEMPL]) ||
				 ((i == TESTS_RANDOM_EXCURSIONS) && testVector[TESTS_RANDOM_EXCURSIONS]) ||
				 ((i == TESTS_RANDOM_EXCUR_VAR) && testVector[TESTS_RANDOM_EXCUR_VAR]) || 
				 ((i == TESTS_SERIAL) && testVector[TESTS_SERIAL]) ) {

				if ( (i == TESTS_NONPERIODIC_TEMPL) && testVector[TESTS_NONPERIODIC_TEMPL] )
					numOfFiles = MAXNUMOFTEMPLATES;
				else if ( (i == TESTS_RANDOM_EXCURSIONS) && testVector[TESTS_RANDOM_EXCURSIONS] )
					numOfFiles = 8;
				else if ( (i == TESTS_RANDOM_EXCUR_VAR) && testVector[TESTS_RANDOM_EXCUR_VAR] ) 
					numOfFiles = 18;
				else
					numOfFiles = 2;
				for ( k=0; k<numOfFiles; k++ ) {
					if ( k < 10 )
						sprintf(s, "experiments/%s/%s/data%1d", generatorDir[option],
							testNames[i], k+1);
					else if ( k < 100 )
						sprintf(s, "experiments/%s/%s/data%2d", generatorDir[option],
							testNames[i], k+1);
					else
						sprintf(s, "experiments/%s/%s/data%3d", generatorDir[option],
							testNames[i], k+1);
					generalSampleSize = computeMetrics(s,i);
					if ( (i == TESTS_RANDOM_EXCURSIONS) || (i == TESTS_RANDOM_EXCUR_VAR) ) 
						randomExcursionSampleSize = generalSampleSize;
				}
			}
			else {
				sprintf(s, "experiments/%s/%s/results", generatorDir[option],
					testNames[i]);
				generalSampleSize = computeMetrics(s, i);
			}
		}
	}

	fprintf(post, "\n\n- - - - - - - - - - - - - - - - - - - - - - - - - - - -");
	fprintf(post, "- - - - - - - - - - - - -\n");

	case1 = 0;
	case2 = 0;

	if ( testVector[TESTS_RANDOM_EXCURSIONS] || testVector[TESTS_RANDOM_EXCUR_VAR] )
		case2 = 1;

	for ( i=1; i<=NUMOFTESTS; i++ ) {
		if ( testVector[i] && (i != TESTS_RANDOM_EXCURSIONS) && (i != TESTS_RANDOM_EXCUR_VAR) ) {
			case1 = 1;
			break;
		}
	}

	if ( case1 ) {
		passRate = 0.99-3.0*sqrt(0.01*(1.0-ALPHA)/(double)generalSampleSize);
		fprintf(post, "The minimum pass rate for each statistical test with ");
		fprintf(post, "the exception of the random\nexcursion (variant) test ");
		fprintf(post, "is approximately = %f for a sample size ",passRate);
		fprintf(post, "= %d\nbinary sequences.\n\n", generalSampleSize);
	}

	if ( case2 ) {
		passRate =.99-3.*sqrt(.01*(1.-ALPHA)/(double)randomExcursionSampleSize);
		fprintf(post, "The minimum pass rate for the random excursion ");
		fprintf(post, "(variant) test is approximately\n%f for a ", passRate);
		fprintf(post, "sample size = %d binary sequences.\n\n", 
			randomExcursionSampleSize);
	}

	fprintf(post, "For further guidelines construct a probability table using ");
	fprintf(post, "the MAPLE program\nprovided in the addendum section of the ");
	fprintf(post, "documentation.\n");
	fprintf(post, "- - - - - - - - - - - - - - - - - - - - - - - - - - - -");
	fprintf(post, "- - - - - - - - - - - - -\n");

	return;
}

int CTestInProgress::computeMetrics(char *s, int test)
{
	int    i, j, pos, count, sampleSize, expCount;
	int    freqPerBin[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	double *A, *T, temp, chi2, proportion, uniformity;
	float  c;
	FILE*  fp;

	if ( DISPLAY_OUTPUT_CHANNELS )
		fprintf(output, "OPEN = %s\n", s);

	if ( (fp = fopen(s, "r")) == NULL) {
		fprintf(output, "%s", s);
		fprintf(output, " -- file not found. Exiting program.\n");
		return 0;
	}

	if ( (A = (double*)calloc(tp.numOfBitStreams, sizeof(double))) == NULL ) {
		fprintf(output, "Final Analysis Report aborted due to insufficient workspace\n");
		fflush(output);
		return 0;
	}

	/* Compute Metric 1: Proportion of Passing Sequences */

	count = 0; 		
	sampleSize = tp.numOfBitStreams;

	if ( (test == TESTS_RANDOM_EXCURSIONS) || (test == TESTS_RANDOM_EXCUR_VAR) ) { /* Special Case: Random Excursion Tests */
		if ( (T = (double*)calloc(tp.numOfBitStreams, sizeof(double))) == NULL ) {
			fprintf(output, "Final Analysis Report aborted due to insufficient workspace\n");
			fflush(output);
			return 0;
		}
		for ( j=0; j<sampleSize; j++ ) {
			fscanf(fp, "%f", &c);
			if ( (double)c > 0.000000 ) {
				T[count] = c;
				count++;
			}   
		}
		free(A);
		A = (double*)calloc(count, sizeof(double));
		for ( j=0; j<count; j++ )
			A[j] = T[j];

		sampleSize = count;
		count = 0;
		for ( j=0; j<sampleSize; j++ )
			if ( A[j] < ALPHA )
				count++;
		free(T);
	}
	else {
		for ( j=0; j<sampleSize; j++ ) {
			fscanf(fp, "%f", &c);
			if ( c < ALPHA )
				count++;
			A[j] = c;
		}
	}
	proportion = 1.0-(double)count/sampleSize;

	/* Compute Metric 2: Histogram */

//	qsort((void*)A, sampleSize, sizeof(double), cmp);

	for ( i=0; i<sampleSize-1; i++ )
		for ( j=1; j<sampleSize; j++ )
			if ( A[j] < A[i] ) {
				temp = A[i];
				A[i] = A[j];
				A[j] = temp;
			}

	for ( j=0; j<sampleSize; j++ ) {
		pos = (int)floor(A[j]*10);
		if ( pos == 10 )
			pos--;
		freqPerBin[pos]++;
	}
	chi2 = 0.0;
	expCount = sampleSize/10;
	for ( j=0; j<10; j++ )
		chi2 += pow(freqPerBin[j]-expCount,2)/expCount;
	uniformity = igamc(9.0/2.0,chi2/2.0);

	for ( j=0; j<10; j++ )			/* DISPLAY RESULTS */
		fprintf(post, "%3d ", freqPerBin[j]);

	if ( uniformity < 0.0001 )
		fprintf(post, " %f * ", uniformity);
	else
		fprintf(post, " %f   ", uniformity);

	if ( proportion < 0.96 )
		fprintf(post, "%6.4f *  %s\n", proportion, testNames[test]);
	else
		fprintf(post, "%6.4f    %s\n", proportion, testNames[test]);

	fflush(post);
	fclose(fp);
	free(A);

	return sampleSize;
}

void CTestInProgress::SHA(int hash_len, int requested_sed_level)
{
	int				i, n0, n1, bitsRead, done, ret_val;
	BYTE			*rnd_bits;
	Hash_DRBG_CTX	ctx;
	char			str[80];

	if ( (epsilon = (BitField *)calloc(tp.n, sizeof(BitField))) == NULL ) {
		fprintf(output, "Insufficient memory available.\n");
		return;
	}
	else {

		if ( ret_val = init_Hash_DRBG(&ctx, 128, hash_len) ) {
			sprintf(str, "ret_val is <%d>", ret_val);
			MessageBox(str, "ERROR", MB_OK);
			return;
		}

		rnd_bits = NULL;
		for ( i=0; i<tp.numOfBitStreams; i++ ) {
			Hash_DRBG(&ctx, tp.n, 128, &rnd_bits);
			if ( rnd_bits ) {
				n0 = n1 = bitsRead = 0;
				done = convertToBits(rnd_bits, tp.n, tp.n, &n0, &n1, &bitsRead);
//				sprintf(str, "n0 is <%d>, n1 is <%d>", n0, n1);
//				MessageBox(str, "info", MB_OK);
				switch(hash_len){
				case 160:
					nist_test_suite(GEN_SHA1);
					break;
				case 224:
					nist_test_suite(GEN_SHA224);
					break;
				case 256:
					nist_test_suite(GEN_SHA256);
					break;
				case 384:
					nist_test_suite(GEN_SHA384);
					break;
				case 512:
					nist_test_suite(GEN_SHA512);
					break;
				}
				if ( rnd_bits ) {
					free(rnd_bits);
					rnd_bits = NULL;
				}
			}
			else {
				MessageBox("HashDRBG failed to return random bits", "ERROR", MB_OK);
				return;
			}
		}
	}
}

#ifdef OLD_SHA1
void CTestInProgress::SHA1()
{
	int		keylen = 160;  /* 160 <= keylen  <= 512:  Must be a multiple of 8. */
	int		seedlen = 160; /* 160 <= seedlen <= 512:  Must be a multiple of 8. */
	BYTE	*Xkey;
	BYTE	*Xseed;
	BYTE	xval[20];
	BYTE	temp[22];
	BYTE	power2[22];
	BYTE	*G;
	int		i, n0, n1, bitsRead, length;
	int		done = 0, counter;
	BYTE	*T;
	ULONG	tx[5], ulongInt;
	FILE	*fp1;

	/* Altered by J. Soto: 12/3/99 */ 

	/* Define the 1st word in the IV */
	if ( (fp1 = fopen("data/sha-iv.dat", "r")) == NULL ) {
#ifdef STS_GUI
		MessageBox("file \"data/sha-iv.dat\" could not be opened. Exiting program.", "STS: SHA1", MB_OK);
#else
		printf("file \"data/sha-iv.dat\" could not be opened. Exiting program.\n");
#endif
		return;
	}

	fscanf(fp1, "%08lx", &ulongInt);
	fclose(fp1);

	/* Update the 1st word in the IV */
	if ( (fp1 = fopen("data/sha-iv.dat", "w")) == NULL) {
#ifdef STS_GUI
		MessageBox("file \"data/sha-iv.dat\" could not be opened. Exiting program.", "STS: SHA1", MB_OK);
#else
		printf("file \"data/sha-iv.dat\" could not be opened. Exiting program.\n");
#endif
		return;
	}
	fprintf(fp1, "%08lx",ulongInt+1);
	fclose(fp1);

	/* DEFINE IV */
	for( i=0; i<5; i++ )
		tx[i] = ulongInt + (ULONG)i;

	if ( ((epsilon = (BitField *)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((T = (BYTE*)calloc(8, sizeof(BYTE))) == NULL) ||
		 ((Xseed = (BYTE*)calloc(20, sizeof(BYTE))) == NULL) ||
		 ((Xkey  = (BYTE*)calloc(20, sizeof(BYTE))) == NULL) ) {
		fprintf(output, "Insufficient memory available.\n");
		exit(1);
	}
	else {
		bzero(T, 8);
		bzero(Xseed, 20);
		bzero(Xkey, 20);
		ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", Xseed, 20);
		ahtopb("ec822a619d6ed5d9492218a7a4c5b15d57c61601", Xkey, 20);

		bzero(xval,20);		/* temp = Xkey left padded out to 66 bytes */
		bzero(temp,22);
		bcopy(Xkey, &temp[22-keylen/8], keylen/8);
		add(temp,22,  Xseed, seedlen/8);	/* temp = temp + Xseed */

		bzero(power2,22);			/* set power2 = 2^keylen */
#ifdef LITTLE_ENDIAN
		power2[22-2] = 0x01;
#else
		power2[22-1] = 0x01;
#endif
		for (i=0;i<keylen;i++)
			bshl(power2, 22);
		Mod(temp, 22, power2, 22);			/* temp = temp mod 2&keylen */
		bcopy(&temp[22-keylen/8], xval, keylen/8);	/* xval = temp */

		length = (tp.n + 159) / 160;
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		counter = 1;
		for( i=0; i<tp.numOfBitStreams*length; i++ ) {
			G = NULL;
			shaG((BYTE *)tx, xval, keylen, &G, 160);
			done = convertToBits(G, tp.n, tp.n, &n0, &n1, &bitsRead);    
			bcopy(G, xval, 20);
			FREE(G);
			if ( done ) {
				fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
				fflush(output);
				nist_test_suite();
				done = 0;
				n0 = 0;
				n1 = 0;
				bitsRead = 0;
			}
		}
		free(epsilon);
		free(Xkey);
		free(Xseed);
		free(T);
	}

	return;
}
#endif

void CTestInProgress::lcg()
{
	double*  DUNIF, SEED;
	int      i, counter;
#ifdef CRYPTX
	int      j;
	FILE*    fp;
	char     filename[100];
#endif
	unsigned bit;
	int      n0, n1, v, bitsRead;

	SEED = 23482349.0;
	if ( ((epsilon = (BitField *)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((DUNIF = (double*)calloc(tp.n, sizeof(double))) == NULL) ) {
		fprintf(output, "Insufficient memory available.\n");
		exit(1);
	}
	counter = 1;
	for( v=0; v<tp.numOfBitStreams; v++ ) {
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		SEED = lcg_rand(tp.n, SEED,DUNIF, tp.n);
		for( i=0; i<tp.n; i++ ) {
			if ( DUNIF[i] < 0.5 ) {
				bit = 0;
				n0++;
			}
			else {
				bit = 1;
				n1++;
			}
			bitsRead++;
			epsilon[i].b = bit;
		}
#ifdef CRYPTX
		for( j=0; j<(int)floor(tp.n/32); j++ ) {
			sum = 0;
			for( i=0; i<32; i++ ) {
				sum += pow(2,31-i)*epsilon[32*j+i].b;
			}
			fwrite((void*)&sum, sizeof(unsigned long), (size_t)1, fp);
		}
#endif
		fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
		fflush(output);
		nist_test_suite(GEN_LCG);
#ifdef CRYPTX 
		counter++;
		if ( v+1 < tp.numOfBitStreams ) {
			fclose(fp);
			sprintf(filename, "lcg%d.data", counter);
			if ( (fp = fopen(filename,"wb")) == NULL ) {
#ifdef STS_GUI
#else
				printf("file: %s could not be opened. Exiting program.\n", filename);
#endif
				exit(-1);
			}
		}
#endif
	}
	free(DUNIF);
	free(epsilon);

	return;
}

void CTestInProgress::bbs()
{
	char     bit_string;
#ifdef CRYPTX
	char     filename[100];
	unsigned long sum;
	FILE*    fp;
	int      j;
#endif
	int      i, v, bitsRead, counter;
	verylong zn = 0, zx0 = 0;
	int      n0, n1;

	bbs_gen_key(256l, &zn, &zx0);
	epsilon = (BitField*)calloc(tp.n,sizeof(BitField));
	counter = 1;
	for ( v=0; v<tp.numOfBitStreams; v++ ) {
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		for ( i=0; i<tp.n; i++ ) {
			bit_string = (char) bbs_next_bits(1l, zn, &zx0);
			if ((int)bit_string == 0) {
				n0++;
				epsilon[i].b = 0;
			}
			else {
				n1++;
				epsilon[i].b = 1;
			}
			bitsRead++;
		}
#ifdef CRYPTX
		for( j=0; j<(int)floor(tp.n/32); j++ ) {
			sum = 0;
			for( i=0; i<32; i++ ) {
				sum += pow(2,31-i)*epsilon[32*j+i].b;
			}
			fwrite((void*)&sum, sizeof(unsigned long), (size_t)1, fp);
		}
#endif
		fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
		fflush(output);
#ifdef CRYPTX
		counter++;
		if (v+1 < numOfBitStreams) {
			fclose(fp);
			sprintf(filename, "bbs%d.data", counter);
			if ( (fp = fopen(filename,"wb")) == NULL) {
				printf("file: %s could not be opened. Exiting program.\n", filename);
				exit(-1);
			}
		}
#endif
		nist_test_suite(GEN_BBS);
		for ( i=0; i<tp.n; i++ )
			epsilon[i].b = 0;
		fflush(output);
	}
	zfree(&zn);
	zfree(&zx0);
	free(epsilon);

	return;
}

void CTestInProgress::micali_schnorr()
{
	char     bit_string;
	long     i = 0, j, k, r;
	int      counter;
#ifdef CRYPTX
	unsigned long sum;
	FILE*    fp;
	char     filename[100];
#endif
	verylong ze = 0, zn = 0, zx = 0, zy = 0, zz = 0;
	int      n0, n1, v, bitsRead;

	if ( (epsilon = (BitField*)calloc(tp.n, sizeof(BitField))) == NULL) {
#ifdef STS_GUI
#else
		printf("Error in Micali_Schnorr:  Insufficient Work Space!\n");
#endif
		return;
	}
	/*fp = fopen("ms1.data","wb");*/
	counter = 1;
	for( v=0; v<tp.numOfBitStreams; v++ ) {
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		i = 0;
		/* fill the buffer to be tested */
		Micali_Schnorr_gen_key(256l, &ze, &zn, &zx, &k, &r);
		while ( i < tp.n ) {
			Micali_Schnorr_next_bits(k, r, ze, zn, &zx, &zz);
			for ( j=0; j<k; j++ ) {
				zlowbits(zz, 1l, &zy);
				if ( i < tp.n ) {
					bit_string = (char) ztoint(zy);
					if ( (int)bit_string == 0 ) {
						epsilon[i++].b = 0; 
						n0++;
					}
					else {
						epsilon[i++].b = 1; 
						n1++;
					}
					bitsRead++;
				}
				zrshift(zz, 1l, &zy);
				zcopy(zy, &zz);
			}
		}
#ifdef CRYPTX
		for( j=0; j<(int)floor(tp.n/32); j++ ) {
			sum = 0;
			for( i=0; i<32; i++ ) {
				sum += pow(2,31-i)*epsilon[32*j+i].b;
			}
			fwrite((void*)&sum,sizeof(unsigned long),(size_t)1,fp);
		}
#endif
		fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
		fflush(output);
#ifdef CRYPTX
		counter++;
		if ( v+1 < tp.numOfBitStreams ) {
			fclose(fp);
			sprintf(filename, "ms%d.data", counter);
			if ( (fp = fopen(filename,"wb")) == NULL ) {
				printf("file: %s could not be opened. Exiting program.\n", filename);
				exit(-1);
			}
		}
#endif
		nist_test_suite(GEN_MS);
		for ( i=0; i<tp.n; i++ )
			epsilon[i].b = 0;
	}
	zfree(&ze);
	zfree(&zn);
	zfree(&zx);
	zfree(&zy);
	zfree(&zz);

	return;
}

void CTestInProgress::quadRes1()
{
	int   k, n0, n1, counter, bitsRead, length, done;
	BYTE  *p, *g, *x, *T;

	if ( ((epsilon = (BitField*)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((p = (BYTE*) calloc(MAXPLEN, sizeof(BYTE))) == NULL) ||
		 ((g = (BYTE*) calloc(MAXPLEN, sizeof(BYTE))) == NULL) ||
		 ((T = (BYTE*) calloc(8, sizeof(BYTE))) == NULL) ||
		 ((x = (BYTE*) calloc(MAXPLEN, sizeof(BYTE))) == NULL)) {
		fprintf(output, "\t\tInsufficient Working Space Allocated in quadRes1()\n");
	}
	else {
		length = (tp.n + 511) / 512;
		bzero(p, MAXPLEN);
		bzero(g, MAXPLEN);
		ahtopb("987b6a6bf2c56a97291c445409920032499f9ee7ad128301b5d0254aa1a9633fdbd378d40149f1e23a13849f3d45992f5c4c6b7104099bc301f6005f9d8115e1", p, 64);
		ahtopb("42985722352572398592585235972389598235232283798723ab348d4582c9384d384c23483489acbdb234b2234bacb35b2a45252c384238448275ac34234933", g, 64);

		n0 = 0;
		n1 = 0;
		done = 0;
		bitsRead = 0;
		counter = 1;
		for( k=0; k<tp.numOfBitStreams*length; k++ ) {
			bzero(x, MAXPLEN);
			ModMult(x, g, 64, g, 64, p,64);
			//done = convertToBits(x, tp.n, &n0, &n1, &bitsRead, 64, 16);
			done = convertToBits(x+64, 512, tp.n, &n0, &n1, &bitsRead);
			bzero(g, MAXPLEN);
			bcopy(x+64, g, 64);
			if ( done ) {
				fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
				fflush(output);
				nist_test_suite(GEN_QCG1);
				n0 = 0;
				n1 = 0;
				done = 0;
				bitsRead = 0;
			}
		}
		free(p);
		free(g);
		free(x);
		free(T);
		free(epsilon);
	}

	return;
}

void CTestInProgress::quadRes2()
{
	BYTE  *g, *x, *t1, *t2;
	BYTE  *a, *b, *c, *T;
	int    k, n0, n1, counter, bitsRead, length, done;

	if ( ((epsilon = (BitField*)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((a = (BYTE*)calloc(2,sizeof(BYTE))) == NULL) ||
		 ((b = (BYTE*)calloc(2,sizeof(BYTE))) == NULL) ||
		 ((c = (BYTE*)calloc(2,sizeof(BYTE))) == NULL) ||
		 ((t1 = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
		 ((t2 = (BYTE*)calloc(2*MAXPLEN,sizeof(BYTE))) == NULL) ||
		 ((g = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
		 ((T = (BYTE*) calloc(8,sizeof(BYTE))) == NULL) ||
		 ((x = (BYTE*)calloc(3*MAXPLEN,sizeof(BYTE))) == NULL)) {
		fprintf(output, "\t\tInsufficient Working Space Allocated in quadRes2()\n");
	}
	else {
#ifdef LITTLE_ENDIAN
		a[0] = 0x01;
		a[1] = 0x00;
		b[0] = 0x02;
		b[1] = 0x00;
		c[0] = 0x03;
		c[1] = 0x00;
#else
		a[0] = 0x00;
		a[1] = 0x01;
		b[0] = 0x00;
		b[1] = 0x02;
		c[0] = 0x00;
		c[1] = 0x03;
#endif

		length = (tp.n + 511) / 512;
		ahtopb("7844506a9456c564b8b8538e0cc15aff46c95e69600f084f0657c2401b3c244734b62ea9bb95be4923b9b7e84eeaf1a224894ef0328d44bc3eb3e983644da3f5", g, 64);

		n0 = 0;
		n1 = 0;
		done = 0;
		counter = 1;
		bitsRead = 0;

		for( k=0; k<tp.numOfBitStreams*length; k++ ) {
			Mult(t1, g, 64, b, 2);			/* 2x */
			add(t1, 66, c, 2);				/* 2x+3 */
			Mult(x, t1, 128, g, 64);		/* x(2x+3) */
			add(x, 128+2, a, 2);			/* x(2x+3)+1 */
			//done = convertToBits(x, tp.n, &n0, &n1, &bitsRead, 66, 16);
			done = convertToBits(x+66, 512, tp.n, &n0, &n1, &bitsRead);
			bzero(g, MAXPLEN);
			bcopy(x+66, g, 64);
			bzero(x, 3*MAXPLEN);
			bzero(t1, MAXPLEN);
			bzero(t2, 2*MAXPLEN);
			if ( done ) {
				fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
				fflush(output);
				nist_test_suite(GEN_QCG2);
				n0 = 0;
				n1 = 0;
				done = 0;
				bitsRead = 0;
			}
		}
		free(g);
		free(x);
		free(a);
		free(b);
		free(c);
		free(T);
		free(epsilon);
	}

	return;
}

void CTestInProgress::cubicRes()
{
	BYTE  *g, *x, *t1, *T;
	int    k, n0, n1, counter, bitsRead, length, done;

	if ( ((epsilon = (BitField*)calloc(tp.n,sizeof(BitField))) == NULL) ||
		 ((t1 = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
		 ((g = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
		 ((T = (BYTE*) calloc(8,sizeof(BYTE))) == NULL) ||
		 ((x = (BYTE*)calloc(2*MAXPLEN,sizeof(BYTE))) == NULL)) {
		fprintf(output,"\t\tInsufficient Working Space Allocated in cubicRes()\n");
	}
	else {
		ahtopb("7844506a9456c564b8b8538e0cc15aff46c95e69600f084f0657c2401b3c244734b62ea9bb95be4923b9b7e84eeaf1a224894ef0328d44bc3eb3e983644da3f5", g, 64);
		length = (tp.n + 511) / 512;
		n0 = 0;
		n1 = 0;
		done = 0;
		counter = 1;
		bitsRead = 0;
		for( k=0; k<tp.numOfBitStreams*length; k++ ) {
			Mult(t1,g,64,g,64);
			Mult(x,t1,128,g,64);
			//done = convertToBits(x,tp.n,&n0,&n1,&bitsRead,128,16);
			done = convertToBits(x+128, 512, tp.n,&n0, &n1, &bitsRead);
			bzero(g,MAXPLEN);
			bcopy(x+128,g,64);
			bzero(x,2*MAXPLEN);
			bzero(t1,MAXPLEN);
			if ( done ) {
				fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
				fflush(output);
				nist_test_suite(GEN_CCG);
				n0 = 0;
				n1 = 0;
				done = 0;
				bitsRead = 0;
			}
		}
		free(g);
		free(x);
		free(t1);
		free(T);
		free(epsilon);
	}

	return;
}

void CTestInProgress::exclusiveOR()
{
#ifdef CRYPTX
	int		j, k;
	char	filename[100];
	FILE*	fp;
	unsigned long sum;
#endif

	int		i, n0, n1, counter, bitsRead, done, fileCounter;
	char	*bit_sequence;

	if ( ((epsilon = (BitField*)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((bit_sequence = (char*)calloc(128, sizeof(char))) == NULL) ) {
		fprintf(output, "\t\tInsufficient Working Space Allocated in exclusiveOR()\n");
	}
	else {
		strcpy(bit_sequence,"0001011011011001000101111001001010011011101101000100000010101111111010100100001010110110000000000100110000101110011111111100111");
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		for( i=0; i<127; i++ ) {
			if ( bit_sequence[i] == '0' ) {
				epsilon[bitsRead].b = 0;
				n0++;
			}
			else {
				epsilon[bitsRead].b = 1;
				n1++;
			}
			bitsRead++;
		}
		fileCounter = 1;
		counter = 0;
		done = 0;
		for( i=127; i<tp.n*tp.numOfBitStreams; i++ ) {
			if ( bit_sequence[(i-1)%127] != bit_sequence[(i-127)%127] ) {
				bit_sequence[i%127] = '1';
				epsilon[bitsRead].b = 1;
				n1++;
			}
			else {
				bit_sequence[i%127] = '0';
				epsilon[bitsRead].b = 0;
				n0++;
			}
			bitsRead++;
			counter++;
			if ( bitsRead == tp.n )
				done = 1;
			if ( done ) {
#ifdef CRYPTX
			for( j=0; j<(int)floor(tp.n/32); j++ ) {
				sum = 0;
				for( k=0; k<32; k++ ) {
					sum += pow(2,31-k)*epsilon[32*j+k].b;
				}
				fwrite((void*)&sum, sizeof(unsigned long), (size_t)1, fp);
			}
#endif
			fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
			fflush(output);
			nist_test_suite(GEN_XOR);
#ifdef CRYPTX
			fileCounter++;
			if ( fileCounter-1 < tp.numOfBitStreams ) {
				fclose(fp);
				sprintf(filename, "xor%d.data", fileCounter);
				if ( (fp = fopen(filename,"wb")) == NULL ) {
#ifdef STS_GUI
#else
					printf("File %s could not be opened. Exiting program.\n", filename);
#endif
					exit(-1);
				}
			}
#endif
			n0 = 0;
			n1 = 0;
			done = 0;
			bitsRead = 0;
			}
		}
		free(bit_sequence);
		free(epsilon);
	}

	return;
}

void CTestInProgress::ANSI()
{
	BYTE	Key1[8], Key2[8], DT[8], V[8], G[8];
	TDESCTX	context;

	//BYTE	*T, *Xkey, *Xseed, G[DSA_H_SIZE];
	int		i, n0, n1, bitsRead, done, length, counter;

	if ( ((epsilon = (BitField *)calloc(tp.n, sizeof(BitField))) == NULL) ) {
		fprintf(output,"Insufficient memory available.\n");
		exit(1);
	}
	else {
		/*
	if ( ((epsilon = (BitField *)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((T = (BYTE*)calloc(8, sizeof(BYTE))) == NULL) ||
		 ((Xseed = (BYTE*)calloc(20, sizeof(BYTE))) == NULL) ||
		 ((Xkey  = (BYTE*)calloc(20, sizeof(BYTE))) == NULL) ) {
		fprintf(output,"Insufficient memory available.\n");
		exit(1);
	}
	else {
		bzero(T, 8);
		bzero(Xseed, 20);
		bzero(Xkey, 20);
		bzero(G, 20);
		ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", Xseed, 20);
		ahtopb("ec822a619d6ed5d9492218a7a4c5b15d57c61601", Xkey, 20);
		*/

		// Key1 = 75c7 1ae5 a11a 232c
		Key1[0] = 0x75; Key1[1] = 0xc7;
		Key1[2] = 0x1a; Key1[3] = 0xe5;
		Key1[4] = 0xa1; Key1[5] = 0x1a;
		Key1[6] = 0x23; Key1[7] = 0x2c;

		// Key2 = 4025 6dcd 94f7 67b0
		Key2[0] = 0x40; Key2[1] = 0x25;
		Key2[2] = 0x6d; Key2[3] = 0xcd;
		Key2[4] = 0x94; Key2[5] = 0xf7;
		Key2[6] = 0x67; Key2[7] = 0xb0;

		// DT = c89a 1d88 8ed1 2f3c
		DT[0] = 0xc8; DT[1] = 0x9a;
		DT[2] = 0x1d; DT[3] = 0x88;
		DT[4] = 0x8e; DT[5] = 0xd1;
		DT[6] = 0x2f; DT[7] = 0x3c;

		// V = 8000 0000 0000 0000
		V[0] = 0x80; V[1] = 0x00;
		V[2] = 0x00; V[3] = 0x00;
		V[4] = 0x00; V[5] = 0x00;
		V[6] = 0x00; V[7] = 0x00;

		ANSIX931Init(&context, Key1, Key2);

		length = (tp.n + 63) / 64;
		n0 = 0;
		n1 = 0;
		done = 0;
		bitsRead = 0;
		counter = 1;
		for( i=0; i<tp.numOfBitStreams*length; i++ ) {
			//G_from_ANSI(Xkey, Xseed, G);
			ANSIX931GenR(&context, V, DT, G);
			//done = convertToBits(G, tp.n, &n0, &n1, &bitsRead, 0, 2);
			done = convertToBits(G, 64, tp.n, &n0, &n1, &bitsRead);
			if ( done ) {
				fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
				fflush(output);
				nist_test_suite(GEN_ANSI);
				done = 0;
				n0 = 0;
				n1 = 0;
				bitsRead = 0;
			}
			//bzero(Xseed, 20);
			//mbcopy(G, Xseed, 20);
		}
		free(epsilon);
		/*
		free(T);
		free(Xseed);
		free(Xkey);
		*/
		return;
	}
}

void CTestInProgress::DES()
{
	int    keylen = 160;  /* 160 <= keylen  <= 512:  Must be a multiple of 8. */
	int    seedlen = 160; /* 160 <= seedlen <= 512:  Must be a multiple of 8. */
	BYTE   *Xkey;
	BYTE   *X;
	BYTE   *Q_;
	BYTE   *Xseed;
	BYTE   xval[64];
	BYTE   temp[66];
	BYTE   power2[66];
	BYTE   one[2];
	BYTE   G[DSA_H_SIZE];
	int    k, n0, n1, bitsRead, length;
	int    done = 0;
	BYTE   *T;
	int    counter;

	if ( ((epsilon = (BitField *)calloc(tp.n,sizeof(BitField))) == NULL) ||
		 ((T = (BYTE*)calloc(8,sizeof(BYTE))) == NULL) ) {
		fprintf(output,"Insufficient memory available.\n");
		exit(1);
	}
	else {
		Xseed = (BYTE*)calloc(20, sizeof(BYTE));
		Xkey  = (BYTE*)calloc(20, sizeof(BYTE));
		Q_    = (BYTE*)calloc(20, sizeof(BYTE));
		X     = (BYTE*)calloc(20, sizeof(BYTE));
		bzero(T, 8);
		bzero(Xseed, 20);
		bzero(Xkey, 20);
		bzero(X, 20);
		bzero(Q_, 20);

		bzero(power2, 66);				/* set power2 = 2^keylen */
#ifdef LITTLE_ENDIAN
		power2[66-keylen/8-2] = 0x01;
#else
		power2[66-keylen/8-1] = 0x01;
#endif

		bzero(one,2);
#ifdef LITTLE_ENDIAN
		one[0] = 0x01;
#else
		one[1] = 0x01;
#endif

		ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", Xseed, 20);
		ahtopb("ec822a619d6ed5d9492218a7a4c5b15d57c61601", Xkey, 20);
		ahtopb("b32a3033fbd7ba96168a6c396e760c2b1f5a3143", Q_, 20);
		bzero(xval, 64);	/* temp = Xkey left padded out to 66 bytes */
		bzero(temp, 66);
		bcopy(Xkey, &temp[66-keylen/8], keylen/8);
		add(temp, 66,  Xseed, seedlen/8);	/* temp = temp + Xseed */

		Mod(temp, 66, power2, 66);			/* temp = temp mod 2&keylen */
		bcopy(&temp[66-keylen/8], xval, keylen/8);	/* xval = temp */
		length = (tp.n + 159) / 160;
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		counter = 1;
		for( k=0; k<tp.numOfBitStreams*length; k++ ) {
			//G_from_DES(Xkey, Xseed, G);
			desG(Xkey, Xseed, G);
			//done = convertToBits(G, tp.n, &n0, &n1, &bitsRead, 0, 5);
			done = convertToBits(G, 160, tp.n, &n0, &n1, &bitsRead);
			if (done) {
				fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
				fflush(output);
				nist_test_suite(GEN_DES);
				done = 0;
				n0 = 0;
				n1 = 0;
				bitsRead = 0;
			}
			Mod(G, DSA_H_SIZE, Q_, DSA_Q_SIZE);
			bcopy(G, X, DSA_Q_SIZE);

			/* Update XKEY : Compute XKEY = (1+XKEY+X) mod 2^keylen */
			bzero(temp, 66);				/* temp = Xkey */
			bcopy(Xkey, &temp[66-keylen/8], keylen/8);
			add(temp, 66,  X, DSA_X_SIZE);		/* temp = temp + X */
			add(temp, 66, one, 2);			/* temp = temp + 1 */ 

			Mod(temp, 66, power2, 66); 		/* temp = temp mod 2&keylen */
			bcopy(&temp[66-keylen/8], Xkey, keylen/8); /* Xkey = temp */
		}
		free(T);
		free(Xseed);
		free(Xkey);
		free(Q_);
		free(X);
		free(epsilon);
	}
	return;
}

void CTestInProgress::modExp()
{
	int		k, n0, n1, counter, bitsRead, length, done;
	BYTE	*p, *g, *x, *y, *T;

	length = (tp.n + 511) / 512;
	if ( ((epsilon = (BitField*)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((p = (BYTE*)calloc(MAXPLEN, sizeof(BYTE))) == NULL) ||
		 ((g = (BYTE*)calloc(MAXPLEN, sizeof(BYTE))) == NULL) ||
		 ((x = (BYTE*)calloc(2*MAXPLEN, sizeof(BYTE))) == NULL) ||
		 ((T = (BYTE*)calloc(8, sizeof(BYTE))) == NULL) ||
		 ((y = (BYTE*)calloc(MAXPLEN, sizeof(BYTE))) == NULL) ) { 
		fprintf(output, "\t\tInsufficient Working Space Allocated in modExp()\n");
	}
	else {
		bzero(y, MAXPLEN);
		bzero(p, MAXPLEN);
		bzero(g, MAXPLEN);
		ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", y, 20);
		ahtopb("8a21a3c5a1953e30c99ac30cec5adaecee15f0d21f6d9f84b90a48b04eed5e7b814a6f57272c39beb738c65b9bf9528539d4300d9cec0b713c2c5f6cb5c78679", p, 64);
		ahtopb("10d6333cfac8e30e808d2192f7c0439480da79db9bbca1667d73be9a677ed31311f3b830937763837cb7b1b1dc75f14eea417f84d9625628750de99e7ef1e976", g, 64);
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		done = 0;
		counter = 1;
		for( k=0; k<tp.numOfBitStreams*length; k++ ) {
			bzero(x, 2*MAXPLEN);
			ModExp(x, g, 64, y, 20, p, 64);	      /* NOTE:  g must be less than p */
			//done = convertToBits(x, tp.n, &n0, &n1, &bitsRead, 0, 16);
			done = convertToBits(x, 512, tp.n, &n0, &n1, &bitsRead);
			bzero(y,MAXPLEN);
			bcopy(x+44,y,20);
			if ( done ) {
				fprintf(output, "\t\tBITSREAD = %d 0s = %d 1s = %d\n", bitsRead, n0, n1);
				fflush(output);
				nist_test_suite(GEN_MODEXP);
				n0 = 0;
				n1 = 0;
				done = 0;
				bitsRead = 0;
			}
		}
		free(p);
		free(g);
		free(x);
		free(y);
		free(T);
		free(epsilon);
	}

	return;
}
