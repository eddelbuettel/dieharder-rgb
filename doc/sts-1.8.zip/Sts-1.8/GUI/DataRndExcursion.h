#if !defined(AFX_DATARNDEXCURSION_H__F0E18BAD_38BD_4806_BCA8_08A00114F72D__INCLUDED_)
#define AFX_DATARNDEXCURSION_H__F0E18BAD_38BD_4806_BCA8_08A00114F72D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataRndExcursion.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataRndExcursion dialog

class CDataRndExcursion : public CDialog
{
// Construction
public:
	CDataRndExcursion(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataRndExcursion)
	enum { IDD = IDD_DataRndExcursion };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataRndExcursion)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataRndExcursion)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATARNDEXCURSION_H__F0E18BAD_38BD_4806_BCA8_08A00114F72D__INCLUDED_)
