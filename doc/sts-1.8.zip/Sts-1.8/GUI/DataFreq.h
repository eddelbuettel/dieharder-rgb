#if !defined(AFX_DATAFREQ_H__B44DAF0B_D227_4129_862D_BDEF6714112F__INCLUDED_)
#define AFX_DATAFREQ_H__B44DAF0B_D227_4129_862D_BDEF6714112F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataFreq.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataFreq dialog

class CDataFreq : public CDialog
{
// Construction
public:
	CDataFreq(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataFreq)
	enum { IDD = IDD_DataFreq };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataFreq)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataFreq)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATAFREQ_H__B44DAF0B_D227_4129_862D_BDEF6714112F__INCLUDED_)
