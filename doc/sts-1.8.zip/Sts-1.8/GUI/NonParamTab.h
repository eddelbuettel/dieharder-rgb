#if !defined(AFX_NONPARAMTAB_H__7FFA4F41_8AB6_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_NONPARAMTAB_H__7FFA4F41_8AB6_11D6_8735_00045A48D764__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NonParamTab.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNonParamTab dialog

class CNonParamTab : public CPropertyPage
{
	DECLARE_DYNCREATE(CNonParamTab)

// Construction
public:

	void selectAll(bool state);
	CNonParamTab();
	~CNonParamTab();

// Dialog Data
	//{{AFX_DATA(CNonParamTab)
	enum { IDD = IDD_NonParamTab };
	CButton	m_Runs;
	CButton	m_Rank;
	CButton	m_RandomExcrVar;
	CButton	m_RandomExcr;
	CButton	m_LongestRuns;
	CButton	m_Frequency;
	CButton	m_Dfft;
	CButton	m_Cumsums;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CNonParamTab)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CNonParamTab)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NONPARAMTAB_H__7FFA4F41_8AB6_11D6_8735_00045A48D764__INCLUDED_)
