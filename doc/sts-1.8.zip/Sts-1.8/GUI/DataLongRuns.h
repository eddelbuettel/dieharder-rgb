#if !defined(AFX_DATALONGRUNS_H__7DDA0F00_D54D_4B1C_9D25_B4712627A1AB__INCLUDED_)
#define AFX_DATALONGRUNS_H__7DDA0F00_D54D_4B1C_9D25_B4712627A1AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataLongRuns.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataLongRuns dialog

class CDataLongRuns : public CDialog
{
// Construction
public:
	CDataLongRuns(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataLongRuns)
	enum { IDD = IDD_DataLongRuns };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataLongRuns)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataLongRuns)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATALONGRUNS_H__7DDA0F00_D54D_4B1C_9D25_B4712627A1AB__INCLUDED_)
