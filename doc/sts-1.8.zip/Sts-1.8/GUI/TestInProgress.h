#if !defined(AFX_TESTINPROGRESS_H__7AD4BB81_AEE6_47C3_B95C_07C4D914100A__INCLUDED_)
#define AFX_TESTINPROGRESS_H__7AD4BB81_AEE6_47C3_B95C_07C4D914100A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestInProgress.h : header file
//
#include "GenOptions1.h"
#include "TestSelection2.h"
#define MAX_NUM_TESTS     16

/////////////////////////////////////////////////////////////////////////////
// CTestInProgress dialog

class CTestInProgress : public CDialog
{
// Construction
public:
	CTestInProgress(CWnd* pParent = NULL);   // standard constructor
	
	void	invokeTestSuite(int option, char* streamFile);
	int		openOutputStreams(int option);
	void	nist_test_suite(int option);
	void	fileBasedBitStreams(char** streamFile);
	void	readBinaryDigitsInASCIIFormat(FILE*, char*);
	void	readHexDigitsInBinaryFormat(FILE*);
	void	partitionResultFile(int numOfFiles, int numOfSequences,
								int option, int category);
	void	postProcessResults(int option);
	int		computeMetrics(char* s, int test);
	void	SHA(int hash_len, int requested_sec_level);
	void	lcg();
	void	bbs();
	void	micali_schnorr();
	void	modExp();
	void	quadRes1();
	void	quadRes2();
	void	cubicRes();
	void	exclusiveOR();
	void	ANSI();
	void	DES();

	CTestSelection2	*m_pTestSelection;
	CGenOptions1	*m_pGenOptions;

	int			mFreqCtr;
	int			mBlkFreqCtr;
	int			mCumSumCtr;
	int			mRunsCtr;
	int			mLongRunsCtr;
	int			mRankCtr;
	int			mDFFTCtr;
	int			mNonPerTempCtr;
	int			mOverlapTempCtr;
	int			mUniversalCtr;
	int			mApenCtr;
	int			mRndExcursionCtr;
	int			mRndExcursionVarCtr;
	int			mSerialCtr;
	int			mLinComplexCtr;

// Dialog Data
	//{{AFX_DATA(CTestInProgress)
	enum { IDD = IDD_Testing_In_Progress };
	CButton	m_IdOK;
	CProgressCtrl	m_Freq_Prog;
	CProgressCtrl	m_BlockFreq_Prog;
	CProgressCtrl	m_CumSum_Prog;
	CProgressCtrl	m_Runs_Prog;
	CProgressCtrl	m_LongRuns_Prog;
	CProgressCtrl	m_Rank_Prog;
	CProgressCtrl	m_DFFT_Prog;
	CProgressCtrl	m_NonPerTemp_Prog;
	CProgressCtrl	m_OverlapTemp_Prog;
	CProgressCtrl	m_Universal_Prog;
	CProgressCtrl	m_Apen_Prog;
	CProgressCtrl	m_RndExcursion_Prog;
	CProgressCtrl	m_RndExcursionVar_Prog;
	CProgressCtrl	m_Serial_Prog;
	CProgressCtrl	m_LinComplex_Prog;
	CButton			m_RunTests;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestInProgress)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTestInProgress)
	afx_msg void OnRunTests();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTINPROGRESS_H__7AD4BB81_AEE6_47C3_B95C_07C4D914100A__INCLUDED_)
