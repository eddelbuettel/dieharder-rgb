// TestConfirmation3.cpp : implementation file
//
#include <stdio.h>
#include "stdafx.h"
#include "StsGui.h"
#include "TestConfirmation3.h"
#include "defs.h"
#include "externs.h"
//#include "proto.h"
//#include "utilities2.h"
//#include "sts.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestConfirmation3 property page

IMPLEMENT_DYNCREATE(CTestConfirmation3, CPropertyPage)

CTestConfirmation3::CTestConfirmation3() : CPropertyPage(CTestConfirmation3::IDD)
{
	//{{AFX_DATA_INIT(CTestConfirmation3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_isFirstDisplayed = TRUE;
	// Setting brush, which will paint the background of the listbox, to light grey
	m_brush.CreateSolidBrush(RGB(192,192,192));
}

CTestConfirmation3::~CTestConfirmation3()
{
}

void CTestConfirmation3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestConfirmation3)
	DDX_Control(pDX, IDC_Info, m_InfoListBox);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestConfirmation3, CPropertyPage)
	//{{AFX_MSG_MAP(CTestConfirmation3)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestConfirmation3 message handlers

HBRUSH CTestConfirmation3::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO: Change any attributes of the DC here
	if (pWnd->GetDlgCtrlID() == IDC_Info) {
		pDC->SetTextColor(RGB(1, 1, 1));  // == black

		// Set the background mode for text to transparent 
		// so background will show thru.
		pDC->SetBkMode(TRANSPARENT);

		// Return handle to our CBrush object
		hbr = m_brush;
	}

	//pDC->SetBkColor(RGB(0, 0, 255));
	//CDC::SetBkColor(RGB(0, 0, 255));
		
	// TODO: Return a different brush if the default is not desired
	return hbr;
}


BOOL CTestConfirmation3::OnSetActive() 
{
	// TODO: Add your specialized code here and/or call the base class
/*
	// Re-setting testVector array
	for (int i=1; i<=MAX_NUM_TESTS; i++)
		testVector[i] = FALSE;

	// Updating listbox info
	m_pGenOptions->UpdateData(TRUE);
	m_pTestSelection->UpdateData(TRUE);
*/
	if ( m_isFirstDisplayed )
		initListBox();
	else
		updateListBox();
	m_isFirstDisplayed = FALSE;

	return CPropertyPage::OnSetActive();
}

void CTestConfirmation3::updateListBox()
{	
	// Updating Generator info
	while(m_InfoListBox.GetCount())
		m_InfoListBox.DeleteString(0);
	initListBox();
}

void CTestConfirmation3::initListBox()
{
	// Adding Generator info
	m_InfoListBox.AddString(" Generator Selected");
	CString padding = "       *  ";

	if (m_pGenOptions->m_isInputFileSelected) {
		//m_InfoListBox.AddString(padding + m_pGenOptions->getGenerator() + m_pGenOptions->getInputFileName());
		m_InfoListBox.AddString(padding + m_pGenOptions->getGenerator() + m_pGenOptions->m_inputFile);
		padding += "Input Mode: ";
		int mode = m_pGenOptions->m_inputMode.GetCurSel();
		if (mode == 0)
			m_InfoListBox.AddString(padding+" Bits in ASCII format");
		else
			m_InfoListBox.AddString(padding+" Hex digits in binary format");
	}

	else
		m_InfoListBox.AddString(padding + m_pGenOptions->getGenerator());

	m_InfoListBox.AddString("");

	// Adding Sequences info
	padding = " Number of sequences: ";
	char temp[20];

	m_pTestSelection->m_numSequences.GetLine(0, temp, 10);
	m_InfoListBox.AddString(padding+temp);
	m_InfoListBox.AddString("");
	
	padding = " Length of sequences:  ";
	m_pTestSelection->m_lenSequences.GetLine(0, temp, 10);
	m_InfoListBox.AddString(padding+temp);
	m_InfoListBox.AddString("");
	
	// Adding Test info
	m_InfoListBox.AddString(" ********************************************************************");
	// this line below looks too long, but it appears correctly in output
	m_InfoListBox.AddString(" *                              Test Information                                 *");
	m_InfoListBox.AddString(" ********************************************************************");
	insertTestSelectionInfo();
	
}

void CTestConfirmation3::insertTestSelectionInfo()
{
	int		paramCtr = 0, NonParamCtr = 0, ID;
	bool	isNone = TRUE;
	m_InfoListBox.AddString(" Non-parameterized tests selected:");

	// ****** if new tests are added, the following loops will *******
	// ******       have to be modified to include them        *******

	// Going through all NonParam Tests to see which ones were selected,
	// and display the selected tests in list box
	for ( ID=IDC_CHECK_Frequency; ID<=IDC_CHECK_LempelZivCmp; ID++ ) {
		if ( m_pTestSelection->m_pNonParamTab->IsDlgButtonChecked(ID) ) {
			isNone = FALSE;
			char	temp[40];
			sprintf(temp, "   %d)  ",++NonParamCtr);
			CString	padding(temp);
			switch (ID) {
				case IDC_CHECK_Frequency:
					m_InfoListBox.AddString(padding+"Frequency");
					testVector[TESTS_FREQUENCY] = TRUE;
					break;
				case IDC_CHECK_Cumsums:
					m_InfoListBox.AddString(padding+"Cumulative Sums");
					testVector[TESTS_CUM_SUMS] = TRUE;
					break;
				case IDC_CHECK_Runs:
					m_InfoListBox.AddString(padding+"Runs");
					testVector[TESTS_RUNS] = TRUE;
					break;
				case IDC_CHECK_LongestRuns:
					m_InfoListBox.AddString(padding+"Longest Runs");
					testVector[TESTS_LONGEST_RUNS] = TRUE;
					break;
				case IDC_CHECK_Rank:
					m_InfoListBox.AddString(padding+"Rank");
					testVector[TESTS_RANK] = TRUE;
					break;
				case IDC_CHECK_DFFT:
					m_InfoListBox.AddString(padding+"Spectral DFT");
					testVector[TESTS_DFFT] = TRUE;
					break;
				case IDC_CHECK_RandomExcr:
					m_InfoListBox.AddString(padding+"Random Excursion");
					testVector[TESTS_RANDOM_EXCURSIONS] = TRUE;
					break;
				case IDC_CHECK_RandomExcrVar:
					m_InfoListBox.AddString(padding+"Random Excursion Variant");
					testVector[TESTS_RANDOM_EXCUR_VAR] = TRUE;
					break;
			}
		}
	}

	if (isNone)
		m_InfoListBox.AddString("   NONE");
	m_InfoListBox.AddString("");
	m_InfoListBox.AddString(" Parameterized tests selected:");
	isNone = TRUE;

	// Going through all Param Tests to see which ones are selected,
	// and displaying them in the list box
	for (ID=IDC_CHECK_BFQCY; ID<=IDC_CHECK_UNIVL; ID++) {
		if (m_pTestSelection->m_pParamTab->IsDlgButtonChecked(ID)) {
			isNone = FALSE;
			char temp[40];
			sprintf(temp, "   %d)  ",++paramCtr);
			CString padding(temp);
			switch(ID) {
				case IDC_CHECK_BFQCY:
					m_InfoListBox.AddString(padding+"Block Frequency");
					m_InfoListBox.AddString("             block length: "+m_pTestSelection->m_pParamTab->getBFQCYBlockLen());
					testVector[TESTS_BLOCK_FREQUENCY] = TRUE;
					break;

				case IDC_CHECK_OVERL_TEMPL:
					m_InfoListBox.AddString(padding+"Overlapping Templates");
					m_InfoListBox.AddString("            template length: "+m_pTestSelection->m_pParamTab->getOverLappingTemplLen());
					testVector[TESTS_OVERLAPPING_TEMPL] = TRUE;
					break;

				case IDC_CHECK_NONP_TEMPL:
					m_InfoListBox.AddString(padding+"Non-overlapping Templates");
					m_InfoListBox.AddString("            template length: "+m_pTestSelection->m_pParamTab->getNonPTemplLen());
					testVector[TESTS_NONPERIODIC_TEMPL] = TRUE;
					break;

				case IDC_CHECK_SERIAL:
					m_InfoListBox.AddString(padding+"Serial");
					m_InfoListBox.AddString("             block length: "+m_pTestSelection->m_pParamTab->getSerialBlockLen());
					testVector[TESTS_SERIAL] = TRUE;
					break;

				case IDC_CHECK_APEN:
					m_InfoListBox.AddString(padding+"Approximate Entropy");
					m_InfoListBox.AddString("             block length: "+m_pTestSelection->m_pParamTab->getAPENBlockLen());
					testVector[TESTS_APEN] = TRUE;
					break;

				case IDC_CHECK_LINEAR_COMPL:
					m_InfoListBox.AddString(padding+"Linear Complexity");
					m_InfoListBox.AddString("             block length: "+m_pTestSelection->m_pParamTab->getLinearCmplBlockLen());
					testVector[TESTS_LINEAR_COMPLEXITY] = TRUE;
					break; 

				case IDC_CHECK_UNIVL:
					m_InfoListBox.AddString(padding+"Universal");
					m_InfoListBox.AddString("             block length: "+m_pTestSelection->m_pParamTab->getUniversalBlockLen());
					m_InfoListBox.AddString("             number of blocks: "+m_pTestSelection->m_pParamTab->getUniversalNumBlocks());
					testVector[TESTS_UNIVERSAL] = TRUE;
					break;
			}
		}
	}

	if ( isNone )
		m_InfoListBox.AddString("   NONE");
	m_InfoListBox.AddString("");
	m_InfoListBox.AddString(" ------------------------------------------------------");
	char totalTests[20];
	memset(totalTests, '\0', 20);
	sprintf(totalTests, " Total number of tests selected: %d", paramCtr+NonParamCtr);
	m_InfoListBox.AddString(totalTests);
}

LRESULT CTestConfirmation3::OnWizardNext() 
{
	return CPropertyPage::OnWizardNext();
}
