// StsGui.h : main header file for the STSGUI application
//

#if !defined(AFX_STSGUI_H__515D32A4_8A99_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_STSGUI_H__515D32A4_8A99_11D6_8735_00045A48D764__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CStsGuiApp:
// See StsGui.cpp for the implementation of this class
//

class CStsGuiApp : public CWinApp
{
public:
	CStsGuiApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStsGuiApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CStsGuiApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STSGUI_H__515D32A4_8A99_11D6_8735_00045A48D764__INCLUDED_)
