#if !defined(AFX_LASTPAGE4_H__FDB76CA2_AA15_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_LASTPAGE4_H__FDB76CA2_AA15_11D6_8735_00045A48D764__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LastPage4.h : header file
//
#include "XTabCtrl.h"
#include "defs.h"
#include "externs.h"
#include "TestInProgress.h"
#include "DataFreq.h"
#include "DataBlkFreq.h"
#include "DataCusum.h"
#include "DataRuns.h"
#include "DataLongRuns.h"
#include "DataRank.h"
#include "DataDFFT.h"
#include "DataNonPeriodic.h"
#include "DataOverlapping.h"
#include "DataUniversal.h"
#include "DataApen.h"
#include "DataRndExcursion.h"
#include "DataVarRndExc.h"
#include "DataSerial.h"
#include "DataLempelZiv.h"
#include "DataLinComp.h"

/////////////////////////////////////////////////////////////////////////////
// CLastPage4 dialog

class CLastPage4 : public CPropertyPage
{
	DECLARE_DYNCREATE(CLastPage4)

// Construction
public:
	CLastPage4();
	~CLastPage4();

	void	MakeTabs();
	void	FillFreqData();
	void	FillBlkFreqData();
	void	FillCusumData();
	void	FillRunsData();
	void	FillLongRunsData();
	void	FillRankData();
	void	FillDFFTData();
	void	FillNonperData();
	void	FillOverlapData();
	void	FillUnivData();
	void	FillApenData();
	void	FillRndExcData();
	void	FillVarRndExcData();
	void	FillSerialData();
	void	FillLempelZivData();
	void	FillLinCompData();

	CTestInProgress		TIP;
	CDataFreq			*m_pFreqTab;
	CDataBlkFreq		*m_pBlockFreqTab;
	CDataCusum			*m_pCusumTab;
	CDataRuns			*m_pRunsTab;
	CDataLongRuns		*m_pLongRunsTab;
	CDataRank			*m_pRankTab;
	CDataDFFT			*m_pDFFTTab;
	CDataNonPeriodic	*m_pNonperiodicTab;
	CDataOverlapping	*m_pOverlappingTab;
	CDataUniversal		*m_pUniversalTab;
	CDataApen			*m_pApenTab;
	CDataRndExcursion	*m_pRndExcursionTab;
	CDataVarRndExc		*m_pVarRndExcursionTab;
	CDataSerial			*m_pSerialTab;
	CDataLempelZiv		*m_pLempelZivTab;
	CDataLinComp		*m_pLinCompTab;

// Dialog Data
	//{{AFX_DATA(CLastPage4)
	enum { IDD = IDD_LastPage4 };
	CXTabCtrl	m_GraphingTab;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CLastPage4)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CLastPage4)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LASTPAGE4_H__FDB76CA2_AA15_11D6_8735_00045A48D764__INCLUDED_)
