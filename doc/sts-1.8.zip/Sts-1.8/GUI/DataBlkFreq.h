#if !defined(AFX_DATABLKFREQ_H__01980A95_7E86_4570_A044_83E1095F9F7D__INCLUDED_)
#define AFX_DATABLKFREQ_H__01980A95_7E86_4570_A044_83E1095F9F7D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataBlkFreq.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataBlkFreq dialog

class CDataBlkFreq : public CDialog
{
// Construction
public:
	CDataBlkFreq(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataBlkFreq)
	enum { IDD = IDD_DataBlkFreq };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataBlkFreq)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataBlkFreq)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATABLKFREQ_H__01980A95_7E86_4570_A044_83E1095F9F7D__INCLUDED_)
