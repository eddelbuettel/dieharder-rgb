#if !defined(AFX_DATARANK_H__753FF3D8_0065_4F7A_B891_B1FD2F53FF43__INCLUDED_)
#define AFX_DATARANK_H__753FF3D8_0065_4F7A_B891_B1FD2F53FF43__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataRank.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataRank dialog

class CDataRank : public CDialog
{
// Construction
public:
	CDataRank(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataRank)
	enum { IDD = IDD_DataRank };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataRank)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataRank)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATARANK_H__753FF3D8_0065_4F7A_B891_B1FD2F53FF43__INCLUDED_)
