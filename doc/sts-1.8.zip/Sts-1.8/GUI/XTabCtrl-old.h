#if !defined(AFX_XTABCTRL_H__515D32B1_8A99_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_XTABCTRL_H__515D32B1_8A99_11D6_8735_00045A48D764__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// XTabCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CXTabCtrl window

class CXTabCtrl : public CTabCtrl
{
// Construction
public:
	CXTabCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXTabCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	void setSelectedColor(COLORREF cr);
	bool selectTab(int iIndex);
	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	void addTab(CWnd *pWnd, LPTSTR lpszCaption, int iImage);
	virtual ~CXTabCtrl();

	// Generated message map functions
protected:
	POINT m_ptTabs;
	int m_iSelectedTab;
	int m_iIndexMouseOver;
	bool m_bMouseOver;
	COLORREF m_crSelected;
	COLORREF m_crNormal;
	bool m_bColorSelected;
	bool m_bColorNormal;
	//{{AFX_MSG(CXTabCtrl)
	afx_msg void OnSelchange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

static int count=0;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XTABCTRL_H__515D32B1_8A99_11D6_8735_00045A48D764__INCLUDED_)
