// XTabCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "StsGui.h"
#include "XTabCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CXTabCtrl

CXTabCtrl::CXTabCtrl()
{
	m_ptTabs.x = 4;
	m_ptTabs.y = 28;
	m_iSelectedTab = 0;
	m_bColorSelected  = false;
	m_bColorNormal = false;
	m_bMouseOver = false;
	m_crNormal = 0;
	m_crSelected = 0;
	m_iIndexMouseOver = -1;
}

CXTabCtrl::~CXTabCtrl()
{
}


BEGIN_MESSAGE_MAP(CXTabCtrl, CTabCtrl)
	//{{AFX_MSG_MAP(CXTabCtrl)
	ON_NOTIFY_REFLECT(TCN_SELCHANGE, OnSelchange)
	ON_NOTIFY_REFLECT(TCN_SELCHANGING, OnSelchanging)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXTabCtrl message handlers

void CXTabCtrl::addTab(CWnd *pWnd, LPTSTR lpszCaption, int iImage)
{
	ASSERT_VALID(pWnd);

	TCITEM item;
	item.mask = TCIF_TEXT|TCIF_PARAM|TCIF_IMAGE;
	item.lParam = (LPARAM) pWnd;
	item.pszText = lpszCaption;
	item.iImage = iImage;

	int iIndex = count++;
	InsertItem(iIndex, &item);
	pWnd->SetWindowPos(NULL, m_ptTabs.x, m_ptTabs.y , 0, 0,
						SWP_FRAMECHANGED | SWP_NOSIZE | SWP_NOZORDER);
	pWnd->ShowWindow(iIndex ? SW_HIDE : SW_SHOW);
}


void CXTabCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
CRect rect = lpDrawItemStruct->rcItem;
	rect.top += ::GetSystemMetrics(SM_CYEDGE);

	int nTabIndex = lpDrawItemStruct->itemID;
	
	if (nTabIndex < 0) return;

	BOOL bSelected = (nTabIndex == GetCurSel());

	COLORREF crSelected = m_bColorSelected ? m_crSelected : GetSysColor(COLOR_BTNTEXT);
	COLORREF crNormal  = m_bColorNormal   ? m_crNormal   : GetSysColor(COLOR_BTNTEXT);
	//COLORREF crDisabled = m_bColorDisabled ? m_crDisabled : GetSysColor(COLOR_GRAYTEXT);

	char label[64];
	TC_ITEM item;
	item.mask = TCIF_TEXT|TCIF_IMAGE;
	item.pszText = label;     
	item.cchTextMax = 63;    	
	if (!GetItem(nTabIndex, &item))
		return;

	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	if (!pDC)
		return;

	int nSavedDC = pDC->SaveDC();
	CRect rectItem;
	POINT pt;

	GetItemRect(nTabIndex, &rectItem);
	GetCursorPos(&pt);
	ScreenToClient(&pt);

	if (rectItem.PtInRect(pt))
		m_iIndexMouseOver = nTabIndex;

	pDC->SetBkMode(TRANSPARENT);
	pDC->FillSolidRect(rect, ::GetSysColor(COLOR_BTNFACE));

	//**  Draw the image
	CImageList* pImageList = GetImageList();
	if (pImageList && item.iImage >= 0) 
	{
		rect.left += pDC->GetTextExtent(_T(" ")).cx;

		IMAGEINFO info;
		pImageList->GetImageInfo(item.iImage, &info);
		CRect ImageRect(info.rcImage);
		int nYpos = rect.top;

		pImageList->Draw(pDC, item.iImage, CPoint(rect.left, nYpos), ILD_TRANSPARENT);
		rect.left += ImageRect.Width();
	}

	/*
	if (!IsTabEnabled(nTabIndex))
	{
		pDC->SetTextColor(crDisabled);
		rect.top -= ::GetSystemMetrics(SM_CYEDGE);
		pDC->DrawText(label, rect, DT_SINGLELINE|DT_VCENTER|DT_CENTER);
	}
	else
	{*/
		//** selected item -----
		if (bSelected)
			pDC->SetTextColor(crSelected);
		/*
		else //** other item ---
		{
			if (m_bColorMouseOver && nTabIndex == m_iIndexMouseOver) 
			{
				pDC->SetTextColor(m_crMouseOver);	
			}
			else
			{
				pDC->SetTextColor(crNormal);
			}
		}

		rect.top -= ::GetSystemMetrics(SM_CYEDGE);
		pDC->DrawText(label, rect, DT_SINGLELINE|DT_VCENTER|DT_CENTER);

	}*/

	pDC->RestoreDC(nSavedDC);
}

void CXTabCtrl::OnSelchange(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int iNewTab = GetCurSel();

	TCITEM item;
	CWnd* pWnd;

	item.mask = TCIF_PARAM;
		
	//** hide the current tab ---------
	GetItem(m_iSelectedTab, &item);
	pWnd = reinterpret_cast<CWnd*> (item.lParam);
	ASSERT_VALID(pWnd);
	pWnd->ShowWindow(SW_HIDE);

	//** show the selected tab --------
	GetItem(iNewTab, &item);
	pWnd = reinterpret_cast<CWnd*> (item.lParam);
	ASSERT_VALID(pWnd);
	pWnd->ShowWindow(SW_SHOW);

	*pResult = 0;
}

void CXTabCtrl::OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	m_iSelectedTab = GetCurSel();
	*pResult = 0;
}

bool CXTabCtrl::selectTab(int iIndex)
{
	ASSERT(iIndex < count);

	if (GetCurSel() == iIndex)
		return TRUE;

	TCITEM item;
	CWnd* pWnd;
	item.mask = TCIF_PARAM;

	GetItem(GetCurSel(), &item);
	pWnd = reinterpret_cast<CWnd*> (item.lParam);
	ASSERT_VALID(pWnd);
	pWnd->ShowWindow(SW_HIDE);

	SetCurSel(iIndex);
	GetItem(iIndex, &item);
	pWnd = reinterpret_cast<CWnd*> (item.lParam);
	ASSERT_VALID(pWnd);
	pWnd->ShowWindow(SW_SHOW);

	return TRUE;
}

void CXTabCtrl::setSelectedColor(COLORREF cr)
{
	m_bColorSelected = true;
	m_crSelected = cr;
}
