#if !defined(AFX_TESTSELECTION2_H__515D32B0_8A99_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_TESTSELECTION2_H__515D32B0_8A99_11D6_8735_00045A48D764__INCLUDED_

#include "ParamTab.h"
#include "NonParamTab.h"
#include "GenOptions1.h"
#include "XTabCtrl.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestSelection2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTestSelection2 dialog

class CTestSelection2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CTestSelection2)

// Construction
public:

	CNonParamTab	*m_pNonParamTab;
	CParamTab		*m_pParamTab;
	CGenOptions1	*m_pGenOptions;
	CTestSelection2();
	~CTestSelection2();
	int		ParamCheck();

// Dialog Data
	//{{AFX_DATA(CTestSelection2)
	enum { IDD = IDD_TestSelection2 };
	CEdit	m_lenSequences;
	CEdit	m_numSequences;
	CButton		m_UncheckAll;
	CStatic		m_UncheckAll_static;
	CXTabCtrl	m_CtrlTab;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CTestSelection2)
	public:
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	//{{AFX_MSG(CTestSelection2)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectAll();
	afx_msg void OnUncheckAll();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTSELECTION2_H__515D32B0_8A99_11D6_8735_00045A48D764__INCLUDED_)
