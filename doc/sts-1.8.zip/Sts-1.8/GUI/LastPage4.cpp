// LastPage4.cpp : implementation file
//

#include "stdafx.h"
#include "StsGui.h"
#include "LastPage4.h"
#include "TestInProgress.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLastPage4 property page

IMPLEMENT_DYNCREATE(CLastPage4, CPropertyPage)

CLastPage4::CLastPage4() : CPropertyPage(CLastPage4::IDD)
{
	//{{AFX_DATA_INIT(CLastPage4)
	//}}AFX_DATA_INIT
}

CLastPage4::~CLastPage4()
{
}

void CLastPage4::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLastPage4)
	DDX_Control(pDX, IDC_RESULTS_TAB, m_GraphingTab);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLastPage4, CPropertyPage)
	//{{AFX_MSG_MAP(CLastPage4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLastPage4 message handlers

BOOL CLastPage4::OnSetActive() 
{
	// Change the Next button on the last page to Done
	CPropertySheet* psheet = (CPropertySheet*) GetParent();   
    psheet->SetWizardButtons(PSWIZB_FINISH);
    psheet->SetFinishText("Done");
	psheet->UpdateWindow();
	
	if ( !TIP.m_pGenOptions->reuse )
		TIP.DoModal();

	// Update Tab data for results
	MakeTabs();

	return CPropertyPage::OnSetActive();
}

void CLastPage4::MakeTabs()
{
	if ( testVector[0] || testVector[TESTS_FREQUENCY] ) {
		m_pFreqTab = new CDataFreq;
		m_pFreqTab->Create(CDataFreq::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pFreqTab, "Freq", 0);
		m_GraphingTab.EnableTab(0, TRUE);
	}
	
	if ( testVector[0] || testVector[TESTS_BLOCK_FREQUENCY] ) {
		m_pBlockFreqTab = new CDataBlkFreq;
		m_pBlockFreqTab->Create(CDataBlkFreq::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pBlockFreqTab, "Blk Freq", 0);
	}
	
	if ( testVector[0] || testVector[TESTS_CUM_SUMS] ) {
		m_pCusumTab = new CDataCusum;
		m_pCusumTab->Create(CDataCusum::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pCusumTab, "Cusum", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_RUNS] ) {
		m_pRunsTab = new CDataRuns;
		m_pRunsTab->Create(CDataRuns::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pRunsTab, "Runs", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_LONGEST_RUNS] ) {
		m_pLongRunsTab = new CDataLongRuns;
		m_pLongRunsTab->Create(CDataLongRuns::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pLongRunsTab, "LongRuns", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_RANK] ) {
		m_pRankTab = new CDataRank;
		m_pRankTab->Create(CDataRank::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pRankTab, "Rank", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_DFFT] ) {
		m_pDFFTTab = new CDataDFFT;
		m_pDFFTTab->Create(CDataDFFT::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pDFFTTab, "DFFT", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_NONPERIODIC_TEMPL] ) {
		m_pNonperiodicTab = new CDataNonPeriodic;
		m_pNonperiodicTab->Create(CDataNonPeriodic::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pNonperiodicTab, "Nonper", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_OVERLAPPING_TEMPL] ) {
		m_pOverlappingTab = new CDataOverlapping;
		m_pOverlappingTab->Create(CDataOverlapping::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pOverlappingTab, "Overlap", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_UNIVERSAL] ) {
		m_pUniversalTab = new CDataUniversal;
		m_pUniversalTab->Create(CDataUniversal::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pUniversalTab, "Univ", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_APEN] ) {
		m_pApenTab = new CDataApen;
		m_pApenTab->Create(CDataApen::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pApenTab, "Apen", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_RANDOM_EXCURSIONS] ) {
		m_pRndExcursionTab = new CDataRndExcursion;
		m_pRndExcursionTab->Create(CDataRndExcursion::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pRndExcursionTab, "RndExc", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_RANDOM_EXCUR_VAR] ) {
		m_pVarRndExcursionTab = new CDataVarRndExc;
		m_pVarRndExcursionTab->Create(CDataVarRndExc::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pVarRndExcursionTab, "RndExcVar", 0);
	}
		
	if ( testVector[0] || testVector[TESTS_SERIAL] ) {
		m_pSerialTab = new CDataSerial;
		m_pSerialTab->Create(CDataSerial::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pSerialTab, "Serial", 0 );
	}
		
	if ( testVector[0] || testVector[TESTS_LINEAR_COMPLEXITY] ) {
		m_pLinCompTab = new CDataLinComp;
		m_pLinCompTab->Create(CDataLinComp::IDD, &m_GraphingTab);
		m_GraphingTab.AddTab(m_pLinCompTab, "LinComp", 0);
	}
}