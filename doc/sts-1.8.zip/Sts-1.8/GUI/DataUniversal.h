#if !defined(AFX_DATAUNIVERSAL_H__386724EF_0AC6_4A40_93F6_A2C3307707C0__INCLUDED_)
#define AFX_DATAUNIVERSAL_H__386724EF_0AC6_4A40_93F6_A2C3307707C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataUniversal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataUniversal dialog

class CDataUniversal : public CDialog
{
// Construction
public:
	CDataUniversal(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataUniversal)
	enum { IDD = IDD_DataUniversal };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataUniversal)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataUniversal)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATAUNIVERSAL_H__386724EF_0AC6_4A40_93F6_A2C3307707C0__INCLUDED_)
