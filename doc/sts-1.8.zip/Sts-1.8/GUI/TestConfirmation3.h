#if !defined(AFX_TESTCONFIRMATION3_H__96F00C03_8E6A_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_TESTCONFIRMATION3_H__96F00C03_8E6A_11D6_8735_00045A48D764__INCLUDED_

#include "GenOptions1.h"
#include "TestSelection2.h"
#define MAX_NUM_TESTS     16

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestConfirmation3.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTestConfirmation3 dialog

class CTestConfirmation3 : public CPropertyPage
{
	DECLARE_DYNCREATE(CTestConfirmation3)

// Construction
public:
	CTestConfirmation3();
	~CTestConfirmation3();
	void insertTestSelectionInfo();
	void initListBox();
	void updateListBox();

	CTestSelection2	*m_pTestSelection;
	CGenOptions1	*m_pGenOptions;
	bool			m_isFirstDisplayed;

// Dialog Data
	//{{AFX_DATA(CTestConfirmation3)
	enum { IDD = IDD_TestConfirmation3 };
	CListBox	m_InfoListBox;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CTestConfirmation3)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CBrush m_brush;
	// Generated message map functions
	//{{AFX_MSG(CTestConfirmation3)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	char* initString(char* temp, int len);

};
static wen = 0;
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTCONFIRMATION3_H__96F00C03_8E6A_11D6_8735_00045A48D764__INCLUDED_)
