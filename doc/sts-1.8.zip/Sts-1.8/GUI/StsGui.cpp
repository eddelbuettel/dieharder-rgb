// StsGui.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "StsGui.h"
#include "GenOptions1.h"
#include "TestSelection2.h"
#include "TestConfirmation3.h"
#include "LastPage4.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStsGuiApp

BEGIN_MESSAGE_MAP(CStsGuiApp, CWinApp)
	//{{AFX_MSG_MAP(CStsGuiApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStsGuiApp construction

CStsGuiApp::CStsGuiApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CStsGuiApp object

CStsGuiApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CStsGuiApp initialization

BOOL CStsGuiApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CPropertySheet	   dlg;
	CGenOptions1	   page1;
	CTestSelection2    page2;
	CTestConfirmation3 page3;
	CLastPage4         page4;

	// Setting pointers in page2 to point to page1
	page2.m_pGenOptions = &page1;

	// Setting pointers in page3 to point to page1 and page2
	page3.m_pGenOptions = &page1;
	page3.m_pTestSelection = &page2;

	// Setting pointers in page4 to point to page1 and page2
	page4.TIP.m_pGenOptions = &page1;
	page4.TIP.m_pTestSelection = &page2;

	// De-activating the Help option
	dlg.m_psh.dwFlags &= ~(PSH_HASHELP); 
    page1.m_psp.dwFlags &= ~PSP_HASHELP;
    page2.m_psp.dwFlags &= ~PSP_HASHELP;
	page3.m_psp.dwFlags &= ~PSP_HASHELP;
	page4.m_psp.dwFlags &= ~PSP_HASHELP;

	dlg.AddPage(&page1);
	dlg.AddPage(&page2);
	dlg.AddPage(&page3);
	dlg.AddPage(&page4);
	dlg.SetWizardMode();
	
	dlg.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
