#if !defined(AFX_DATAAPEN_H__669A9FBE_1A76_414E_96CB_21BAB954A8A3__INCLUDED_)
#define AFX_DATAAPEN_H__669A9FBE_1A76_414E_96CB_21BAB954A8A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataApen.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataApen dialog

class CDataApen : public CDialog
{
// Construction
public:
	CDataApen(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataApen)
	enum { IDD = IDD_DataApen };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataApen)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataApen)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATAAPEN_H__669A9FBE_1A76_414E_96CB_21BAB954A8A3__INCLUDED_)
