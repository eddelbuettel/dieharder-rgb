// GenOptions1.cpp : implementation file

#include <afxdlgs.h>
#include "stdafx.h"
#include "StsGui.h"
#include "GenOptions1.h"
#include "defs.h"
#include "decls.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGenOptions1 property page

IMPLEMENT_DYNCREATE(CGenOptions1, CPropertyPage)

CGenOptions1::CGenOptions1() : CPropertyPage(CGenOptions1::IDD)
{
	//{{AFX_DATA_INIT(CGenOptions1)
	m_inputFile = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDI_NIST);
	m_isInputFileSelected = FALSE;
}

CGenOptions1::~CGenOptions1()
{
}

void CGenOptions1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGenOptions1)
	DDX_Control(pDX, IDC_SAVE_DATA, m_SaveData);
	DDX_Control(pDX, IDC_RADIO_SHA1, m_Radio_Generators);
	DDX_Control(pDX, IDC_RADIO_REGENERATE, m_radioRegenerate);
	DDX_Control(pDX, INPUT_MODE_STATIC, m_inputMode_static);
	DDX_Control(pDX, IDC_InputMode, m_inputMode);
	DDX_Control(pDX, ID_Browse, m_browse);
	DDX_Text(pDX, IDC_inputFile, m_inputFile);
	DDV_MaxChars(pDX, m_inputFile, 200);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGenOptions1, CPropertyPage)
	//{{AFX_MSG_MAP(CGenOptions1)
	ON_BN_CLICKED(ID_Browse, OnBUTTONBrowse)
	ON_BN_CLICKED(IDC_RADIO_MODULAR_EXP, OnRadioModularExp)
	ON_BN_CLICKED(IDC_RADIO_LINEAR_CONGR, OnRadioLinearCongr)
	ON_BN_CLICKED(IDC_RADIO_BBS, OnRadioBbs)
	ON_BN_CLICKED(IDC_RADIO_MICALI_SCHNORR, OnRadioMicaliSchnorr)
	ON_BN_CLICKED(IDC_RADIO_QUADRATIC_I, OnRadioQuadraticI)
	ON_BN_CLICKED(IDC_RADIO_QUADRATIC_II, OnRadioQuadraticIi)
	ON_BN_CLICKED(IDC_RADIO_CUBIC_CONGR, OnRadioCubicCongr)
	ON_BN_CLICKED(IDC_RADIO_XOR, OnRadioXor)
	ON_BN_CLICKED(IDC_RADIO_ANSI, OnRadioAnsi)
	ON_BN_CLICKED(IDC_RADIO_GDES, OnRadioGdes)
	ON_BN_CLICKED(IDC_RADIO_INPUT_FILE, OnRadioInputFile)
	ON_BN_CLICKED(IDC_RADIO_REGENERATE, OnRadioRegenerate)
	ON_BN_CLICKED(IDC_RADIO_REUSE, OnRadioReuse)
	ON_BN_CLICKED(IDC_RADIO_SHA1, OnRadioSha1)
	ON_BN_CLICKED(IDC_RADIO_SHA224, OnRadioSha224)
	ON_BN_CLICKED(IDC_RADIO_SHA256, OnRadioSha256)
	ON_BN_CLICKED(IDC_RADIO_SHA384, OnRadioSha384)
	ON_BN_CLICKED(IDC_RADIO_SHA512, OnRadioSha512)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGenOptions1 message handlers

BOOL CGenOptions1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_Radio_Generators.SetCheck(TRUE);
	reuse = -1;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGenOptions1::OnBUTTONBrowse() 
{
	// TODO: Add your control notification handler code here
	//CFileDialog m_ldFile(TRUE, NULL, NULL, OFN_FILEMUSTEXIST | 
	//	OFN_PATHMUSTEXIST | OFN_HIDEREADONLY, "All Files (*.*)|*.*||", NULL);
	CFileDialog m_ldFile(TRUE, NULL, NULL, OFN_FILEMUSTEXIST | 
		OFN_PATHMUSTEXIST | OFN_HIDEREADONLY, NULL, NULL);

	CString m_sWindowText = "STS : ";
	char	buffer[200];
	char	prog_dir[200];

	// Initial directory ... "\data"
	CString m_sPath = (LPCTSTR)_getcwd(buffer, 200);
	strcpy(prog_dir, buffer);
	m_sPath += "\\data";
	m_ldFile.m_ofn.lpstrInitialDir = (LPCSTR)(m_sPath);
//	m_ldFile.m_ofn.lpstrFilter = "All files (*.*)","*.*";
	
	if ( m_ldFile.DoModal() == IDOK ) {
		// m_inputFile = (LPCTSTR)m_ldFile.GetFileName();
		m_inputFile = m_ldFile.GetPathName();
		UpdateData(FALSE);
	}
	_chdir(prog_dir);
}

void CGenOptions1::OnRadioSha1() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);	
}

void CGenOptions1::OnRadioSha224() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);	
}

void CGenOptions1::OnRadioSha256() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);	
}

void CGenOptions1::OnRadioSha384() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);	
}

void CGenOptions1::OnRadioSha512() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);	
}

void CGenOptions1::OnRadioLinearCongr() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioBbs() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioMicaliSchnorr() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioQuadraticI() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioQuadraticIi() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioCubicCongr() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioXor() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioAnsi() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioGdes() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioModularExp() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(FALSE);
	m_inputMode.EnableWindow(FALSE);
	m_inputMode_static.EnableWindow(FALSE);
}

void CGenOptions1::OnRadioInputFile() 
{
	// TODO: Add your control notification handler code here
	m_browse.EnableWindow(TRUE);
	m_inputMode.EnableWindow(TRUE);
	m_inputMode_static.EnableWindow(TRUE);
}

void CGenOptions1::OnRadioRegenerate() 
{
	// TODO: Add your control notification handler code here
	reuse = 0;
}

void CGenOptions1::OnRadioReuse() 
{
	// TODO: Add your control notification handler code here
	reuse = 1;	
}

int CGenOptions1::ReuseAvailable() 
{
	// TODO: Add your control notification handler code here
	char	fn[256], str[512];
	FILE	*inf_fp;

	UpdateData(TRUE);

	sprintf(fn, "%s.inf", generatorDir[getGeneratorNum()]);
	if ( (inf_fp = fopen(fn, "r")) == NULL ) {
		sprintf(str, "%s - doesn't exist to reuse data.\nPlease select a different generator or regenerate data.", fn);
		MessageBox(str, "File Error!!!", MB_OK);
		return 1;
	}
	else {
		fscanf(inf_fp, "Generator=%d\n", &(tp.generator));
		fscanf(inf_fp, "DataMode=%d\n", &(tp.datamode));
		fscanf(inf_fp, "LenSeq=%d\n", &(tp.n));
		fscanf(inf_fp, "NumSeq=%d\n", &(tp.numOfBitStreams));
		fscanf(inf_fp, "BlkFreqBlkLen=%d\n", &(tp.blockFrequencyBlockLength));
		fscanf(inf_fp, "AperiodicBlkLen=%d\n", &(tp.nonOverlappingTemplateBlockLength));
		fscanf(inf_fp, "OverlappingBlkLen=%d\n", &(tp.overlappingTemplateBlockLength));
		fscanf(inf_fp, "UnivBlkLen=%d\n", &(tp.universalBlockLength));
		fscanf(inf_fp, "UnivSteps=%d\n", &(tp.universalNumberInitializationSteps));
		fscanf(inf_fp, "ApenBlkLen=%d\n", &(tp.approximateEntropyBlockLength));
		fscanf(inf_fp, "SerialBlkLen=%d\n", &(tp.serialBlockLength));
		fscanf(inf_fp, "LinCompSeqLen=%d\n", &(tp.linearComplexitySequenceLength));

		fscanf(inf_fp, "Frequence=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_FREQUENCY] = 1;
		else
			testVector[TESTS_FREQUENCY] = 0;
		
		fscanf(inf_fp, "BlockFrequence=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_BLOCK_FREQUENCY] = 1;
		else
			testVector[TESTS_BLOCK_FREQUENCY] = 0;
		
		fscanf(inf_fp, "CuSum=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_CUM_SUMS] = 1;
		else
			testVector[TESTS_CUM_SUMS] = 0;
		
		fscanf(inf_fp, "Runs=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_RUNS] = 1;
		else
			testVector[TESTS_RUNS] = 0;
		
		fscanf(inf_fp, "LongRuns=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_LONGEST_RUNS] = 1;
		else
			testVector[TESTS_LONGEST_RUNS] = 0;
		
		fscanf(inf_fp, "Rank=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_RANK] = 1;
		else
			testVector[TESTS_RANK] = 0;
		
		fscanf(inf_fp, "DFFT=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_DFFT] = 1;
		else
			testVector[TESTS_DFFT] = 0;
		
		fscanf(inf_fp, "NonPeriodic=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_NONPERIODIC_TEMPL] = 1;
		else
			testVector[TESTS_NONPERIODIC_TEMPL] = 0;
		
		fscanf(inf_fp, "Overlapping=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_OVERLAPPING_TEMPL] = 1;
		else
			testVector[TESTS_OVERLAPPING_TEMPL] = 0;
		
		fscanf(inf_fp, "Universal=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_UNIVERSAL] = 1;
		else
			testVector[TESTS_UNIVERSAL] = 0;
		
		fscanf(inf_fp, "Apen=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_APEN] = 1;
		else
			testVector[TESTS_APEN] = 0;
		
		fscanf(inf_fp, "RandomExcursions=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_RANDOM_EXCURSIONS] = 1;
		else
			testVector[TESTS_RANDOM_EXCURSIONS] = 0;
		
		fscanf(inf_fp, "RandomExcursionsVar=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_RANDOM_EXCUR_VAR] = 1;
		else
			testVector[TESTS_RANDOM_EXCUR_VAR] = 0;
		
		fscanf(inf_fp, "Serial=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_SERIAL] = 1;
		else
			testVector[TESTS_SERIAL] = 0;
				
		fscanf(inf_fp, "LinearComplexity=%s\n", str);
		if ( !strncmp(str, "TRUE", 4) )
			testVector[TESTS_LINEAR_COMPLEXITY] = 1;
		else
			testVector[TESTS_LINEAR_COMPLEXITY] = 0;

		fclose(inf_fp);
		return 0;
	}
}

LRESULT CGenOptions1::OnWizardNext() 
{
	// TODO: Add your specialized code here and/or call the base class
	UpdateData(TRUE);
	bool	error = FALSE;

	// Checks that if input file is selected, a file and input mode are specified
	int Radio12 = IsDlgButtonChecked(IDC_RADIO_INPUT_FILE);
	if ( Radio12 ) {
		if ( m_inputFile.GetLength() == 0 ) {
			error = TRUE;
			MessageBox("Please specify a valid input file!","Input File Error", MB_OK|MB_ICONSTOP);
		}
	
		if ( (m_inputModeNum = m_inputMode.GetCurSel()) == CB_ERR ) {
			error = TRUE;
			MessageBox("Please specify a valid input mode!","Input File Error", MB_OK|MB_ICONSTOP);
		}
	}

	if ( !this->GetCheckedRadioButton(IDC_RADIO_REGENERATE, IDC_RADIO_REUSE) ) {
		MessageBox("Please REGENERATE or REUSE data!", "Data Select Error", MB_OK|MB_ICONSTOP);
		return E_UNEXPECTED;
	}

	if ( reuse && ReuseAvailable() )
		return E_UNEXPECTED;

	if ( error )
		return E_UNEXPECTED;

	if ( Radio12 )
		m_isInputFileSelected = TRUE;
	else
		m_isInputFileSelected = FALSE;

	return CPropertyPage::OnWizardNext();
}

CString CGenOptions1::getGenerator()
{
	UpdateData(TRUE);
	int	checkedButton = this->GetCheckedRadioButton(IDC_RADIO_SHA1, IDC_RADIO_INPUT_FILE);

	switch (checkedButton) {
		case IDC_RADIO_SHA1:
			return CString("DRBG using SHA-1");
			
		case IDC_RADIO_SHA224:
			return CString("DRBG using SHA-224");
			
		case IDC_RADIO_SHA256:
			return CString("DRBG using SHA-256");
			
		case IDC_RADIO_SHA384:
			return CString("DRBG using SHA-384");
			
		case IDC_RADIO_SHA512:
			return CString("DRBG using SHA-512");
					 	 
		case IDC_RADIO_LINEAR_CONGR:
			return CString("Linear Congruential");
		 	 
		case IDC_RADIO_BBS:
			return CString("Blum-Blum-Shub");
		 	 
		case IDC_RADIO_MICALI_SCHNORR:
			return CString("Micali-Schnorr");
		 	 
		case IDC_RADIO_QUADRATIC_I:
			return CString("Quadratic Congruential I");
			 
		case IDC_RADIO_QUADRATIC_II:
			return CString("Quadratic Congruential II");
			
		case IDC_RADIO_CUBIC_CONGR:
			return CString("Cubic Congruential");
			
		case IDC_RADIO_XOR:
			return CString("XOR");
			
		case IDC_RADIO_ANSI:
			return CString("ANSI X9.17(3-DES)");
			
		case IDC_RADIO_GDES:
			return CString("G using DES");
			 
		case IDC_RADIO_MODULAR_EXP:
			return CString("Modular Exponentiation");
			
		case IDC_RADIO_INPUT_FILE:
			return CString("Input File:      ");
			
		default:
			return CString("Non selected");   // should not be possible
	}
}

int CGenOptions1::getGeneratorNum()
{
	UpdateData(TRUE);
	int checkedButton = this->GetCheckedRadioButton(IDC_RADIO_SHA1, IDC_RADIO_INPUT_FILE);

	switch (checkedButton) {
		case IDC_RADIO_SHA1:
			return 1;
			
		case IDC_RADIO_SHA224:
			return 2;
			
		case IDC_RADIO_SHA256:
			return 3;
			
		case IDC_RADIO_SHA384:
			return 4;
			
		case IDC_RADIO_SHA512:
			return 5;
					 	 
		case IDC_RADIO_LINEAR_CONGR:
			return 6;
		 	 
		case IDC_RADIO_BBS:
			return 7;
		 	 
		case IDC_RADIO_MICALI_SCHNORR:
			return 8;
		 	 
		case IDC_RADIO_QUADRATIC_I:
			return 9;
			 
		case IDC_RADIO_QUADRATIC_II:
			return 10;
			
		case IDC_RADIO_CUBIC_CONGR:
			return 11;
			
		case IDC_RADIO_XOR:
			return 12;
			
		case IDC_RADIO_ANSI:
			return 13;
			
		case IDC_RADIO_GDES:
			return 14;
			 
		case IDC_RADIO_MODULAR_EXP:
			return 15;
			
		case IDC_RADIO_INPUT_FILE:
			return 0;
			
		default:
			return -1;   // should not be possible
	}
}
