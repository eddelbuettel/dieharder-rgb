// NonParamTab.cpp : implementation file
//

#include "stdafx.h"
#include "StsGui.h"
#include "NonParamTab.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNonParamTab property page

IMPLEMENT_DYNCREATE(CNonParamTab, CPropertyPage)

CNonParamTab::CNonParamTab() : CPropertyPage(CNonParamTab::IDD)
{
	//{{AFX_DATA_INIT(CNonParamTab)
	//}}AFX_DATA_INIT
}

CNonParamTab::~CNonParamTab()
{
}

void CNonParamTab::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNonParamTab)
	DDX_Control(pDX, IDC_CHECK_Runs, m_Runs);
	DDX_Control(pDX, IDC_CHECK_Rank, m_Rank);
	DDX_Control(pDX, IDC_CHECK_RandomExcrVar, m_RandomExcrVar);
	DDX_Control(pDX, IDC_CHECK_RandomExcr, m_RandomExcr);
	DDX_Control(pDX, IDC_CHECK_LongestRuns, m_LongestRuns);
	DDX_Control(pDX, IDC_CHECK_Frequency, m_Frequency);
	DDX_Control(pDX, IDC_CHECK_DFFT, m_Dfft);
	DDX_Control(pDX, IDC_CHECK_Cumsums, m_Cumsums);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNonParamTab, CPropertyPage)
	//{{AFX_MSG_MAP(CNonParamTab)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNonParamTab message handlers


void CNonParamTab::selectAll(bool state)
{
	m_Cumsums.SetCheck(state);
	m_Dfft.SetCheck(state);
	m_Frequency.SetCheck(state);
	m_LongestRuns.SetCheck(state);
	m_RandomExcr.SetCheck(state);
	m_RandomExcrVar.SetCheck(state);
	m_Rank.SetCheck(state);
	m_Runs.SetCheck(state);
}


