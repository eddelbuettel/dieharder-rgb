// TestSelection2.cpp : implementation file
//

#include "stdafx.h"
#include "StsGui.h"
#include "TestSelection2.h"
#include "defs.h"
#include "externs.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSelection2 property page

IMPLEMENT_DYNCREATE(CTestSelection2, CPropertyPage)

CTestSelection2::CTestSelection2() : CPropertyPage(CTestSelection2::IDD)
{
	//{{AFX_DATA_INIT(CTestSelection2)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDI_NIST);
}

CTestSelection2::~CTestSelection2()
{
}

void CTestSelection2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestSelection2)
	DDX_Control(pDX, IDC_lenSequences, m_lenSequences);
	DDX_Control(pDX, IDC_numSequences, m_numSequences);
	DDX_Control(pDX, IDC_UncheckAll, m_UncheckAll);
	DDX_Control(pDX, IDC_UncheckAll_static, m_UncheckAll_static);
	DDX_Control(pDX, IDC_MAINTAB, m_CtrlTab);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestSelection2, CPropertyPage)
	//{{AFX_MSG_MAP(CTestSelection2)
	ON_BN_CLICKED(IDC_SelectAll, OnSelectAll)
	ON_BN_CLICKED(IDC_UncheckAll, OnUncheckAll)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSelection2 message handlers

BOOL CTestSelection2::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	char	str[32];
	
	// TODO: Add extra initialization here
	// Creating Param Tab
	m_pParamTab = new CParamTab;
	m_pParamTab->Create(CParamTab::IDD, &m_CtrlTab);
	m_CtrlTab.AddTab(m_pParamTab, "Parameterized Test Selection", 0);

	// Creating NonParam Tab
	m_pNonParamTab = new CNonParamTab;
	m_pNonParamTab->Create(CNonParamTab::IDD, &m_CtrlTab);
	m_CtrlTab.AddTab(m_pNonParamTab, "Non-parameterized Test Selection", 0);

	if ( m_pGenOptions->reuse ) {
		m_pParamTab->reuse = 1;
		if ( testVector[TESTS_ALL] || testVector[TESTS_FREQUENCY] )
			m_pNonParamTab->m_Frequency.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_BLOCK_FREQUENCY] ) {
			m_pParamTab->m_BFQCY.SetCheck(1);
			sprintf(str, "%d", tp.blockFrequencyBlockLength);
			m_pParamTab->m_BFQCY_blockLen.SetWindowText(str);
		}

		if ( testVector[TESTS_ALL] || testVector[TESTS_CUM_SUMS] )
			m_pNonParamTab->m_Cumsums.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_RUNS] )
			m_pNonParamTab->m_Runs.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_LONGEST_RUNS] )
			m_pNonParamTab->m_LongestRuns.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_RANK] )
			m_pNonParamTab->m_Rank.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_DFFT] )
			m_pNonParamTab->m_Dfft.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_NONPERIODIC_TEMPL] ) {
			m_pParamTab->m_NONP_TEMPL.SetCheck(1);
			sprintf(str, "%d", tp.nonOverlappingTemplateBlockLength);
			m_pParamTab->m_NONP_templLen.SetWindowText(str);
		}

		if ( testVector[TESTS_ALL] || testVector[TESTS_OVERLAPPING_TEMPL] ) {
			m_pParamTab->m_OverlappingTempl.SetCheck(1);
			sprintf(str, "%d", tp.overlappingTemplateBlockLength);
			m_pParamTab->m_OVERL_templLen.SetWindowText(str);
		}

		if ( testVector[TESTS_ALL] || testVector[TESTS_UNIVERSAL] ) {
			m_pParamTab->m_Universal.SetCheck(1);
			sprintf(str, "%d", tp.universalBlockLength);
			m_pParamTab->m_Universal_blockLen.SetWindowText(str);
			sprintf(str, "%d", tp.universalNumberInitializationSteps);
			m_pParamTab->m_Universal_numBlocks.SetWindowText(str);
		}

		if ( testVector[TESTS_ALL] || testVector[TESTS_APEN] ) {
			m_pParamTab->m_APEN.SetCheck(1);
			sprintf(str, "%d", tp.approximateEntropyBlockLength);
			m_pParamTab->m_APEN_blockLen.SetWindowText(str);
		}

		if ( testVector[TESTS_ALL] || testVector[TESTS_RANDOM_EXCURSIONS] )
			m_pNonParamTab->m_RandomExcr.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_RANDOM_EXCUR_VAR] )
			m_pNonParamTab->m_RandomExcrVar.SetCheck(1);

		if ( testVector[TESTS_ALL] || testVector[TESTS_SERIAL] ) {
			m_pParamTab->m_Serial.SetCheck(1);
			sprintf(str, "%d", tp.serialBlockLength);
			m_pParamTab->m_Serial_blockLen.SetWindowText(str);
		}

		if ( testVector[TESTS_ALL] || testVector[TESTS_LINEAR_COMPLEXITY] ) {
			m_pParamTab->m_LinearCompl.SetCheck(1);
			sprintf(str, "%d", tp.linearComplexitySequenceLength);
			m_pParamTab->m_LinearCompl_blockLen.SetWindowText(str);
		}

		m_lenSequences.EnableWindow(FALSE);
		m_numSequences.EnableWindow(FALSE);

		sprintf(str, "%d", tp.n);
		m_lenSequences.SetWindowText(str);
		sprintf(str, "%d", tp.numOfBitStreams);
		m_numSequences.SetWindowText(str);
		UpdateData(FALSE);

	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTestSelection2::OnSelectAll() 
{
	// TODO: Add your control notification handler code here
	m_pParamTab->selectAll(TRUE);
	m_pNonParamTab->selectAll(TRUE);

	// to allow user to uncheck all
	m_UncheckAll.ShowWindow(1);
	m_UncheckAll_static.ShowWindow(1);
}

LRESULT CTestSelection2::OnWizardNext() 
{
	// TODO: Add your specialized code here and/or call the base class
	char	buffer[10];
	int		ret_val;

	UpdateData(TRUE);

	// Checks that length and number of sequences are not <= 0
	m_lenSequences.GetLine(0, buffer, 10);
	if ( atoi(buffer) <= 0 ) {
		MessageBox("Length of sequences has to be greater than zero!", "Len Sequences Error", MB_OK|MB_ICONSTOP);
		return E_UNEXPECTED;
	}
	m_numSequences.GetLine(0, buffer, 10);
	if ( atoi(buffer) <= 0 ) {
		MessageBox("Number of sequences has to be greater than zero!", "Num Sequences Error", MB_OK|MB_ICONSTOP);
		return E_UNEXPECTED;
	}

	// if user did not select any tests at all
	if ( !m_pParamTab->m_APEN.GetCheck() && !m_pParamTab->m_BFQCY.GetCheck() &&
			  !m_pParamTab->m_LinearCompl.GetCheck() && !m_pParamTab->m_NONP_TEMPL.GetCheck() &&
			  !m_pParamTab->m_OverlappingTempl.GetCheck() && !m_pParamTab->m_Serial.GetCheck() &&
			  !m_pParamTab->m_Universal.GetCheck() && !m_pNonParamTab->m_Cumsums.GetCheck() &&
			  !m_pNonParamTab->m_Dfft.GetCheck() && !m_pNonParamTab->m_Frequency.GetCheck() &&
			  !m_pNonParamTab->m_LongestRuns.GetCheck() && !m_pNonParamTab->m_RandomExcr.GetCheck() &&
			  !m_pNonParamTab->m_RandomExcrVar.GetCheck() && !m_pNonParamTab->m_Rank.GetCheck() &&
			  !m_pNonParamTab->m_Runs.GetCheck() ) {
		MessageBox("Please select at least one test.","Warning", MB_OK|MB_ICONSTOP);
		return E_UNEXPECTED;
	}

	// if user selects a parameterized test and did not specify any parameters
	if ( m_pParamTab->m_APEN.GetCheck() && 
		 !m_pParamTab->m_APEN_blockLen.GetLine(0, buffer, 10) ||
		 m_pParamTab->m_BFQCY.GetCheck() &&
		 !m_pParamTab->m_BFQCY_blockLen.GetLine(0, buffer, 10)  ||
		 m_pParamTab->m_LinearCompl.GetCheck() &&
		 !m_pParamTab->m_LinearCompl_blockLen.GetLine(0, buffer, 10) ||
		 m_pParamTab->m_NONP_TEMPL.GetCheck() &&
		 !m_pParamTab->m_NONP_templLen.GetLine(0, buffer, 10) ||
		 m_pParamTab->m_OverlappingTempl.GetCheck() &&
		 !m_pParamTab->m_OVERL_templLen.GetLine(0, buffer, 10) ||
		 m_pParamTab->m_Serial.GetCheck() &&
		 !m_pParamTab->m_Serial_blockLen.GetLine(0, buffer, 10) ||
		 m_pParamTab->m_Universal.GetCheck() &&
		 (!m_pParamTab->m_Universal_blockLen.GetLine(0, buffer, 10) ||
		 !m_pParamTab->m_Universal_numBlocks.GetLine(0, buffer, 10)) ) {
		MessageBox("Missing or invalid parameters!","Warning", MB_OK|MB_ICONSTOP);
		return E_UNEXPECTED;
	}

	if ( ret_val = ParamCheck() )
		return E_UNEXPECTED;

	//m_pTestConfirmation->updateListBox();
	return CPropertyPage::OnWizardNext();
}

void CTestSelection2::OnUncheckAll() 
{
	// TODO: Add your control notification handler code here
	m_UncheckAll.ShowWindow(0);
	m_UncheckAll_static.ShowWindow(0);

	m_pParamTab->selectAll(FALSE);
	m_pNonParamTab->selectAll(FALSE);
}

int CTestSelection2::ParamCheck() 
{
	int		i, flag, m, n_bits, L, Q;
	char	str[32];

	m_lenSequences.GetLine(0, str, 10);
	tp.n = atoi(str);
	m_numSequences.GetLine(0, str, 10);
	tp.numOfBitStreams = atoi(str);

	// Default values here, shouldn't need these
	tp.blockFrequencyBlockLength = 10;
	tp.nonOverlappingTemplateBlockLength = 10;
	tp.overlappingTemplateBlockLength = 10;
	tp.universalBlockLength = 6;
	tp.universalNumberInitializationSteps = 640;
	tp.approximateEntropyBlockLength = 5;
	tp.serialBlockLength = 5;
	tp.linearComplexitySequenceLength = 5000;

	for ( i=0; i<=NUMOFTESTS; i++ )
		testVector[i] = FALSE;

	flag = 1;
	if ( m_pNonParamTab->m_Frequency.GetCheck() ) {
		testVector[TESTS_FREQUENCY] = TRUE;
		if ( tp.n < 100 ) {
			MessageBox("Frequency Test: Stream length < 100",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 1;
		}
	}
	else
		flag = 0;

	if ( m_pNonParamTab->m_Cumsums.GetCheck() ) {
		if ( tp.n < 100 ) {
			MessageBox("Cumulative Sums Test: Stream length < 100",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 2;
		}
	}
	else
		flag = 0;

	if ( m_pNonParamTab->m_Runs.GetCheck() ) {
		if ( tp.n < 100 ) {
			MessageBox("Runs Test: Stream length < 100",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 3;
		}
	}
	else
		flag = 0;

	if ( m_pNonParamTab->m_LongestRuns.GetCheck() ) {
#if LONG_RUNS_CASE_8 == 1
		if ( tp.n < 128 ) {
			MessageBox("Longest Runs Test, Case_8: Stream length < 128",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 4;
		}
#elif LONG_RUNS_CASE_128 == 1
		if ( tp.n < 6272 ) {
			MessageBox("Longest Runs Test, Case_128: Stream length < 6272",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 5;
		}
#elif LONG_RUNS_CASE_10000 == 1
		if ( tp.n < 750000 ) {
			MessageBox("Longest Runs Test, Case_10000: Stream length < 750000",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 6;
		}
#endif
	}
	else
		flag = 0;

	if ( m_pNonParamTab->m_Rank.GetCheck() ) {
		if ( tp.n < 38912 ) {
			MessageBox("Rank Test: Stream length < 38912",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 7;
		}
	}
	else
		flag = 0;

	if ( m_pNonParamTab->m_Dfft.GetCheck() ) {
		if ( tp.n < 1000 ) {
			MessageBox("DFFT Test: Stream length < 1000",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 8;
		}
	}
	else
		flag = 0;

	if ( m_pNonParamTab->m_RandomExcr.GetCheck() ) {
		if ( tp.n < 1000000 ) {
			MessageBox("Random Excursions Test: Stream length < 1000000",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 9;
		}
	}
	else
		flag = 0;

	if ( m_pNonParamTab->m_RandomExcrVar.GetCheck() ) {
		if ( tp.n < 1000000 ) {
			MessageBox("Random Excursions Variant Test: Stream length < 1000000",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 10;
		}
	}
	else
		flag = 0;

	if ( m_pParamTab->m_BFQCY.GetCheck() ) {
		if ( tp.n < 100 ) {
			MessageBox("Block Frequency Test: Stream length < 100",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 11;
		}
		m = tp.blockFrequencyBlockLength = atoi(m_pParamTab->getBFQCYBlockLen());
//		if ( (m < 20) || (m <= tp.n/100) || ((int)floor((double)tp.n/(double)m) >= 100) )
//			return 12;
	}
	else
		flag = 0;

	if ( m_pParamTab->m_APEN.GetCheck() ) {
		m = tp.approximateEntropyBlockLength = atoi(m_pParamTab->getAPENBlockLen());
		for ( n_bits=32; n_bits>0; n_bits-- )
			if ( tp.n & (1 << n_bits) )
				break;
		if ( m > n_bits-2 ) {
			MessageBox("Approximate Entropy Test: Stream length too short",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 13;
		}
	}
	else
		flag = 0;

	if ( m_pParamTab->m_LinearCompl.GetCheck() ) {
		m = tp.linearComplexitySequenceLength = atoi(m_pParamTab->getLinearCmplBlockLen());
		if ( tp.n < 1000000 ) {
			MessageBox("Linear Complexity Test: Stream length < 1000000",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 14;
		}
		if ( (m < 500) || (m > 5000) ) {
			MessageBox("Linear Complexity Test: M<500 or M>5000",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 14;
		}
		if ( (tp.n / m) < 200 ) {
			MessageBox("Linear Complexity Test: n/M < 200",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 14;
		}
	}
	else
		flag = 0;

	if ( m_pParamTab->m_NONP_TEMPL.GetCheck() ) {
		tp.nonOverlappingTemplateBlockLength = atoi(m_pParamTab->getNonPTemplLen());
		if ( (int)floor(tp.n/8) <= tp.n/100 ) {
			MessageBox("Non-overlapping Templates Test: M <= n/100",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 15;
		}
	}
	else
		flag = 0;

	if ( m_pParamTab->m_OverlappingTempl.GetCheck() ) {
		m = tp.overlappingTemplateBlockLength = atoi(m_pParamTab->getOverLappingTemplLen());
		if ( tp.n < 1000000 || ((m != 9) && (m != 10)) ) {
			MessageBox("Overlapping Templates Test: n < 1000000 or m<9 or m>10",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 16;
		}
	}
	else
		flag = 0;

	if ( m_pParamTab->m_Serial.GetCheck() ) {
		m = tp.serialBlockLength = atoi(m_pParamTab->getSerialBlockLen());
		for ( n_bits=32; n_bits>0; n_bits-- )
			if ( tp.n & (1 << n_bits) )
				break;
		if ( m > n_bits-2 ) {
			MessageBox("Serial Test: stream length too short",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 17;
		}

	}
	else
		flag = 0;

	if ( m_pParamTab->m_Universal.GetCheck() ) {
		tp.universalBlockLength = atoi(m_pParamTab->getUniversalBlockLen());
		tp.universalNumberInitializationSteps = atoi(m_pParamTab->getUniversalNumBlocks());
		if ( tp.n >= 387840 )     { L = 6;  Q = 640;    }
		if ( tp.n >= 904960 )     { L = 7;  Q = 1280;   }
		if ( tp.n >= 2068480 )    { L = 8;  Q = 2560;   }
		if ( tp.n >= 4654080 )    { L = 9;  Q = 5120;   }
		if ( tp.n >= 10342400 )   { L = 10; Q = 10240;  }
		if ( tp.n >= 22753280 )   { L = 11; Q = 20480;  }
		if ( tp.n >= 49643520 )   { L = 12; Q = 40960;  }
		if ( tp.n >= 107560960 )  { L = 13; Q = 81920;  }
		if ( tp.n >= 231669760 )  { L = 14; Q = 163840; }
		if ( tp.n >= 496435200 )  { L = 15; Q = 327680; }
		if ( tp.n >= 1059061760 ) { L = 16; Q = 655360; }

		if ( tp.n < 387840) {
			MessageBox("Universal Test: stream length < 387840",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 18;
		}
		if ( L != tp.universalBlockLength ) {
			MessageBox("Universal Test: bad L choice",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 18;
		}
		if ( Q != tp.universalNumberInitializationSteps ) {
			MessageBox("Universal Test: bad Q choice",
				"Parameter configuration error", MB_OK|MB_ICONSTOP);
			return 18;
		}
	}
	else
		flag = 0;

	if ( flag )
		testVector[0] = TRUE;

	return 0;
}