// DataLongRuns.cpp : implementation file
//

#include "stdafx.h"
#include "StsGui.h"
#include "DataLongRuns.h"
#include "defs.h"
#include "externs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataLongRuns dialog


CDataLongRuns::CDataLongRuns(CWnd* pParent /*=NULL*/)
	: CDialog(CDataLongRuns::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDataLongRuns)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDataLongRuns::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataLongRuns)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataLongRuns, CDialog)
	//{{AFX_MSG_MAP(CDataLongRuns)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataLongRuns message handlers

void CDataLongRuns::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CPen	redPen(PS_SOLID, 1, RGB(255,0,0));
	char	s[256];
	FILE	*fp;
	float	*pvals, tmp;
	int		i, j, x, y;
	
	// TODO: Add your message handler code here

	dc.MoveTo( 20, 20);
	dc.LineTo( 20,420);
	dc.MoveTo( 20,420);
	dc.LineTo(820,420);
	dc.MoveTo( 20,420);
	dc.LineTo(820, 20);
	
	dc.SelectObject(&redPen);
	// Get the actual data
	
	sprintf(s, "experiments/%s/%s/results", generatorDir[tp.generator],
		testNames[TESTS_LONGEST_RUNS]);
	if ( (fp = fopen(s, "r")) == NULL ) {
		MessageBox(s, "File Open Error", MB_ICONSTOP|MB_OK);
		return;
	}
	pvals = (float *)calloc(sizeof(float), tp.numOfBitStreams);
	for ( i=0; i<tp.numOfBitStreams; i++ )
		fscanf(fp, "%f\n", &(pvals[i]));
	fclose(fp);

	for (i=0; i<tp.numOfBitStreams-1; i++ )
		for ( j=i+1; j<tp.numOfBitStreams; j++ )
			if ( pvals[j] < pvals[i] ) {
				tmp = pvals[i];
				pvals[i] = pvals[j];
				pvals[j] = tmp;
			}

	for ( i=0; i<tp.numOfBitStreams; i++ ) {
		x = (800 * i) / tp.numOfBitStreams;
		y = (int)(400 * pvals[i]);
		dc.Ellipse(x-1+20, 420-y-1, x+1+20, 420-y+1);
		}
	
	// Do not call CDialog::OnPaint() for painting messages
}
