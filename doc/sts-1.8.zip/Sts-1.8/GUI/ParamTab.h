#if !defined(AFX_PARAMTAB_H__7FFA4F42_8AB6_11D6_8735_00045A48D764__INCLUDED_)
#define AFX_PARAMTAB_H__7FFA4F42_8AB6_11D6_8735_00045A48D764__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ParamTab.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CParamTab dialog

class CParamTab : public CPropertyPage
{
	DECLARE_DYNCREATE(CParamTab)

// Construction
public:

	int		reuse;
	CString getUniversalNumBlocks();
	CString getUniversalBlockLen();
	CString getSerialBlockLen();
	CString getOverLappingTemplLen();
	CString getNonPTemplLen();
	CString getLinearCmplBlockLen();
	CString getAPENBlockLen();
	CString getBFQCYBlockLen();
	void selectAll(bool state);
	CParamTab();
	~CParamTab();

// Dialog Data
	//{{AFX_DATA(CParamTab)
	enum { IDD = IDD_ParamTab };
	CButton	m_BFQCY;
	CButton	m_OverlappingTempl;
	CButton	m_NONP_TEMPL;
	CButton	m_Serial;
	CButton	m_APEN;
	CButton	m_LinearCompl;
	CButton	m_Universal;
	CStatic	m_BFQCY_static;
	CStatic	m_OVERL_static;
	CStatic	m_NONP_static;
	CStatic	m_Serial_static;
	CStatic	m_APEN_static;
	CStatic	m_LinearCompl_static;
	CStatic	m_Universal_static1;
	CStatic	m_Universal_static2;
	CEdit	m_BFQCY_blockLen;
	CEdit	m_OVERL_templLen;
	CEdit	m_NONP_templLen;
	CEdit	m_Serial_blockLen;
	CEdit	m_APEN_blockLen;
	CEdit	m_LinearCompl_blockLen;
	CEdit	m_Universal_numBlocks;
	CEdit	m_Universal_blockLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CParamTab)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CParamTab)
	afx_msg void OnCheckApen();
	afx_msg void OnCheckBfqcy();
	afx_msg void OnCheckLinearCompl();
	afx_msg void OnCheckNonpTempl();
	afx_msg void OnCheckOverlTempl();
	afx_msg void OnCheckSerial();
	afx_msg void OnCheckUnivl();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	char* initString(char* temp, int len);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARAMTAB_H__7FFA4F42_8AB6_11D6_8735_00045A48D764__INCLUDED_)
