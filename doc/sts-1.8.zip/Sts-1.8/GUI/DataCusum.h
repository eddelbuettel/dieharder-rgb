#if !defined(AFX_DATACUSUM_H__F2C78A8F_B2F5_47B2_AD48_5B9316C8DA04__INCLUDED_)
#define AFX_DATACUSUM_H__F2C78A8F_B2F5_47B2_AD48_5B9316C8DA04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataCusum.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataCusum dialog

class CDataCusum : public CDialog
{
// Construction
public:
	CDataCusum(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataCusum)
	enum { IDD = IDD_DataCusum };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataCusum)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataCusum)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATACUSUM_H__F2C78A8F_B2F5_47B2_AD48_5B9316C8DA04__INCLUDED_)
