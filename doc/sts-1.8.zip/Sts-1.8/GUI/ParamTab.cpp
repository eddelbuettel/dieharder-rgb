// ParamTab.cpp : implementation file
//

#include "stdafx.h"
#include "StsGui.h"
#include "ParamTab.h"
#include "TestSelection2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CParamTab property page

IMPLEMENT_DYNCREATE(CParamTab, CPropertyPage)

CParamTab::CParamTab() : CPropertyPage(CParamTab::IDD)
{
	//{{AFX_DATA_INIT(CParamTab)
	//}}AFX_DATA_INIT
	reuse = 0;
}

CParamTab::~CParamTab()
{
}

void CParamTab::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CParamTab)
	DDX_Control(pDX, IDC_UNIVL_numBlocks, m_Universal_numBlocks);
	DDX_Control(pDX, IDC_UNIVL_blockLen, m_Universal_blockLen);
	DDX_Control(pDX, IDC_OVERL_templLen, m_OVERL_templLen);
	DDX_Control(pDX, IDC_NONP_templLen, m_NONP_templLen);
	DDX_Control(pDX, IDC_LinearCompl_static, m_LinearCompl_static);
	DDX_Control(pDX, IDC_LinearCompl_blockLen, m_LinearCompl_blockLen);
	DDX_Control(pDX, IDC_CHECK_UNIVL, m_Universal);
	DDX_Control(pDX, IDC_CHECK_SERIAL, m_Serial);
	DDX_Control(pDX, IDC_CHECK_OVERL_TEMPL, m_OverlappingTempl);
	DDX_Control(pDX, IDC_CHECK_NONP_TEMPL, m_NONP_TEMPL);
	DDX_Control(pDX, IDC_CHECK_LINEAR_COMPL, m_LinearCompl);
	DDX_Control(pDX, IDC_CHECK_BFQCY, m_BFQCY);
	DDX_Control(pDX, IDC_CHECK_APEN, m_APEN);
	DDX_Control(pDX, IDC_Universal_static2, m_Universal_static2);
	DDX_Control(pDX, IDC_Universal_static1, m_Universal_static1);
	DDX_Control(pDX, IDC_Serial_static, m_Serial_static);
	DDX_Control(pDX, IDC_OVERL_static, m_OVERL_static);
	DDX_Control(pDX, IDC_NONP_static, m_NONP_static);
	DDX_Control(pDX, IDC_BFQCY_static, m_BFQCY_static);
	DDX_Control(pDX, IDC_APEN_static, m_APEN_static);
	DDX_Control(pDX, IDC_SERIAL_blockLen, m_Serial_blockLen);
	DDX_Control(pDX, IDC_BFQCY_blockLen, m_BFQCY_blockLen);
	DDX_Control(pDX, IDC_APEN_blockLen, m_APEN_blockLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CParamTab, CPropertyPage)
	//{{AFX_MSG_MAP(CParamTab)
	ON_BN_CLICKED(IDC_CHECK_APEN, OnCheckApen)
	ON_BN_CLICKED(IDC_CHECK_BFQCY, OnCheckBfqcy)
	ON_BN_CLICKED(IDC_CHECK_LINEAR_COMPL, OnCheckLinearCompl)
	ON_BN_CLICKED(IDC_CHECK_NONP_TEMPL, OnCheckNonpTempl)
	ON_BN_CLICKED(IDC_CHECK_OVERL_TEMPL, OnCheckOverlTempl)
	ON_BN_CLICKED(IDC_CHECK_SERIAL, OnCheckSerial)
	ON_BN_CLICKED(IDC_CHECK_UNIVL, OnCheckUnivl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CParamTab message handlers


BOOL CParamTab::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_BFQCY_blockLen.LimitText(10);
	m_BFQCY_blockLen.SetWindowText("128");
	m_NONP_templLen.LimitText(10);
	m_NONP_templLen.SetWindowText("9");
	m_OVERL_templLen.LimitText(10);
	m_OVERL_templLen.SetWindowText("9");
	m_APEN_blockLen.LimitText(10);
	m_APEN_blockLen.SetWindowText("10");
	m_Serial_blockLen.LimitText(10);
	m_Serial_blockLen.SetWindowText("16");
	m_LinearCompl_blockLen.LimitText(10);
	m_LinearCompl_blockLen.SetWindowText("500");
	m_Universal_numBlocks.LimitText(10);
	m_Universal_numBlocks.SetWindowText("1280");
	m_Universal_blockLen.LimitText(10);
	m_Universal_blockLen.SetWindowText("7");

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CParamTab::OnCheckApen() 
{
	// TODO: Add your control notification handler code here
	if ( !m_APEN.GetCheck() ) {
		m_APEN_blockLen.EnableWindow(FALSE);
		m_APEN_static.EnableWindow(FALSE);
	}
	else {
		m_APEN_blockLen.EnableWindow(TRUE);
		m_APEN_static.EnableWindow(TRUE);
	}
}

void CParamTab::OnCheckBfqcy() 
{
	// TODO: Add your control notification handler code here
	if ( reuse )
		return;

	if ( !m_BFQCY.GetCheck() ) {
		m_BFQCY_blockLen.EnableWindow(FALSE);
		m_BFQCY_static.EnableWindow(FALSE);
	}
	else {
		m_BFQCY_blockLen.EnableWindow(TRUE);
		m_BFQCY_static.EnableWindow(TRUE);
	}
}

void CParamTab::OnCheckLinearCompl() 
{
	// TODO: Add your control notification handler code here
	if ( reuse )
		return;

	if ( !m_LinearCompl.GetCheck() ) {
		m_LinearCompl_blockLen.EnableWindow(FALSE);
		m_LinearCompl_static.EnableWindow(FALSE);
	}
	else {
		m_LinearCompl_blockLen.EnableWindow(TRUE);
		m_LinearCompl_static.EnableWindow(TRUE);
	}
}

void CParamTab::OnCheckNonpTempl() 
{
	// TODO: Add your control notification handler code here
	if ( reuse )
		return;

	if ( !m_NONP_TEMPL.GetCheck() ) {
		m_NONP_templLen.EnableWindow(FALSE);
		m_NONP_static.EnableWindow(FALSE);
	}
	else {
		m_NONP_templLen.EnableWindow(TRUE);
		m_NONP_static.EnableWindow(TRUE);
	}
}

void CParamTab::OnCheckOverlTempl() 
{
	// TODO: Add your control notification handler code here
	if ( reuse )
		return;

	if ( !m_OverlappingTempl.GetCheck() ) {
		m_OVERL_templLen.EnableWindow(FALSE);
		m_OVERL_static.EnableWindow(FALSE);
	}
	else {
		m_OVERL_templLen.EnableWindow(TRUE);
		m_OVERL_static.EnableWindow(TRUE);
	}
}

void CParamTab::OnCheckSerial() 
{
	// TODO: Add your control notification handler code here
	if ( reuse )
		return;

	if ( !m_Serial.GetCheck() ) {
		m_Serial_blockLen.EnableWindow(FALSE);
		m_Serial_static.EnableWindow(FALSE);
	}
	else {
		m_Serial_blockLen.EnableWindow(TRUE);
		m_Serial_static.EnableWindow(TRUE);
	}
}

void CParamTab::OnCheckUnivl() 
{
	// TODO: Add your control notification handler code here
	if ( reuse )
		return;

	if ( !m_Universal.GetCheck() ) {
		m_Universal_blockLen.EnableWindow(FALSE);
		m_Universal_numBlocks.EnableWindow(FALSE);
		m_Universal_static1.EnableWindow(FALSE);
		m_Universal_static2.EnableWindow(FALSE);
	}
	else {
		m_Universal_blockLen.EnableWindow(TRUE);
		m_Universal_numBlocks.EnableWindow(TRUE);
		m_Universal_static1.EnableWindow(TRUE);
		m_Universal_static2.EnableWindow(TRUE);
	}
}

void CParamTab::selectAll(bool state)
{
	m_APEN.SetCheck(state);
	m_BFQCY.SetCheck(state);
	m_LinearCompl.SetCheck(state);
	m_NONP_TEMPL.SetCheck(state);
	m_OverlappingTempl.SetCheck(state);
	m_Serial.SetCheck(state);
	m_Universal.SetCheck(state);

	OnCheckApen();
	OnCheckBfqcy();
	OnCheckLinearCompl();
	OnCheckNonpTempl();
	OnCheckOverlTempl();
	OnCheckSerial();
	OnCheckUnivl();
}

CString CParamTab::getBFQCYBlockLen()
{
	char	temp[10];

	initString(temp,10);
	this->m_BFQCY_blockLen.GetLine(0, temp, 10);
	return CString(temp);
}

CString CParamTab::getAPENBlockLen()
{
	char	temp[10];

	initString(temp,10);
	this->m_APEN_blockLen.GetLine(0,temp, 10);
	return CString(temp);
}

CString CParamTab::getLinearCmplBlockLen()
{
	char	temp[10];

	initString(temp,10);
	this->m_LinearCompl_blockLen.GetLine(0, temp, 10);
	return CString(temp);
}

CString CParamTab::getNonPTemplLen()
{
	char	temp[10];

	initString(temp,10);
	this->m_NONP_templLen.GetLine(0, temp, 10);
	return CString(temp);
}

CString CParamTab::getOverLappingTemplLen()
{
	char	temp[10];

	initString(temp,10);
	this->m_OVERL_templLen.GetLine(0, temp, 10);
	return CString(temp);
}

CString CParamTab::getSerialBlockLen()
{
	char	temp[10];

	initString(temp,10);
	this->m_Serial_blockLen.GetLine(0, temp, 10);
	return CString(temp);
}

CString CParamTab::getUniversalBlockLen()
{
	char	temp[10];

	initString(temp,10);
	this->m_Universal_blockLen.GetLine(0, temp, 10);
	return CString(temp);
}

CString CParamTab::getUniversalNumBlocks()
{
	char	temp[10];

	initString(temp,10);
	this->m_Universal_numBlocks.GetLine(0,temp, 10);
	return CString(temp);
}

char* CParamTab::initString(char *temp, int len)
{
	for ( int i=0; i<len; i++ )
		temp[i] = '\0';
	return temp;
}
