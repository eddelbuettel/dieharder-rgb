#if !defined(AFX_DATASERIAL_H__9B242D30_735B_4344_B3E7_2A4A68723E51__INCLUDED_)
#define AFX_DATASERIAL_H__9B242D30_735B_4344_B3E7_2A4A68723E51__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataSerial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataSerial dialog

class CDataSerial : public CDialog
{
// Construction
public:
	CDataSerial(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataSerial)
	enum { IDD = IDD_DataSerial };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataSerial)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataSerial)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATASERIAL_H__9B242D30_735B_4344_B3E7_2A4A68723E51__INCLUDED_)
