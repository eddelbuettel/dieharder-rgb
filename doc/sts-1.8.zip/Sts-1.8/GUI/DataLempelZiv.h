#if !defined(AFX_DATALEMPELZIV_H__8C00CDD3_51F2_4187_898D_90C0B0EBF739__INCLUDED_)
#define AFX_DATALEMPELZIV_H__8C00CDD3_51F2_4187_898D_90C0B0EBF739__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataLempelZiv.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataLempelZiv dialog

class CDataLempelZiv : public CDialog
{
// Construction
public:
	CDataLempelZiv(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataLempelZiv)
	enum { IDD = IDD_DataLempelZiv };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataLempelZiv)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataLempelZiv)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATALEMPELZIV_H__8C00CDD3_51F2_4187_898D_90C0B0EBF739__INCLUDED_)
