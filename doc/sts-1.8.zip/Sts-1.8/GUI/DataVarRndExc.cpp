// DataVarRndExc.cpp : implementation file
//

#include "stdafx.h"
#include "StsGui.h"
#include "DataVarRndExc.h"
#include "defs.h"
#include "externs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataVarRndExc dialog


CDataVarRndExc::CDataVarRndExc(CWnd* pParent /*=NULL*/)
	: CDialog(CDataVarRndExc::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDataVarRndExc)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDataVarRndExc::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataVarRndExc)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataVarRndExc, CDialog)
	//{{AFX_MSG_MAP(CDataVarRndExc)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataVarRndExc message handlers

void CDataVarRndExc::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CPen	redPen(PS_SOLID, 1, RGB(255,0,0));
	char	s[256];
	FILE	*fp;
	float	*pvals, tmp;
	int		i, j, x, y, start, num_good;
	
	// TODO: Add your message handler code here

	dc.MoveTo( 20, 20);
	dc.LineTo( 20,420);
	dc.MoveTo( 20,420);
	dc.LineTo(820,420);
	dc.MoveTo( 20,420);
	dc.LineTo(820, 20);
	
	dc.SelectObject(&redPen);
	// Get the actual data
	
	sprintf(s, "experiments/%s/%s/data5", generatorDir[tp.generator],
		testNames[TESTS_RANDOM_EXCUR_VAR]);
	if ( (fp = fopen(s, "r")) == NULL ) {
		MessageBox(s, "File Open Error", MB_ICONSTOP|MB_OK);
		return;
	}
	
	pvals = (float *)calloc(sizeof(float), tp.numOfBitStreams);
	for ( i=0; i<tp.numOfBitStreams; i++ )
		fscanf(fp, "%f\n", &(pvals[i]));
	fclose(fp);

	for (i=0; i<tp.numOfBitStreams-1; i++ )
		for ( j=i+1; j<tp.numOfBitStreams; j++ )
			if ( pvals[j] < pvals[i] ) {
				tmp = pvals[i];
				pvals[i] = pvals[j];
				pvals[j] = tmp;
			}

	for ( i=0; i<tp.numOfBitStreams; i++ ) {
		if ( pvals[i] == 0.0 )
			start = i;
	}
	//  These values for start and num_good leave the first 0 in the list
	num_good = tp.numOfBitStreams - start;
	for ( i=start; i<tp.numOfBitStreams; i++ ) {
		x = (800 * (i-start)) / num_good;
		y = (int)(400 * pvals[i]);
		dc.Ellipse(x-1+20, 420-y-1, x+1+20, 420-y+1);
		}
	
	// Do not call CDialog::OnPaint() for painting messages
}
