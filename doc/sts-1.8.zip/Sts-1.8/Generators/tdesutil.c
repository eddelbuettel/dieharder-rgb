/*****************************************************************************
 *  TDESUTIL.C                                                  VERSION 1.00 *
 *---------------------------------------------------------------------------*
 *  October 1998                                                             *
 *---------------------------------------------------------------------------*
 *  This software was developed at the National Institute of Standards and   *
 *  Technology by employees of the Federal Government in the course of their *
 *  official duties. Pursuant to title 17 Section 105 of the United States   *
 *  Code this software is not subject to copyright protection and is in the  *
 *  public domain.  We would appreciate acknowledgement if the software is   *
 *  used.																	 *
 *	This software was produced as part of research efforts and is for		 *
 *  demonstration purposes only. Our primary goals in its design did not	 *
 *	include widespread use outside of our own laboratories. Acceptance of	 *
 *	this software implies that you agree to use it for non-commercial		 *
 *	purposes only and that you agree to accept it as nonproprietary and		 *
 *	unlicensed, not supported by NIST and not carrying any warranty, either	 *
 *	expressed or implied, as to its performance or fitness for any particular*
 *	purpose.										                         *
 *---------------------------------------------------------------------------*
 *																			 *
 *  Produced by the National Institute of Standards and Technology (NIST),   *
 *  Information Technology Laboratory (ITL) Security Technology Group.		 *
 *****************************************************************************
 * Separating out the util functions to this file for use by all other files.*                                  *
 *---------------------------------------------------------------------------*
 *  Version:     1                                                           *
 *  Programmer:  Sharon S. Keller                                            *
 *  History:     7-21-98 - (Created, SSK)                                    *
 *                   Completed 12/11/98                                      *
 ****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "tdesutil.h"
//#include "CAVSDefs.h"
#include "defs.h"
#include "mp.h"
// #include "..\include\externs.h"
#include "tdes.h"

time_t hld_time = 0;

//#define TDESDEBUG
/*****************************************************************************
 *  BDES.C                                                                   *
 *---------------------------------------------------------------------------*
 *  D A T A   E N C R Y P T I O N   S T A N D A R D                          *
 *  FEDERAL INFORMATION PROCESSING STANDARDS PUBLICATION (FIPS PUB) 46       *
 *  JANUARY 15, 1977                                                         *
 *---------------------------------------------------------------------------*
 *  This software is used at the National Bureau of Standards (NBS) as       *
 *  a part of research efforts and for demonstration purposes only.  Use     *
 *  of this software implies that you agree to accept it as nonproprietary   *
 *  our own laboratories.  Use of this software implies that you             *
 *  agree to accept it as nonproprietary and unlicensed, not supported by    *
 *  NBS, and not carrying any warranty, either expressed or implied, as to   *
 *  its performance or fitness for any particular purpose.                   *
 *---------------------------------------------------------------------------*
 * This DES software was developed by Steve Kent and John Linn               *
 * at BBN Communications Corporation, Cambridge, MA                          *
 * Do not redistribute this software, or integrate with other                *
 * software, without preserving this notice.                                 *
 *---------------------------------------------------------------------------*
 *  Modified by David M. Balenson, March 1988, for use with NBS software.    *
 ****************************************************************************/

/* fastdemo.c: jl 5 May 1986: demonstrate DES in various modes, using */
/* optimized DES version */
/* changes 2 June 1986: */
/* use Dan Hoey's IP, IP-1 optimization */

/* define TIMEONLY to time DES cycles rather than run ordinary demo */
/* timing data on C/70, (compiled -O) with 500 iterations */
/* (each iteration is an encrypt+decrypt) */
/* without HOEYOPT: typical DES op is about 7.825 msec (470 ticks/1000 opns) */
/* with HOEYOPT: typical DES op is about 7.425 msec (445 ticks/1000 opns) */
/* this compares with VAX timing of a slightly different version, */
/* (pre-HOEYOPT) of 2.6 ms/cycle */

#include        <ctype.h>

#define FALSE   0
#define TRUE    1

int getlinef();
int ahtop();

#define EXSHMSK(A,M,B,S,TMP)    \
    TMP = ((B >> S) ^ A) & M;   \
    A ^= TMP;                   \
    TMP <<= S;                  \
    B ^= TMP

/* tables to describe permutations, per NBS FIPS */

static int pc1c [] =
	{ 57, 49, 41, 33, 25, 17, 9,
	  1, 58, 50, 42, 34, 26, 18,
	  10, 2, 59, 51, 43, 35, 27,
	  19, 11, 3, 60, 52, 44, 36 };

static int pc1d [] =
	{ 63, 55, 47, 39, 31, 23, 15,
	  7, 62, 54, 46, 38, 30, 22,
	  14, 6, 61, 53, 45, 37, 29,
	  21, 13, 5, 28, 20, 12, 4 };

static int shiftsked []=
	{ 1, 1, 2, 2, 2, 2, 2, 2,
	  1, 2, 2, 2, 2, 2, 2, 1 };

static long snop [8] [64] = {
0X808200L,0X0L,0X8000L,0X808202L,
0X808002L,0X8202L,0X2L,0X8000L,
0X200L,0X808200L,0X808202L,0X200L,
0X800202L,0X808002L,0X800000L,0X2L,
0X202L,0X800200L,0X800200L,0X8200L,
0X8200L,0X808000L,0X808000L,0X800202L,
0X8002L,0X800002L,0X800002L,0X8002L,
0X0L,0X202L,0X8202L,0X800000L,
0X8000L,0X808202L,0X2L,0X808000L,
0X808200L,0X800000L,0X800000L,0X200L,
0X808002L,0X8000L,0X8200L,0X800002L,
0X200L,0X2L,0X800202L,0X8202L,
0X808202L,0X8002L,0X808000L,0X800202L,
0X800002L,0X202L,0X8202L,0X808200L,
0X202L,0X800200L,0X800200L,0X0L,
0X8002L,0X8200L,0X0L,0X808002L,

0X104L,0X4010100L,0X0L,0X4010004L,
0X4000100L,0X0L,0X10104L,0X4000100L,
0X10004L,0X4000004L,0X4000004L,0X10000L,
0X4010104L,0X10004L,0X4010000L,0X104L,
0X4000000L,0X4L,0X4010100L,0X100L,
0X10100L,0X4010000L,0X4010004L,0X10104L,
0X4000104L,0X10100L,0X10000L,0X4000104L,
0X4L,0X4010104L,0X100L,0X4000000L,
0X4010100L,0X4000000L,0X10004L,0X104L,
0X10000L,0X4010100L,0X4000100L,0X0L,
0X100L,0X10004L,0X4010104L,0X4000100L,
0X4000004L,0X100L,0X0L,0X4010004L,
0X4000104L,0X10000L,0X4000000L,0X4010104L,
0X4L,0X10104L,0X10100L,0X4000004L,
0X4010000L,0X4000104L,0X104L,0X4010000L,
0X10104L,0X4L,0X4010004L,0X10100L,

0X80L,0X1040080L,0X1040000L,0X21000080L,
0X40000L,0X80L,0X20000000L,0X1040000L,
0X20040080L,0X40000L,0X1000080L,0X20040080L,
0X21000080L,0X21040000L,0X40080L,0X20000000L,
0X1000000L,0X20040000L,0X20040000L,0X0L,
0X20000080L,0X21040080L,0X21040080L,0X1000080L,
0X21040000L,0X20000080L,0X0L,0X21000000L,
0X1040080L,0X1000000L,0X21000000L,0X40080L,
0X40000L,0X21000080L,0X80L,0X1000000L,
0X20000000L,0X1040000L,0X21000080L,0X20040080L,
0X1000080L,0X20000000L,0X21040000L,0X1040080L,
0X20040080L,0X80L,0X1000000L,0X21040000L,
0X21040080L,0X40080L,0X21000000L,0X21040080L,
0X1040000L,0X0L,0X20040000L,0X21000000L,
0X40080L,0X1000080L,0X20000080L,0X40000L,
0X0L,0X20040000L,0X1040080L,0X20000080L,

0X100000L,0X2100001L,0X2000401L,0X0L,
0X400L,0X2000401L,0X100401L,0X2100400L,
0X2100401L,0X100000L,0X0L,0X2000001L,
0X1L,0X2000000L,0X2100001L,0X401L,
0X2000400L,0X100401L,0X100001L,0X2000400L,
0X2000001L,0X2100000L,0X2100400L,0X100001L,
0X2100000L,0X400L,0X401L,0X2100401L,
0X100400L,0X1L,0X2000000L,0X100400L,
0X2000000L,0X100400L,0X100000L,0X2000401L,
0X2000401L,0X2100001L,0X2100001L,0X1L,
0X100001L,0X2000000L,0X2000400L,0X100000L,
0X2100400L,0X401L,0X100401L,0X2100400L,
0X401L,0X2000001L,0X2100401L,0X2100000L,
0X100400L,0X0L,0X1L,0X2100401L,
0X0L,0X100401L,0X2100000L,0X400L,
0X2000001L,0X2000400L,0X400L,0X100001L,

0X40084010L,0X40004000L,0X4000L,0X84010L,
0X80000L,0X10L,0X40080010L,0X40004010L,
0X40000010L,0X40084010L,0X40084000L,0X40000000L,
0X40004000L,0X80000L,0X10L,0X40080010L,
0X84000L,0X80010L,0X40004010L,0X0L,
0X40000000L,0X4000L,0X84010L,0X40080000L,
0X80010L,0X40000010L,0X0L,0X84000L,
0X4010L,0X40084000L,0X40080000L,0X4010L,
0X0L,0X84010L,0X40080010L,0X80000L,
0X40004010L,0X40080000L,0X40084000L,0X4000L,
0X40080000L,0X40004000L,0X10L,0X40084010L,
0X84010L,0X10L,0X4000L,0X40000000L,
0X4010L,0X40084000L,0X80000L,0X40000010L,
0X80010L,0X40004010L,0X40000010L,0X80010L,
0X84000L,0X0L,0X40004000L,0X4010L,
0X40000000L,0X40080010L,0X40084010L,0X84000L,

0X80401000L,0X80001040L,0X80001040L,0X40L,
0X401040L,0X80400040L,0X80400000L,0X80001000L,
0X0L,0X401000L,0X401000L,0X80401040L,
0X80000040L,0X0L,0X400040L,0X80400000L,
0X80000000L,0X1000L,0X400000L,0X80401000L,
0X40L,0X400000L,0X80001000L,0X1040L,
0X80400040L,0X80000000L,0X1040L,0X400040L,
0X1000L,0X401040L,0X80401040L,0X80000040L,
0X400040L,0X80400000L,0X401000L,0X80401040L,
0X80000040L,0X0L,0X0L,0X401000L,
0X1040L,0X400040L,0X80400040L,0X80000000L,
0X80401000L,0X80001040L,0X80001040L,0X40L,
0X80401040L,0X80000040L,0X80000000L,0X1000L,
0X80400000L,0X80001000L,0X401040L,0X80400040L,
0X80001000L,0X1040L,0X400000L,0X80401000L,
0X40L,0X400000L,0X1000L,0X401040L,

0X10000008L,0X10200000L,0X2000L,0X10202008L,
0X10200000L,0X8L,0X10202008L,0X200000L,
0X10002000L,0X202008L,0X200000L,0X10000008L,
0X200008L,0X10002000L,0X10000000L,0X2008L,
0X0L,0X200008L,0X10002008L,0X2000L,
0X202000L,0X10002008L,0X8L,0X10200008L,
0X10200008L,0X0L,0X202008L,0X10202000L,
0X2008L,0X202000L,0X10202000L,0X10000000L,
0X10002000L,0X8L,0X10200008L,0X202000L,
0X10202008L,0X200000L,0X2008L,0X10000008L,
0X200000L,0X10002000L,0X10000000L,0X2008L,
0X10000008L,0X10202008L,0X202000L,0X10200000L,
0X202008L,0X10202000L,0X0L,0X10200008L,
0X8L,0X2000L,0X10200000L,0X202008L,
0X2000L,0X200008L,0X10002008L,0X0L,
0X10202000L,0X10000000L,0X200008L,0X10002008L,

0X8000820L,0X800L,0X20000L,0X8020820L,
0X8000000L,0X8000820L,0X20L,0X8000000L,
0X20020L,0X8020000L,0X8020820L,0X20800L,
0X8020800L,0X20820L,0X800L,0X20L,
0X8020000L,0X8000020L,0X8000800L,0X820L,
0X20800L,0X20020L,0X8020020L,0X8020800L,
0X820L,0X0L,0X0L,0X8020020L,
0X8000020L,0X8000800L,0X20820L,0X20000L,
0X20820L,0X20000L,0X8020800L,0X800L,
0X20L,0X8020020L,0X800L,0X20820L,
0X8000800L,0X20L,0X8000020L,0X8020000L,
0X8020020L,0X8000000L,0X20000L,0X8000820L,
0X0L,0X8020820L,0X20020L,0X8000020L,
0X8020000L,0X8000800L,0X8000820L,0X0L,
0X8020820L,0X20800L,0X20800L,0X820L,
0X820L,0X20020L,0X8000000L,0X8020800L 
};

static long pc2otab [8] [128] = {
0X0L,0X10L,0X4000L,0X4010L,0X40000L,0X40010L,0X44000L,0X44010L,
0X100L,0X110L,0X4100L,0X4110L,0X40100L,0X40110L,0X44100L,0X44110L,
0X20000L,0X20010L,0X24000L,0X24010L,0X60000L,0X60010L,0X64000L,0X64010L,
0X20100L,0X20110L,0X24100L,0X24110L,0X60100L,0X60110L,0X64100L,0X64110L,
0X1L,0X11L,0X4001L,0X4011L,0X40001L,0X40011L,0X44001L,0X44011L,
0X101L,0X111L,0X4101L,0X4111L,0X40101L,0X40111L,0X44101L,0X44111L,
0X20001L,0X20011L,0X24001L,0X24011L,0X60001L,0X60011L,0X64001L,0X64011L,
0X20101L,0X20111L,0X24101L,0X24111L,0X60101L,0X60111L,0X64101L,0X64111L,
0X80000L,0X80010L,0X84000L,0X84010L,0XC0000L,0XC0010L,0XC4000L,0XC4010L,
0X80100L,0X80110L,0X84100L,0X84110L,0XC0100L,0XC0110L,0XC4100L,0XC4110L,
0XA0000L,0XA0010L,0XA4000L,0XA4010L,0XE0000L,0XE0010L,0XE4000L,0XE4010L,
0XA0100L,0XA0110L,0XA4100L,0XA4110L,0XE0100L,0XE0110L,0XE4100L,0XE4110L,
0X80001L,0X80011L,0X84001L,0X84011L,0XC0001L,0XC0011L,0XC4001L,0XC4011L,
0X80101L,0X80111L,0X84101L,0X84111L,0XC0101L,0XC0111L,0XC4101L,0XC4111L,
0XA0001L,0XA0011L,0XA4001L,0XA4011L,0XE0001L,0XE0011L,0XE4001L,0XE4011L,
0XA0101L,0XA0111L,0XA4101L,0XA4111L,0XE0101L,0XE0111L,0XE4101L,0XE4111L,

0X0L,0X800000L,0X2L,0X800002L,0X200L,0X800200L,0X202L,0X800202L,
0X200000L,0XA00000L,0X200002L,0XA00002L,0X200200L,0XA00200L,0X200202L,0XA00202L,
0X1000L,0X801000L,0X1002L,0X801002L,0X1200L,0X801200L,0X1202L,0X801202L,
0X201000L,0XA01000L,0X201002L,0XA01002L,0X201200L,0XA01200L,0X201202L,0XA01202L,
0X0L,0X800000L,0X2L,0X800002L,0X200L,0X800200L,0X202L,0X800202L,
0X200000L,0XA00000L,0X200002L,0XA00002L,0X200200L,0XA00200L,0X200202L,0XA00202L,
0X1000L,0X801000L,0X1002L,0X801002L,0X1200L,0X801200L,0X1202L,0X801202L,
0X201000L,0XA01000L,0X201002L,0XA01002L,0X201200L,0XA01200L,0X201202L,0XA01202L,
0X40L,0X800040L,0X42L,0X800042L,0X240L,0X800240L,0X242L,0X800242L,
0X200040L,0XA00040L,0X200042L,0XA00042L,0X200240L,0XA00240L,0X200242L,0XA00242L,
0X1040L,0X801040L,0X1042L,0X801042L,0X1240L,0X801240L,0X1242L,0X801242L,
0X201040L,0XA01040L,0X201042L,0XA01042L,0X201240L,0XA01240L,0X201242L,0XA01242L,
0X40L,0X800040L,0X42L,0X800042L,0X240L,0X800240L,0X242L,0X800242L,
0X200040L,0XA00040L,0X200042L,0XA00042L,0X200240L,0XA00240L,0X200242L,0XA00242L,
0X1040L,0X801040L,0X1042L,0X801042L,0X1240L,0X801240L,0X1242L,0X801242L,
0X201040L,0XA01040L,0X201042L,0XA01042L,0X201240L,0XA01240L,0X201242L,0XA01242L,

0X0L,0X2000L,0X4L,0X2004L,0X400L,0X2400L,0X404L,0X2404L,
0X0L,0X2000L,0X4L,0X2004L,0X400L,0X2400L,0X404L,0X2404L,
0X400000L,0X402000L,0X400004L,0X402004L,0X400400L,0X402400L,0X400404L,0X402404L,
0X400000L,0X402000L,0X400004L,0X402004L,0X400400L,0X402400L,0X400404L,0X402404L,
0X20L,0X2020L,0X24L,0X2024L,0X420L,0X2420L,0X424L,0X2424L,
0X20L,0X2020L,0X24L,0X2024L,0X420L,0X2420L,0X424L,0X2424L,
0X400020L,0X402020L,0X400024L,0X402024L,0X400420L,0X402420L,0X400424L,0X402424L,
0X400020L,0X402020L,0X400024L,0X402024L,0X400420L,0X402420L,0X400424L,0X402424L,
0X8000L,0XA000L,0X8004L,0XA004L,0X8400L,0XA400L,0X8404L,0XA404L,
0X8000L,0XA000L,0X8004L,0XA004L,0X8400L,0XA400L,0X8404L,0XA404L,
0X408000L,0X40A000L,0X408004L,0X40A004L,0X408400L,0X40A400L,0X408404L,0X40A404L,
0X408000L,0X40A000L,0X408004L,0X40A004L,0X408400L,0X40A400L,0X408404L,0X40A404L,
0X8020L,0XA020L,0X8024L,0XA024L,0X8420L,0XA420L,0X8424L,0XA424L,
0X8020L,0XA020L,0X8024L,0XA024L,0X8420L,0XA420L,0X8424L,0XA424L,
0X408020L,0X40A020L,0X408024L,0X40A024L,0X408420L,0X40A420L,0X408424L,0X40A424L,
0X408020L,0X40A020L,0X408024L,0X40A024L,0X408420L,0X40A420L,0X408424L,0X40A424L,

0X0L,0X10000L,0X8L,0X10008L,0X80L,0X10080L,0X88L,0X10088L,
0X0L,0X10000L,0X8L,0X10008L,0X80L,0X10080L,0X88L,0X10088L,
0X100000L,0X110000L,0X100008L,0X110008L,0X100080L,0X110080L,0X100088L,0X110088L,
0X100000L,0X110000L,0X100008L,0X110008L,0X100080L,0X110080L,0X100088L,0X110088L,
0X800L,0X10800L,0X808L,0X10808L,0X880L,0X10880L,0X888L,0X10888L,
0X800L,0X10800L,0X808L,0X10808L,0X880L,0X10880L,0X888L,0X10888L,
0X100800L,0X110800L,0X100808L,0X110808L,0X100880L,0X110880L,0X100888L,0X110888L,
0X100800L,0X110800L,0X100808L,0X110808L,0X100880L,0X110880L,0X100888L,0X110888L,
0X0L,0X10000L,0X8L,0X10008L,0X80L,0X10080L,0X88L,0X10088L,
0X0L,0X10000L,0X8L,0X10008L,0X80L,0X10080L,0X88L,0X10088L,
0X100000L,0X110000L,0X100008L,0X110008L,0X100080L,0X110080L,0X100088L,0X110088L,
0X100000L,0X110000L,0X100008L,0X110008L,0X100080L,0X110080L,0X100088L,0X110088L,
0X800L,0X10800L,0X808L,0X10808L,0X880L,0X10880L,0X888L,0X10888L,
0X800L,0X10800L,0X808L,0X10808L,0X880L,0X10880L,0X888L,0X10888L,
0X100800L,0X110800L,0X100808L,0X110808L,0X100880L,0X110880L,0X100888L,0X110888L,
0X100800L,0X110800L,0X100808L,0X110808L,0X100880L,0X110880L,0X100888L,0X110888L,

0X0L,0X0L,0X80L,0X80L,0X2000L,0X2000L,0X2080L,0X2080L,
0X1L,0X1L,0X81L,0X81L,0X2001L,0X2001L,0X2081L,0X2081L,
0X200000L,0X200000L,0X200080L,0X200080L,0X202000L,0X202000L,0X202080L,0X202080L,
0X200001L,0X200001L,0X200081L,0X200081L,0X202001L,0X202001L,0X202081L,0X202081L,
0X20000L,0X20000L,0X20080L,0X20080L,0X22000L,0X22000L,0X22080L,0X22080L,
0X20001L,0X20001L,0X20081L,0X20081L,0X22001L,0X22001L,0X22081L,0X22081L,
0X220000L,0X220000L,0X220080L,0X220080L,0X222000L,0X222000L,0X222080L,0X222080L,
0X220001L,0X220001L,0X220081L,0X220081L,0X222001L,0X222001L,0X222081L,0X222081L,
0X2L,0X2L,0X82L,0X82L,0X2002L,0X2002L,0X2082L,0X2082L,
0X3L,0X3L,0X83L,0X83L,0X2003L,0X2003L,0X2083L,0X2083L,
0X200002L,0X200002L,0X200082L,0X200082L,0X202002L,0X202002L,0X202082L,0X202082L,
0X200003L,0X200003L,0X200083L,0X200083L,0X202003L,0X202003L,0X202083L,0X202083L,
0X20002L,0X20002L,0X20082L,0X20082L,0X22002L,0X22002L,0X22082L,0X22082L,
0X20003L,0X20003L,0X20083L,0X20083L,0X22003L,0X22003L,0X22083L,0X22083L,
0X220002L,0X220002L,0X220082L,0X220082L,0X222002L,0X222002L,0X222082L,0X222082L,
0X220003L,0X220003L,0X220083L,0X220083L,0X222003L,0X222003L,0X222083L,0X222083L,

0X0L,0X10L,0X800000L,0X800010L,0X10000L,0X10010L,0X810000L,0X810010L,
0X200L,0X210L,0X800200L,0X800210L,0X10200L,0X10210L,0X810200L,0X810210L,
0X0L,0X10L,0X800000L,0X800010L,0X10000L,0X10010L,0X810000L,0X810010L,
0X200L,0X210L,0X800200L,0X800210L,0X10200L,0X10210L,0X810200L,0X810210L,
0X100000L,0X100010L,0X900000L,0X900010L,0X110000L,0X110010L,0X910000L,0X910010L,
0X100200L,0X100210L,0X900200L,0X900210L,0X110200L,0X110210L,0X910200L,0X910210L,
0X100000L,0X100010L,0X900000L,0X900010L,0X110000L,0X110010L,0X910000L,0X910010L,
0X100200L,0X100210L,0X900200L,0X900210L,0X110200L,0X110210L,0X910200L,0X910210L,
0X4L,0X14L,0X800004L,0X800014L,0X10004L,0X10014L,0X810004L,0X810014L,
0X204L,0X214L,0X800204L,0X800214L,0X10204L,0X10214L,0X810204L,0X810214L,
0X4L,0X14L,0X800004L,0X800014L,0X10004L,0X10014L,0X810004L,0X810014L,
0X204L,0X214L,0X800204L,0X800214L,0X10204L,0X10214L,0X810204L,0X810214L,
0X100004L,0X100014L,0X900004L,0X900014L,0X110004L,0X110014L,0X910004L,0X910014L,
0X100204L,0X100214L,0X900204L,0X900214L,0X110204L,0X110214L,0X910204L,0X910214L,
0X100004L,0X100014L,0X900004L,0X900014L,0X110004L,0X110014L,0X910004L,0X910014L,
0X100204L,0X100214L,0X900204L,0X900214L,0X110204L,0X110214L,0X910204L,0X910214L,

0X0L,0X400L,0X1000L,0X1400L,0X80000L,0X80400L,0X81000L,0X81400L,
0X20L,0X420L,0X1020L,0X1420L,0X80020L,0X80420L,0X81020L,0X81420L,
0X4000L,0X4400L,0X5000L,0X5400L,0X84000L,0X84400L,0X85000L,0X85400L,
0X4020L,0X4420L,0X5020L,0X5420L,0X84020L,0X84420L,0X85020L,0X85420L,
0X800L,0XC00L,0X1800L,0X1C00L,0X80800L,0X80C00L,0X81800L,0X81C00L,
0X820L,0XC20L,0X1820L,0X1C20L,0X80820L,0X80C20L,0X81820L,0X81C20L,
0X4800L,0X4C00L,0X5800L,0X5C00L,0X84800L,0X84C00L,0X85800L,0X85C00L,
0X4820L,0X4C20L,0X5820L,0X5C20L,0X84820L,0X84C20L,0X85820L,0X85C20L,
0X0L,0X400L,0X1000L,0X1400L,0X80000L,0X80400L,0X81000L,0X81400L,
0X20L,0X420L,0X1020L,0X1420L,0X80020L,0X80420L,0X81020L,0X81420L,
0X4000L,0X4400L,0X5000L,0X5400L,0X84000L,0X84400L,0X85000L,0X85400L,
0X4020L,0X4420L,0X5020L,0X5420L,0X84020L,0X84420L,0X85020L,0X85420L,
0X800L,0XC00L,0X1800L,0X1C00L,0X80800L,0X80C00L,0X81800L,0X81C00L,
0X820L,0XC20L,0X1820L,0X1C20L,0X80820L,0X80C20L,0X81820L,0X81C20L,
0X4800L,0X4C00L,0X5800L,0X5C00L,0X84800L,0X84C00L,0X85800L,0X85C00L,
0X4820L,0X4C20L,0X5820L,0X5C20L,0X84820L,0X84C20L,0X85820L,0X85C20L,

0X0L,0X100L,0X40000L,0X40100L,0X0L,0X100L,0X40000L,0X40100L,
0X40L,0X140L,0X40040L,0X40140L,0X40L,0X140L,0X40040L,0X40140L,
0X400000L,0X400100L,0X440000L,0X440100L,0X400000L,0X400100L,0X440000L,0X440100L,
0X400040L,0X400140L,0X440040L,0X440140L,0X400040L,0X400140L,0X440040L,0X440140L,
0X8000L,0X8100L,0X48000L,0X48100L,0X8000L,0X8100L,0X48000L,0X48100L,
0X8040L,0X8140L,0X48040L,0X48140L,0X8040L,0X8140L,0X48040L,0X48140L,
0X408000L,0X408100L,0X448000L,0X448100L,0X408000L,0X408100L,0X448000L,0X448100L,
0X408040L,0X408140L,0X448040L,0X448140L,0X408040L,0X408140L,0X448040L,0X448140L,
0X8L,0X108L,0X40008L,0X40108L,0X8L,0X108L,0X40008L,0X40108L,
0X48L,0X148L,0X40048L,0X40148L,0X48L,0X148L,0X40048L,0X40148L,
0X400008L,0X400108L,0X440008L,0X440108L,0X400008L,0X400108L,0X440008L,0X440108L,
0X400048L,0X400148L,0X440048L,0X440148L,0X400048L,0X400148L,0X440048L,0X440148L,
0X8008L,0X8108L,0X48008L,0X48108L,0X8008L,0X8108L,0X48008L,0X48108L,
0X8048L,0X8148L,0X48048L,0X48148L,0X8048L,0X8148L,0X48048L,0X48148L,
0X408008L,0X408108L,0X448008L,0X448108L,0X408008L,0X408108L,0X448008L,0X448108L,
0X408048L,0X408148L,0X448048L,0X448148L,0X408048L,0X408148L,0X448048L,0X448148L 
};

/* --- some bit manipulation primitives --- */

/* g_keybit -- extract bit bnum from the key in inkey */
#define g_keybit(bnum) (01 & (inkey [bnum/8] >> (8 - (bnum%8))))

/* do left rotate of 28 bit quantity */
long    lrot28 (long lval)
{
  lval <<= 1;
  if (0X10000000L & lval) lval++;
  lval &= 0XFFFFFFFL;
  return (lval);
}
/* SUPPORT ROUTINES FOR DEMODES */

static void  packbtol (BYTE as_ba[], long *as_l)   /* pack 4 bytes into a long */
{
  long lt;

  lt = as_ba [0] & 0xff;
  lt <<= 8;
  lt |= as_ba [1] & 0xff;
  lt <<= 8;
  lt |= as_ba [2] & 0xff;
  lt <<= 8;
  lt |= as_ba [3] & 0xff;

  *as_l = lt;
}


/* SETKEY - Generate key schedule for given key and type of cryption 
 */
/* Make key schedule from key bytes in inkey */
/*staticSSK*/ int setkey (int sw1, int sw2, BYTE inkey[8], unsigned ks[16][4])
{
  extern long pc2otab [8] [128];

  int   round, r;
  long  pcct, pcdt;
  long  pc2out [2];
  int   i, j, parac;
  BYTE incopy;

  /* test parity of bytes in inkey */
  if (sw1) {
    for (i = 0; i < 8; i++)       /* do each byte */
    {
      parac = 0;
      incopy = inkey [i];

      for (j = 0; j < 8; j++)     /* 8 bits in a DES byte */
      {
        if (incopy & 01) parac++;
        incopy >>= 1;
      }
      if (! (parac & 01)) return (0); /* no odd parity on this byte */
    }
  }

  /* do pc-1 permutation, extracting bits from inkey */
  pcct = pcdt = 0L;
  for (i = 0; i < 27; i++)   
   /* filling all appropriate bits */
  {
    pcct |= g_keybit(pc1c [i]);
    pcdt |= g_keybit(pc1d [i]);
    pcct <<= 1;
    pcdt <<= 1;
  }
  /* one final ior, without a shift */
  pcct |= g_keybit(pc1c [i]);
  pcdt |= g_keybit(pc1d [i]);

  for (round = 0; round < 16; round++)
  {
    /* always at least one shift */
    pcct = lrot28 (pcct);
    pcdt = lrot28 (pcdt);

    if (shiftsked [round] == 2)
    {   /* this round needs another shift */
      pcct = lrot28 (pcct);
      pcdt = lrot28 (pcdt);
    } 

    /* Now, pcct and pcdt have the values on which we can apply
       pc2 and select the key bits, storing them in pc2out[0] and
       pc2out[1]. The high order [pc2out[0]] bits all come from
       pcct, and the low order from pcdt. */

    pc2out [0] = pc2otab [0] [pcct >> 21];
    pc2out [0] |= pc2otab [1] [0X7F & (pcct >> 14)];
    pc2out [0] |= pc2otab [2] [0X7F & (pcct >> 7)];
    pc2out [0] |= pc2otab [3] [0X7F & pcct];

    pc2out [1] = pc2otab [4] [pcdt >> 21];
    pc2out [1] |= pc2otab [5] [0X7F & (pcdt >> 14)];
    pc2out [1] |= pc2otab [6] [0X7F & (pcdt >> 7)];
    pc2out [1] |= pc2otab [7] [0X7F & pcdt];

    /* order key bits and bytes so as to be compatible with
       the format generated by the E implementation */

    r = sw2 ? 15-round : round;

    ks [r] [0] = 0XFC00 & (pc2out [0] >> 8);
    ks [r] [0] |= (0XFC & (pc2out [0] >> 4));
    ks [r] [1] = 0XFC00 & (pc2out [1] >> 8);
    ks [r] [1] |= (0XFC & (pc2out [1] >> 4));

    ks [r] [2] = 0XFC00 & (pc2out [0] >> 2);
    ks [r] [2] |= (0XFC & (pc2out [0] << 2));
    ks [r] [3] = 0XFC00 & (pc2out [1] >> 2);
    ks [r] [3] |= (0XFC & (pc2out [1] << 2));
  }
  return (TRUE);
}

#define LMASK    0XFCFCFCFCL;

/* doip -- permute 64 bits from inar to outar */
static void  doip (long inar[2], long outar[2])
{
  long lt;

  outar [0] = inar [0];
  outar [1] = inar [1];
  EXSHMSK(outar[1],0x0f0f0f0f,outar[0],4,lt);
  EXSHMSK(outar[1],0x0000ffff,outar[0],16,lt);
  EXSHMSK(outar[0],0x33333333,outar[1],2,lt);
  EXSHMSK(outar[0],0x00ff00ff,outar[1],8,lt);
  EXSHMSK(outar[1],0x55555555,outar[0],1,lt);
}

/* doipi -- perform ip-inverse */
static void  doipi (long inar[2], long outar[2])
{
  long lt;

  outar [0] = inar [0];
  outar [1] = inar [1];
  EXSHMSK(outar[1],0x55555555,outar[0],1,lt);
  EXSHMSK(outar[0],0x00ff00ff,outar[1],8,lt);
  EXSHMSK(outar[0],0x33333333,outar[1],2,lt);
  EXSHMSK(outar[1],0x0000ffff,outar[0],16,lt);
  EXSHMSK(outar[1],0x0f0f0f0f,outar[0],4,lt);
}

/* des -- encrypt/decrypt a block under key sched in ks */
int des (BYTE in[8], BYTE out[8], unsigned ks[16][4])
{
	long	inar[2], outar[2];
	int		round, oddbit;
	unsigned	expan[4];   /* receives output of E transform */
	long	sbout, scopy, tlong;
	long	oarr[2];
	extern long snop [8] [64];
#ifdef TDESDEBUG
	int		i, j;
	FILE	*fp;

	fp = fopen("atest4.txt", "a");

	fprintf(fp, "KS is:\n");
	for ( i=0; i<16; i++ ) {
		for ( j=0; j<4; j++ )
			fprintf(fp, "%04x ", ks[i][j]);
		fprintf(fp, "\n");
	}
#endif

	packbtol(&in[0], &inar[0]);
	packbtol(&in[4], &inar[1]);

	doip (inar, outar);

	for ( round=0; round<16; round++ ) {
		sbout = 0L;

		tlong = outar [1];
		oddbit = (int) (01 & tlong);
		tlong >>= 1;
		tlong &= 0X7FFFFFFFL;       /* defeat sign extend -- jl 17 feb 84 */
		if (oddbit) tlong |= 0X80000000L;

		tlong &= LMASK;
		expan[0] = (unsigned) (tlong >> 16);
		expan[1] = (unsigned) tlong;

		tlong = outar [1];
		oddbit = !! (tlong & 0X80000000L);
		tlong <<= 3;
		if (oddbit) tlong |= 04;
		tlong &= LMASK;
		expan[2] = (unsigned) (tlong >> 16);
		expan[3] = (unsigned) tlong;

		/* this code bypasses the alternative of loop setup 
		and resultant computation within the loop for speed */
		expan [0] ^= ks [round] [0];
		sbout |= snop[0][0X3F & (expan [0] >> 10)];
		sbout |= snop[1][0X3F & (expan [0] >> 2)];
		expan [1] ^= ks [round] [1];
		sbout |= snop[2][0X3F & (expan [1] >> 10)];
		sbout |= snop[3][0X3F & (expan [1] >> 2)];
		expan [2] ^= ks [round] [2];
		sbout |= snop[4][0X3F & (expan [2] >> 10)];
		sbout |= snop[5][0X3F & (expan [2] >> 2)];
		expan [3] ^= ks [round] [3];
		sbout |= snop[6][0X3F & (expan [3] >> 10)];
		sbout |= snop[7][0X3F & (expan [3] >> 2)];

		scopy = outar[0];
		outar[0] = outar[1];
		outar[1] = scopy ^ sbout;
#ifdef TDESDEBUG
		fprintf(fp, "Loop %2d: outar is <%08x%08x>\n", round, outar[0], outar[1]);
#endif
	}

	/* a final swap */
	scopy = outar[0];
	outar[0] = outar[1];
	outar[1] = scopy;

	doipi(outar, oarr);  /* perform ip-inverse into temp copy */
	outar[0] = oarr[0];
	outar[1] = oarr[1];

	sprdltob(outar[0], &out[0]);
	sprdltob(outar[1], &out[4]);
#ifdef TDESDEBUG
	fprintf(fp, "Leaving DES: <");
	for (i=0; i<8; i++)
		fprintf(fp, "%02x", out[i]);
	fprintf(fp, ">\n");
	fclose(fp);
#endif

	return 0;
}


static void  sprdltob (long as_l, BYTE as_ba[])  /* spread a long into 4 bytes */
{
  as_ba [0] = (char) ((as_l >> 24) & 0xff);
  as_ba [1] = (char) ((as_l >> 16) & 0xff);
  as_ba [2] = (char) ((as_l >> 8) & 0xff);
  as_ba [3] = (char) (as_l & 0xff);
}




/* PACK()  Pack n bytes at 1 bit/byte into n/8 bytes at 8 bits/byte
BYTE *packed;		packed block ( n bytes at 8 bits/byte)
BYTE *binary;		the unpacked block (n*8 bytes at 1 bit/byte) */
/*static*/ void pack(BYTE *packed, BYTE *binary, int len)
{
        int i, j, k;

        for (i=0; i<len; i++) {
                k = 0;
                for (j=0; j<8; j++) k = (k<<1) + *binary++;
                *packed++ = k;
        }
}


/* UNPACK()  Unpack n bytes at 8 bits/byte into n*8 bytes at 1 bit/byte
BYTE *packed;		packed block (n bytes at 8 bits/byte)
BYTE *binary;		unpacked block (n*8 bytes at 1 bit/byte) */
/*static*/ void unpack(BYTE *packed, BYTE *binary, int len) 
{
        int i, j, k;
        for (i=0; i<len; i++) {
                k = *packed++;
        for (j=0; j<8; j++) *binary++ = (k>>(7-j)) & 01;
        }
}

/* xor8 - op2 = op1 ^ op2
 */
static void xor8 (BSTRTD op1, BSTRTD op2)
{
 int i;
 for (i=0;i<8;i++) op2[i] ^= op1[i];
}


static void xor_up (BSTRTD arr1_up, BSTRTD arr2_up, int off, int len)
{
 int i;
 for (i=off;i<off+len;i++) arr1_up[i]^=arr2_up[i];
}

static void shl_up (BSTRTD arr_up, int num, int len)
{
 int i;
 for (i=0;i<len-num;i++) {
  arr_up[i]=arr_up[i+num], 
  arr_up[i+num]=0;
 }
}


static void dump(FILE *fp, char *str, char *arr, int len)
{
  fprintf(fp,str);
  while (len--) fprintf(fp,"%02X",(unsigned char)*arr++);
  fprintf(fp,"\n");
}

/******************************************************************************
 *  GETF_HEX2()      Accepts ASCII-HEXADECIMAL input from the card reader.     *
 ******************************************************************************/

#define MAXLINE 100

void getf_hex2(FILE *name, int len, char *resp)
{
	int i, j, n;
	int valid = FALSE;
	char temp1[MAXLINE+1];
	char temp2[MAXLINE+1];
	
	/* DOUBLE CHECK PARAMETERS */
	if ((len < 0) || (len > MAXLINE) || ((len % 2) != 0)) {
		fprintf(stderr,"get_hex2: invalid length (%d).\n", len);
		exit(1);
	}

	/* FETCH HEXADECIMAL INPUT */
	while (!valid) {
		n = getlinef(name,temp1,MAXLINE);
		for (i=0, j=0; i<n; i++) {
			if (isxdigit(temp1[i])) temp2[j++] = temp1[i];
			if (j == len) break;
		}
		temp2[j] = '\00';
		if (j < len) printf("\007ENTER AT LEAST %d HEX DIGITS.\n",len);
		else {
			ahtop(resp,temp2,len);
		    	valid = TRUE;
		}
	}
}
/******************************************************************************
 *  GETLINEF()                                                                 *
 ******************************************************************************/

int
getlinef(FILE *ptr, char *s, int l)		/* get at most l characters into s */
{
	int cc, i;

	i=0;
	while (--l > 0 && (cc=fgetc(ptr)) != EOF && cc != '\n')
		s[i++] = cc;
	s[i] = '\00';
	return(i);
}
/******************************************************************************
 *  AHTOP()  Convert 'len' ASCII hex chars in 'ah' into packed BYTEs in 'p'   *
 ******************************************************************************/

int
ahtop(BYTE *p, char *ah, int len)
{
	register i;

	for (i=0;i<len;i++) if (!isxdigit(ah[i])) return(FALSE);
	for (i=0;i<len;i+=2)
	    if (sscanf(&ah[i],"%02x",&p[i/2]) != 1) return(FALSE);
	return(TRUE);
}
/******************************************************************************
 *  GETLINE()                                                                 *
 ******************************************************************************/

getline(char *s,int l)		/* get at most l characters into s */
{
	int cc, i;

	i=0;
	while (--l > 0 && (cc=getchar()) != EOF && cc != '\n')
		s[i++] = cc;
	s[i] = '\00';
	return(i);
}

/*************************************************************************
 *  PUTL()                                                               *
 *************************************************************************/

/*static*/ void putl(char c, char *s)
{
	int i, l, l1, l2;

	if ((l = strlen(s)) == 0) {
	    for (i=0;i<79;i++) putchar(c);
	    putchar('\n');
         }
        l1 = (77 - l) / 2;
	l2 = 77 - l - l1;
	for (i=0; i<l1; i++) putchar(c);
	putchar(' ');
	for (i=0; i<l; i++) putchar(s[i]);
	putchar(' ');
	for (i=0; i<l2; i++) putchar(c);
	putchar('\n');
}
/***************************************************************************/
/***************************************************************************
 *  GET_HEX2()      Accepts ASCII-HEXADECIMAL input from the card reader.     *
 ***************************************************************************/

#define MAXLINE 100

void get_hex2(char *name, int len, char *resp)
{
	int i, j, n;
	int valid = FALSE;
	char temp1[MAXLINE+1];
	char temp2[MAXLINE+1];
	
	/* DOUBLE CHECK PARAMETERS */
	if ((len < 0) || (len > MAXLINE) || ((len % 2) != 0)) {
		fprintf(stderr,"get_hex2: invalid length (%d).\n", len);
		exit(1);
	}

	/* FETCH HEXADECIMAL INPUT */
        while (!valid) {
		printf("%s",name);
		n = getline(temp1,MAXLINE);
		for (i=0, j=0; i<n; i++) {
			if (isxdigit(temp1[i])) temp2[j++] = temp1[i];
			if (j == len) break;
		}
		temp2[j] = '\0';
		if (j < len) printf("\007ENTER AT LEAST %d HEX DIGITS.\n",len);
		else {
			ahtop(resp,temp2,len);
		    	valid = TRUE;
		}
	}
printf("\nresp is ");
for (i=0;i<len/2;i++)
  printf("%02x", resp[i]);
}

//set odd parity 02-17-00

void
setoddparity(BYTE key1[], BYTE key2[], BYTE key3[])
{
	BYTE bmask, key[8];
	int i, j, k, bcount;
for (i=0;i<3;i++)
   {
  	switch(i) {
 		case 0:  memcpy(key, key1, 8);
			   break;
		case 1:  memcpy(key, key2, 8);
			   break;
		case 2:  memcpy(key, key3, 8);
			   break;
	}
                     
      /* Set key bytes to ODD parity */
 	for (j=0;j<8;j++)
	 {
	   bmask = (BYTE) MSBIT;
	   bcount = 0;
	   for (k=0;k<8;k++)
	    {
	      if (bmask & key[j])
	        bcount++;
	      bmask >>= 1;
	    }
	  if (!(bcount %2))
	    key[j] ^= 0x01;
	 }

  	switch(i) {
 		case 0:  memcpy(key1, key, 8);
			   break;
		case 1:  memcpy(key2, key, 8);
			   break;
		case 2:  memcpy(key3, key, 8);
			   break;
	}
  } /*end i loop*/
}

void 
calculateiv2iv3(BYTE *iv1, BYTE *iv2, BYTE *iv3)
{
	BYTE R1[] = {0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55};
	BYTE R2[] = {0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa};

	//calculate value of IV2 and IV3 based on value of IV1
	/*Use IV1 */

	memcpy(iv2, iv1, 8);
	add (iv2, 8, R1, 8);

	/*now add R2 to IV1 to make iv3 */
	memcpy(iv3, iv1, 8);
	add (iv3, 8, R2, 8);
}


void key56to64(BYTE *key56, BYTE *key64)
{
	BYTE	keyin[7];
	int		i, j;

	bcopy(key56, keyin, 7);
	for ( i=7; i>=0; i-- ) {
		key64[i] = keyin[6] << 1;
		for ( j=0; j<7; j++ )
			bshr(keyin, 7);
	}
}

/* TDESInit - intializes the DES Context to begin a Triple DES operation
	DES keys (packed) may be NULL
	DES mode (TDES_CBC, TDES_ECB, TDES_CFB1,TDES_CFB8, 
              TDES_CFB64, TDES_OFB) 
	crypt	 (DES_ENCIPHER or DES_DECIPHER)
 */

int /*EXPORT*/  TDESInit (P_TDESCTX context, BSTRTD key1, BSTRTD key2, BSTRTD key3, BSTRTD iv, int mode, int crypt)
{
  /* set up the DES Context
   */

/*	 if (mode != TDES_ECB && mode != TDES_CBC && mode != TDES_OFB &&
      mode != TDES_CFB && mode != TDES_OFBI && mode != TDES_CBCI &&
      mode != TDES_CFBP && mode != TDES_CFB_64 && mode != TDES_CFB_8 && mode != TDES_CFB_1
	  && mode != TDES_CFBP_64 && TDES_CFBP_8 && TDES_CFBP_1) {exit (1);}
*/
  context->Mode = mode;

  context->crypt = crypt;

  if (mode != TDES_ECB && mode != TDES_CBC && mode != TDES_OFB &&
      mode != TDES_OFBI && mode != TDES_CBCI )
  { 
    switch (mode) {
      case TDES_CFB_64: context->kbit=64;
                       context->Mode = TDES_CFB;
                       break;
      case TDES_CFB_8:  context->kbit=8;
                       context->Mode = TDES_CFB;
                       break;
      case TDES_CFB_1:  context->kbit=1;
                       context->Mode = TDES_CFB;
                       break;
      case TDES_CFBP_64: context->kbit=64;
                       context->Mode = TDES_CFBP;
                       break;
      case TDES_CFBP_8:  context->kbit=8;
                       context->Mode = TDES_CFBP;
                       break;
      case TDES_CFBP_1:  context->kbit=1;
                       context->Mode = TDES_CFBP;
                       break;
      case TDES_CFB:
      case TDES_CFBP:
						context->kbit=64;
						break;
      default:         return TDES_INVALID_MODE;
    }
}
	 if (context->Mode != TDES_ECB) {
		 if (iv==NULL)  { return TDES_NOIV; }

		 /* Store IV into DES context */
			memcpy(context->IV1, iv, 8);

			calculateiv2iv3(context->IV1, context->IV2, context->IV3);
	 }
  /* Generate DES key schedule and load it into DES Context */

	setoddparity(key1, key2, key3);
     if ((context->Mode == TDES_CFB || context->Mode == TDES_CFBP||
          context ->Mode==TDES_OFB || context->Mode == TDES_OFBI)
       && (crypt==DES_DECIPHER))
 
       {
         setkey(IGNOREPARITY,DES_ENCIPHER,key1,context->KS1);
         setkey(IGNOREPARITY,DES_DECIPHER,key2,context->KS2);
         setkey(IGNOREPARITY,DES_ENCIPHER,key3,context->KS3);
       }
     else 
     {
     setkey(IGNOREPARITY,crypt,key1,context->KS1);
     setkey(IGNOREPARITY,!crypt,key2,context->KS2);
     setkey(IGNOREPARITY,crypt,key3,context->KS3);
     }

   return 0;
}

/*  TDES()
		The modes defined below are for the test suite only.  Some
		changes would need to be made to have the routines work for
		all modes of operation.  For example, the k-bit CFB is not
		initialized properly.  Also, the "chained modes" (all modes
		except ECB) would need to maintain previous values for the
		next call.
*/
void TDES(P_TDESCTX context,
		 BYTE *input,
		 BYTE *output,
		 FILE *stream)
{
	BYTE	ib[8], ob[8];
	int		i;
	if ( context->crypt == DES_ENCIPHER )
		switch (context->Mode) {
			case TDES_ECB:
				for ( i=0; i<8; i++ )
					ib[i] = input[i];
				break;
			case TDES_CBC:
				for ( i=0; i<8; i++ )
					ib[i] = input[i] ^ context->IV1[i];
				break;
			case TDES_CBCI:
				switch(context->leafnum) {
					case 1:
						for ( i=0; i<8; i++ )
							ib[i] = input[i] ^ context->IV1[i];
						break;
					case 2:
						for ( i=0; i<8; i++ )
							ib[i] = input[i] ^ context->IV2[i];
						break;
					case 3:
						for ( i=0; i<8; i++ )
							ib[i] = input[i] ^ context->IV3[i];
						break;
					}
				break;
			case TDES_OFB:
			case TDES_CFB:
			case TDES_CFB_1:
			case TDES_CFB_8:
			case TDES_CFB_64:
				for ( i=0; i<8; i++ )
					ib[i] = context->IV1[i];
				break;
			case TDES_CFBP:
			case TDES_CFBP_1:
			case TDES_CFBP_8:
			case TDES_CFBP_64:
				switch(context->leafnum) {
					case 1:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;
					case 2:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV2[i];
						break;
					case 3:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV3[i];
						break;
					default: 
						/* will be RM input(j-1) || output*/
 						/* this is computed in monte program and stored in
							context.IV1. */ 
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;	
					}
				break;
			case TDES_OFBI:
				switch(context->leafnum) {
					case 1:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;
					case 2:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV2[i];
						break;
					case 3:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV3[i];
						break;
					default: 
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;	
					}
				break;
			}/*switch*/
	else  /* Mode is Decipher  */
		switch (context->Mode) {
			case TDES_ECB:
			case TDES_CBC:
			case TDES_CBCI:
				for ( i=0; i<8; i++ )
					ib[i] = input[i];
				break;
			/* Do need CFB for modes tests.  I think it will
				only get here if it is cfb modes since the
				other tests force cryption to be Encipher*/
			case TDES_OFB:
			case TDES_CFB:
			case TDES_CFB_1:
			case TDES_CFB_8:
			case TDES_CFB_64:
				for ( i=0; i<8; i++ )
					ib[i] = context->IV1[i];
				break;

			case TDES_CFBP:
			case TDES_CFBP_1:
			case TDES_CFBP_8:
			case TDES_CFBP_64:
				switch(context->leafnum) {
					case 1:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;
					case 2:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV2[i];
						break;
					case 3:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV3[i];
						break;
					default: 
						/* will be RM input(j-1) || output*/
 						/* this is computed in monte program and stored in
							context.IV1. */ 
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;	
					}
				break;

			case TDES_OFBI:
				switch(context->leafnum) {
					case 1:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;
					case 2:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV2[i];
						break;
					case 3:
						for ( i=0; i<8; i++ )
							ib[i] = context->IV3[i];
						break;
					default: 
						for ( i=0; i<8; i++ )
							ib[i] = context->IV1[i];
						break;	
					}
				break;
	}
	TDES_Core(context, ib, ob);			

	if ( context->crypt == DES_ENCIPHER )
		switch (context->Mode) {
			case TDES_ECB:
			case TDES_CBC:
			case TDES_CBCI:
				for ( i=0; i<8; i++ )
					output[i] = ob[i];
				break;
			case TDES_OFB:
			case TDES_OFBI:
				for (i=0; i<8; i++ )
					output[i] = ob[i] ^ input[i];
				break;
			case TDES_CFB:
			case TDES_CFB_1:
			case TDES_CFB_8:
			case TDES_CFB_64:
			case TDES_CFBP:
			case TDES_CFBP_1:
			case TDES_CFBP_8:
			case TDES_CFBP_64: 
				for (i=0;i<8;i++)
					output[i] = ob[i] ^ input[i];
				break;
				
		}
	else  /* Mode is Decipher  */
		switch (context->Mode) {
			case TDES_ECB:
				for ( i=0; i<8; i++ )
					output[i] = ob[i];
				break;
			case TDES_CBC:
				for ( i=0; i<8; i++ )
					output[i] = ob[i] ^ context->IV1[i];
				break;
			case TDES_CBCI:
				switch(context->leafnum) {
					case 1:
						for ( i=0; i<8; i++ )
							output[i] = ob[i] ^ context->IV1[i];
						break;
					case 2:
						for ( i=0; i<8; i++ )
							output[i] = ob[i] ^ context->IV2[i];
						break;
					case 3:
						for ( i=0; i<8; i++ )
							output[i] = ob[i] ^ context->IV3[i];
						break;
					}
				break;
			case TDES_OFB:
			case TDES_OFBI:
				for (i=0; i<8; i++ )
					output[i] = ob[i] ^ input[i];
				break;
			case TDES_CFB:
			case TDES_CFB_1:
			case TDES_CFB_8:
			case TDES_CFB_64:
			case TDES_CFBP:
			case TDES_CFBP_1:
			case TDES_CFBP_8:
			case TDES_CFBP_64: 
				for (i=0;i<8;i++)
					output[i] = ob[i] ^ input[i];
				break;
			/* Shouldn't need TDES_CFB's or TDES_OFB's here */
			}
	}

void TDES_Core(P_TDESCTX context, BYTE *input, BYTE *output)
{
	BYTE interm1[8], interm2[8];
#ifdef TDESDEBUG 
	int		i;
	BYTE	strg1[16], strg2[16], strg3[16];
	FILE	*stream;
#endif
	if (context->crypt == DES_ENCIPHER || (context->Mode & TDES_ENCEQDEC_MASK) ) 
		des(&input[0], interm1, context->KS1);
	else
		des(input, interm1, context->KS3);
	des(interm1, interm2,context->KS2);

	if (context->crypt == DES_ENCIPHER || (context->Mode & TDES_ENCEQDEC_MASK))
		des(interm2, output, context->KS3);
	else
		des(interm2, &output[0], context->KS1);

#ifdef TDESDEBUG
	stream = fopen("atest.txt", "a");

	if (context->crypt == DES_ENCIPHER || (context->Mode & TDES_ENCEQDEC_MASK)) {
		strcpy(strg1," K1 - Enc - ");
		strcpy(strg2," K2 - Dec - ");
		strcpy(strg3," K3 - Enc - ");
	}
	else {
	strcpy(strg1," K3 - Dec - ");
	strcpy(strg2," K2 - Enc - ");
	strcpy(strg3," K1 - Dec - ");
	}
		fprintf(stream,"\nDEA %s Input: ", strg1);
	 	for (i=0;i<8;i++)
			fprintf(stream,"%02x", input[i]);
		fprintf(stream,"\tOutput:  ");
		for (i=0;i<8;i++)
		  fprintf(stream,"%02x", interm1[i]);
		fprintf(stream,"\nDEA %s Input: ", strg2);
		for (i=0;i<8;i++)
		  fprintf(stream,"%02x", interm1[i]);
		fprintf(stream,"\tOutput:  ");
		for (i=0;i<8;i++)
		  fprintf(stream,"%02x", interm2[i]);
		fprintf(stream,"\nDEA %s Input: ", strg3);
		for (i=0;i<8;i++)
		  fprintf(stream,"%02x", interm2[i]);
		fprintf(stream,"\tOutput:  ");
		for (i=0;i<8;i++)
		  fprintf(stream,"%02x", output[i]);
		fprintf(stream, "\n");
		fclose(stream);
#endif
}


int TDES_Test()
{
	TDESCTX	context;
	BYTE	key1[8], key2[8], key3[8], pt[8], ct[8];
	
	key1[0] = key2[0] = key3[0] = 0x01;
	key1[1] = key2[1] = key3[1] = 0x23;
	key1[2] = key2[2] = key3[2] = 0x45;
	key1[3] = key2[3] = key3[3] = 0x67;
	key1[4] = key2[4] = key3[4] = 0x89;
	key1[5] = key2[5] = key3[5] = 0xab;
	key1[6] = key2[6] = key3[6] = 0xcd;
	key1[7] = key2[7] = key3[7] = 0xef;

	pt[0] = 0x4e;
	pt[1] = 0x6f;
	pt[2] = 0x77;
	pt[3] = 0x20;
	pt[4] = 0x69;
	pt[5] = 0x73;
	pt[6] = 0x20;
	pt[7] = 0x74;

	// Call TDESInit to make the key schedule
	if ( TDESInit(&context, key1, key2, key3, NULL, TDES_ECB, DES_ENCIPHER) )
		return 0;

	TDES(&context, pt, ct, NULL);

	if ( (ct[0] != 0x3f) || (ct[1] != 0xa4) || (ct[2] != 0x0e) || (ct[3] != 0x8a) ||
	     (ct[4] != 0x98) || (ct[5] != 0x4d) || (ct[6] != 0x48) || (ct[7] != 0x15) )
		return 0;

	return 1;
} //  TDES_Test

void basis_vector(BYTE *arr, int arr_len, int bitpos)
{
	int				i;
	unsigned int	mask;

	if ( bitpos/8 > arr_len )
		return;
	for ( i=0; i<bitpos/8; i++ )
		arr[i] = 0x00;

	mask = 0x80;
	for ( i=0; i<bitpos%8; i++ )
		mask >>= 1;
	arr[bitpos/8] = mask;

	for ( i=bitpos/8+1; i<arr_len; i++ )
		arr[i] = 0x00;
}


/****************************************************************************/
/* bit_shift_left - shifts array left by one bit.                           */
/*                                                                          */
/* Parameters:                                                              */
/*                                                                          */
/* x    Address of array x                                                  */
/* l    Length array x in bytes                                             */
/*                                                                          */
/****************************************************************************/
void bit_shift_left(char *x, int l)
  {
    char *p;
    int c1, c2;

    p = x + l-1;
    c1 = 0;
    c2 = 0;
    while (p != x)
    {
     if (*p & (char)0x80)
       c2 = 1;
     *p <<= 1; /* shift the word left once (ls bit = 0) */
     if (c1)
       *p += 1;
     c1 = c2;
     c2 = 0;
     p--;
    }
    *p <<= 1; /* shift the word left once (ls bit = 0) */
    if (c1)
      *p += 1;
 }

void shift_concat(
	int kbits,
	BYTE *iv,
	int len,
	BYTE *result)
{
	int	i;

	switch (kbits) {
		case 1:
			bit_shift_left(iv, len);
			if ( result[0] & (BYTE)MSBIT )
				iv[len-1] |= (BYTE)LSBIT;
			break;
		case 8:
			for (i=0; i<len-1; i++)
				iv[i] = iv[i+1];
			iv[len-1] = result[0];
			break;
		case 64:
			for (i=0; i<len-8; i++)
				iv[i] = iv[i+8];
			for (i=len-8; i<len; i++)
				iv[i] = result[i-(len-8)];
			break;
		}
	}

void genrand( BYTE *val, int len )
{
	int i;

	/* Seed the random-number generator with current time so that
	 * the numbers will be different every time we run.    */
	if ( hld_time == 0 )
		hld_time = time( NULL );
	srand(hld_time);

	for (i=0; i<len; i++)
		val[i] = rand() & 0xff;
	hld_time = rand();
}

void printvalue(P_TDESCTX context, BYTE *input, FILE *stream)
{
	int i;

	if (context->kbit > 1)
		for (i=0; i<context->kbit/8; i++)
			fprintf(stream,"%02x", input[i]);
	else
		if (input[0] & (BYTE) MSBIT)
			fprintf(stream, "1");
		else
			fprintf(stream, "0");
	fprintf(stream, "\n");
	}

void GetErrorMsg(char *msg, int errorno)
{
	switch (errorno) {

		case TDES_VARPT_ERR:
			strcpy (msg, "Variable PT KAT");
			break;
		case TDES_INVPERM_ERR:
			strcpy (msg, "Inverse Permutation KAT");
			break;
		case TDES_VARKEY_ERR: 
			strcpy (msg, "Variable Key KAT");
			break;
		case TDES_PERMOP_ERR: 
			strcpy (msg, "Permutation Operation KAT");
			break;
		case TDES_SUBTAB_ERR: 
			strcpy (msg, "Substitution Table KAT");
			break;
		case TDES_MONTE_ERR: 
			strcpy (msg, "Monte Carlo (Modes) Test");
			break;
		case TDES_INVALID_MODE:
			strcpy (msg, "Invalid mode passed");
			break;
		case TDES_NOIV:
			strcpy (msg, "IV required");
			break;
		case TDES_OPENFILE_FAILED:
			strcpy (msg, "File not opened successfully");
			break;
		}
}

