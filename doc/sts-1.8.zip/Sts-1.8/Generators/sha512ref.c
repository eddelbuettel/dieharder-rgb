#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sha512.h"
#include "mp.h"

//#define	DEBUG_SHA512

//void bshr(BYTE *x, int len);

WORD64	K512[80] = {
	{ 0x428a2f98, 0xd728ae22}, { 0x71374491, 0x23ef65cd},
	{ 0xb5c0fbcf, 0xec4d3b2f}, { 0xe9b5dba5, 0x8189dbbc},
	{ 0x3956c25b, 0xf348b538}, { 0x59f111f1, 0xb605d019},
	{ 0x923f82a4, 0xaf194f9b}, { 0xab1c5ed5, 0xda6d8118},
	{ 0xd807aa98, 0xa3030242}, { 0x12835b01, 0x45706fbe},
	{ 0x243185be, 0x4ee4b28c}, { 0x550c7dc3, 0xd5ffb4e2},
	{ 0x72be5d74, 0xf27b896f}, { 0x80deb1fe, 0x3b1696b1},
	{ 0x9bdc06a7, 0x25c71235}, { 0xc19bf174, 0xcf692694},
	{ 0xe49b69c1, 0x9ef14ad2}, { 0xefbe4786, 0x384f25e3},
	{ 0x0fc19dc6, 0x8b8cd5b5}, { 0x240ca1cc, 0x77ac9c65},
	{ 0x2de92c6f, 0x592b0275}, { 0x4a7484aa, 0x6ea6e483},
	{ 0x5cb0a9dc, 0xbd41fbd4}, { 0x76f988da, 0x831153b5},
	{ 0x983e5152, 0xee66dfab}, { 0xa831c66d, 0x2db43210},
	{ 0xb00327c8, 0x98fb213f}, { 0xbf597fc7, 0xbeef0ee4},
	{ 0xc6e00bf3, 0x3da88fc2}, { 0xd5a79147, 0x930aa725},
	{ 0x06ca6351, 0xe003826f}, { 0x14292967, 0x0a0e6e70},
	{ 0x27b70a85, 0x46d22ffc}, { 0x2e1b2138, 0x5c26c926},
	{ 0x4d2c6dfc, 0x5ac42aed}, { 0x53380d13, 0x9d95b3df},
	{ 0x650a7354, 0x8baf63de}, { 0x766a0abb, 0x3c77b2a8},
	{ 0x81c2c92e, 0x47edaee6}, { 0x92722c85, 0x1482353b},
	{ 0xa2bfe8a1, 0x4cf10364}, { 0xa81a664b, 0xbc423001},
	{ 0xc24b8b70, 0xd0f89791}, { 0xc76c51a3, 0x0654be30},
	{ 0xd192e819, 0xd6ef5218}, { 0xd6990624, 0x5565a910},
	{ 0xf40e3585, 0x5771202a}, { 0x106aa070, 0x32bbd1b8},
	{ 0x19a4c116, 0xb8d2d0c8}, { 0x1e376c08, 0x5141ab53},
	{ 0x2748774c, 0xdf8eeb99}, { 0x34b0bcb5, 0xe19b48a8},
	{ 0x391c0cb3, 0xc5c95a63}, { 0x4ed8aa4a, 0xe3418acb},
	{ 0x5b9cca4f, 0x7763e373}, { 0x682e6ff3, 0xd6b2b8a3},
	{ 0x748f82ee, 0x5defb2fc}, { 0x78a5636f, 0x43172f60},
	{ 0x84c87814, 0xa1f0ab72}, { 0x8cc70208, 0x1a6439ec},
	{ 0x90befffa, 0x23631e28}, { 0xa4506ceb, 0xde82bde9},
	{ 0xbef9a3f7, 0xb2c67915}, { 0xc67178f2, 0xe372532b},
	{ 0xca273ece, 0xea26619c}, { 0xd186b8c7, 0x21c0c207},
	{ 0xeada7dd6, 0xcde0eb1e}, { 0xf57d4f7f, 0xee6ed178},
	{ 0x06f067aa, 0x72176fba}, { 0x0a637dc5, 0xa2c898a6},
	{ 0x113f9804, 0xbef90dae}, { 0x1b710b35, 0x131c471b},
	{ 0x28db77f5, 0x23047d84}, { 0x32caab7b, 0x40c72493},
	{ 0x3c9ebe0a, 0x15c9bebc}, { 0x431d67c4, 0x9c100d4c},
	{ 0x4cc5d4be, 0xcb3e42b6}, { 0x597f299c, 0xfc657e2a},
	{ 0x5fcb6fab, 0x3ad6faec}, { 0x6c44198c, 0x4a475817} };


void CalcT1_512(WORD64 T1, WORD64 h, WORD64 e, WORD64 f, WORD64 g, WORD64 Wj, int j)
{
	WORD64	tmp1, tmp2;

	T1[0] = h[0];
	T1[1] = h[1];

	tmp1[0] = ((e[0] & f[0]) ^ (~e[0] & g[0]));	/*	Ch(e, f, g);  */
	tmp1[1] = ((e[1] & f[1]) ^ (~e[1] & g[1]));
	add_WORD64(T1, tmp1);

	ROT_WORD64(tmp1, e, 14);		/* CapSigma1(e)  */
	ROT_WORD64(tmp2, e, 18);
	tmp1[0] ^= tmp2[0];
	tmp1[1] ^= tmp2[1];
	ROT_WORD64(tmp2, e, 41);
	tmp1[0] ^= tmp2[0];
	tmp1[1] ^= tmp2[1];
	add_WORD64(T1, tmp1);

	add_WORD64(T1, K512[j]);
	add_WORD64(T1, Wj);
	}


void CalcT2_512(WORD64 T2, WORD64 a, WORD64 b, WORD64 c)
{
	WORD64	tmp1, tmp2;

	T2[0] = ((a[0] & b[0]) ^ (a[0] & c[0]) ^ (b[0] & c[0]));	/*	Maj(a, b, c);  */
	T2[1] = ((a[1] & b[1]) ^ (a[1] & c[1]) ^ (b[1] & c[1]));

	ROT_WORD64(tmp1, a, 28);		/* CapSigma0(e)  */
	ROT_WORD64(tmp2, a, 34);
	tmp1[0] ^= tmp2[0];
	tmp1[1] ^= tmp2[1];
	ROT_WORD64(tmp2, a, 39);
	tmp1[0] ^= tmp2[0];
	tmp1[1] ^= tmp2[1];
	add_WORD64(T2, tmp1);
	}


void CalcWj_512(WORD64 Wj, WORD64 Wj2, WORD64 Wj7, WORD64 Wj15, WORD64 Wj16)
{
	WORD64	tmp1, tmp2;

	Wj[0] = Wj16[0];
	Wj[1] = Wj16[1];

	ROT_WORD64(tmp1, Wj2, 19);		/* smallSigma1(Wj2)  */
	ROT_WORD64(tmp2, Wj2, 61);
	tmp1[0] ^= tmp2[0];
	tmp1[1] ^= tmp2[1];
	tmp1[0] ^= Wj2[0] >> 6;
	tmp1[1] ^= (Wj2[1] >> 6) | (Wj2[0] << 26);
	add_WORD64(Wj, tmp1);

	add_WORD64(Wj, Wj7);

	ROT_WORD64(tmp1, Wj15, 1);		/* smallSigma0(Wj15)  */
	ROT_WORD64(tmp2, Wj15, 8);
	tmp1[0] ^= tmp2[0];
	tmp1[1] ^= tmp2[1];
	tmp1[0] ^= Wj15[0] >> 7;
	tmp1[1] ^= (Wj15[1] >> 7) | (Wj15[0] << 25);
	add_WORD64(Wj, tmp1);
	}


void SHA512_ProcessBlock(SHA512_CTX *ctx)
{
	int		j;
	WORD64	T1, T2, a, b, c, d, e, f, g, h;
	WORD64	W[SHA512_WORD64BLOCKLEN];

	for (j=0; j<SHA512_WORD64BLOCKLEN; j++) {
		W[j][0] = ctx->Mblock[j][0];
		W[j][1] = ctx->Mblock[j][1];
		}

	a[0] = ctx->H[0][0];
	a[1] = ctx->H[0][1];
	b[0] = ctx->H[1][0];
	b[1] = ctx->H[1][1];
	c[0] = ctx->H[2][0];
	c[1] = ctx->H[2][1];
	d[0] = ctx->H[3][0];
	d[1] = ctx->H[3][1];
	e[0] = ctx->H[4][0];
	e[1] = ctx->H[4][1];
	f[0] = ctx->H[5][0];
	f[1] = ctx->H[5][1];
	g[0] = ctx->H[6][0];
	g[1] = ctx->H[6][1];
	h[0] = ctx->H[7][0];
	h[1] = ctx->H[7][1];

	/*  Changed the following from "j<64" to "j<4" for testing purposes */
	for (j=0; j<80; j++) {
		if ( j > 15 )
			CalcWj_512(W[j%16], W[(j-2)%16], W[(j-7)%16], W[(j-15)%16], W[j%16]);

		CalcT1_512(T1, h, e, f, g, W[j%16], j);
		CalcT2_512(T2, a, b, c);

		h[0] = g[0];
		h[1] = g[1];
		g[0] = f[0];
		g[1] = f[1];
		f[0] = e[0];
		f[1] = e[1];
		e[0] = d[0];
		e[1] = d[1];
		add_WORD64(e, T1);
		d[0] = c[0];
		d[1] = c[1];
		c[0] = b[0];
		c[1] = b[1];
		b[0] = a[0];
		b[1] = a[1];
		a[0] = T1[0];
		a[1] = T1[1];
		add_WORD64(a, T2);
		}
	if ( (ctx->H[0][1] + a[1]) < a[1] )
		a[0]++;
	ctx->H[0][0] += a[0];
	ctx->H[0][1] += a[1];
	if ( (ctx->H[1][1] + b[1]) < b[1] )
		b[0]++;
	ctx->H[1][0] += b[0];
	ctx->H[1][1] += b[1];
	if ( (ctx->H[2][1] + c[1]) < c[1] )
		c[0]++;
	ctx->H[2][0] += c[0];
	ctx->H[2][1] += c[1];
	if ( (ctx->H[3][1] + d[1]) < d[1] )
		d[0]++;
	ctx->H[3][0] += d[0];
	ctx->H[3][1] += d[1];
	if ( (ctx->H[4][1] + e[1]) < e[1] )
		e[0]++;
	ctx->H[4][0] += e[0];
	ctx->H[4][1] += e[1];
	if ( (ctx->H[5][1] + f[1]) < f[1] )
		f[0]++;
	ctx->H[5][0] += f[0];
	ctx->H[5][1] += f[1];
	if ( (ctx->H[6][1] + g[1]) < g[1] )
		g[0]++;
	ctx->H[6][0] += g[0];
	ctx->H[6][1] += g[1];
	if ( (ctx->H[7][1] + h[1]) < h[1] )
		h[0]++;
	ctx->H[7][0] += h[0];
	ctx->H[7][1] += h[1];
	}


/**********************************************************************/
/*	 SHA512_Init initialization routine.                              */
/*		Clears all fields in the SHA Context structure and primes the */
/*		hash with the initialization vector.                          */
/**********************************************************************/
int SHA512_Init(SHA512_CTX *ctx)
{
	int i;
	WORD64 IH[SHA512_WORD64HASHLEN] = {
		{ 0x6a09e667, 0xf3bcc908 },
		{ 0xbb67ae85, 0x84caa73b },
		{ 0x3c6ef372, 0xfe94f82b },
		{ 0xa54ff53a, 0x5f1d36f1 },
		{ 0x510e527f, 0xade682d1 },
		{ 0x9b05688c, 0x2b3e6c1f },
		{ 0x1f83d9ab, 0xfb41bd6b },
		{ 0x5be0cd19, 0x137e2179 } };

	ctx->MsgLen[0][0] = 0x00000000L;
	ctx->MsgLen[0][1] = 0x00000000L;
	ctx->MsgLen[1][0] = 0x00000000L;
	ctx->MsgLen[1][1] = 0x00000000L;
	ctx->Numbits = 0;
	for (i=0; i<SHA512_WORD64BLOCKLEN; i++) {
		ctx->Mblock[i][0] = 0x00000000L;
		ctx->Mblock[i][1] = 0x00000000L;
		}
	for (i=0; i<SHA512_WORD64HASHLEN ;i++) {
		ctx->H[i][0] = IH[i][0];
		ctx->H[i][1] = IH[i][1];
		}
	return 0;
	}


/**********************************************************************/
/*	 SHA512_Init2 initialization routine.                             */
/*		Clears all fields in the SHA Context structure and primes the */
/*		hash with the user supplied initialization vector.            */
/**********************************************************************/
int SHA512_Init2(SHA512_CTX *ctx, WORD64 *IH)
{
	int i;

	ctx->MsgLen[0][0] = 0x00000000L;
	ctx->MsgLen[0][1] = 0x00000000L;
	ctx->MsgLen[1][0] = 0x00000000L;
	ctx->MsgLen[1][1] = 0x00000000L;
	ctx->Numbits = 0;
	for (i=0; i<SHA512_WORD64BLOCKLEN; i++) {
		ctx->Mblock[i][0] = 0x00000000L;
		ctx->Mblock[i][1] = 0x00000000L;
		}
	for (i=0; i<SHA512_WORD64HASHLEN ;i++) {
		ctx->H[i][0] = IH[i][0];
		ctx->H[i][1] = IH[i][1];
		}
	return 0;
	}


/**********************************************************************/
/*	 SHA512_Update hashes full 512 bit blocks. Assumes that           */
/*	 bitcount is a multiple of SHA512_BLOCKLEN until the final        */
/*	 buffer is being processed. In this case, the data has            */
/*	 less than 512 bits then it saves the data for a                  */
/*	 subsequent call to SHA512_Final.                                 */
/**********************************************************************/
int SHA512_Update(SHA512_CTX *ctx, BYTE *buffer, int bitcount)
{
	int		offsetBytes, offsetBits;
  	BYTE	tbuf[SHA512_BYTEBLOCKLEN+1];

	while ( (bitcount+ctx->Numbits) >= SHA512_BLOCKLEN ) {
	   	offsetBytes = ctx->Numbits / 8;
   		offsetBits = ctx->Numbits % 8;

		/* increment Message Length counter  */
		if ( (ctx->MsgLen[1][1] + SHA512_BLOCKLEN) < ctx->MsgLen[1][1] ) {
			if ( ctx->MsgLen[1][0] == 0xffffffff ) {
				if ( ctx->MsgLen[0][1] == 0xffffffff ) {
					if (ctx->MsgLen[0][0] == 0xffffffff )
						exit(-1);
					ctx->MsgLen[0][0]++;
					}
				ctx->MsgLen[0][1]++;
				}
			ctx->MsgLen[1][0]++;
			}
		ctx->MsgLen[1][1] += SHA512_BLOCKLEN;

		/* Process full block now */
		if ( offsetBits == 0 ) {
			memcpy((BYTE *) ctx->Mblock+offsetBytes, buffer, SHA512_BYTEBLOCKLEN-offsetBytes);
			}
		else {
			BYTE	tbuf[SHA512_BYTEBLOCKLEN+1], tbuf2[SHA512_BYTEBLOCKLEN+1];
			int		i, offset1, rmdr1, offset2;

			offset1 = ctx->Numbits/8;
			offset2 = bitcount/8;
			rmdr1 = ctx->Numbits%8;

			/* tbuf gets the current contents of Mblock */
			memset(tbuf, '\0', SHA512_BYTEBLOCKLEN);
			memcpy(tbuf, ctx->Mblock, offset1+1);

			/* tbuf 2 gets the new data to go into Mblock */
			memset(tbuf2, '\0', SHA512_BYTEBLOCKLEN);
			memcpy(tbuf2+offset1, buffer, offset2+1);
			for ( i=0; i<rmdr1; i++ )
				bshr(tbuf2, SHA512_BYTEBLOCKLEN);

			xor(tbuf, tbuf, tbuf2, SHA512_BYTEBLOCKLEN);

			memcpy((BYTE *)ctx->Mblock, tbuf, SHA512_BYTEBLOCKLEN);
			ctx->Numbits += bitcount;
			}

#ifdef LITTLE_ENDIAN
byteReverse64(ctx->Mblock, SHA512_WORD64BLOCKLEN);
#endif

		/* Process full block  */
		SHA512_ProcessBlock(ctx);
		if ( offsetBits != 0 ) {
			ctx->Numbits = offsetBits;
			memcpy((BYTE *) ctx->Mblock, tbuf+SHA512_BYTEBLOCKLEN, 1);
			}
		else
			ctx->Numbits = 0; 
		buffer += (SHA512_BYTEBLOCKLEN-offsetBytes);
		bitcount -= ((SHA512_BYTEBLOCKLEN-offsetBytes)*8);
		}

	/* Save partial block for subsequent invocation of SHAFinal */
	if ( bitcount ) {
		if ( (ctx->Numbits%8) == 0 ) {
			memcpy((BYTE *) ((BYTE *)ctx->Mblock+(ctx->Numbits/8)), buffer, (bitcount+7)/8);
			ctx->Numbits += bitcount;
			}
		else {
			BYTE	tbuf[SHA512_BYTEBLOCKLEN], tbuf2[SHA512_BYTEBLOCKLEN];
			int		i, offset1, rmdr1, offset2;

			offset1 = ctx->Numbits/8;
			offset2 = bitcount/8;
			rmdr1 = ctx->Numbits%8;
			memset(tbuf, '\0', SHA512_BYTEBLOCKLEN);
			memcpy(tbuf, ctx->Mblock, offset1+1);

			memset(tbuf2, '\0', SHA512_BYTEBLOCKLEN);
			memcpy(tbuf2+offset1, buffer, offset2+1);
			for ( i=0; i<rmdr1; i++ )
				bshr(tbuf2, SHA512_BYTEBLOCKLEN);

			xor(tbuf, tbuf, tbuf2, SHA512_BYTEBLOCKLEN);

			memcpy((BYTE *)ctx->Mblock, tbuf, SHA512_BYTEBLOCKLEN);
			ctx->Numbits += bitcount;
			}
		}

	return 0;
	}


/**********************************************************************/
/*	 SHA512_Final does the hashing of the last block of the message.  */
/*	 It is this routine that does the necessary padding of zeros      */
/*	 and sets the length of the data at the end.                      */
/**********************************************************************/
int SHA512_Final(SHA512_CTX *ctx)
{
	int     i, k, numsub, row, col;
	ULONG   numbits;
	ULONG   padbits=0x80000000L, padbits2=0xFFFFFFFFL;

	
#ifdef LITTLE_ENDIAN
byteReverse64(ctx->Mblock, SHA512_WORD64BLOCKLEN);
#endif

	numbits=ctx->Numbits;
	numsub=(int)numbits/32;
	row = numbits/64;
	col = (numbits/32) % 2;

	/* put in the "1" bit  */
	padbits >>= numbits % 32L;
	padbits2 <<= (31L - (numbits % 32L));
	ctx->Mblock[row][col] |= padbits;
	ctx->Mblock[row][col] &= padbits2;

	if ( !col )
		ctx->Mblock[row][1] = 0x00000000L;

	/* put in the zero bits  */
	for (k=row+1; k<SHA512_WORD64BLOCKLEN; k++) {
		ctx->Mblock[k][0] = 0x00000000L;
		ctx->Mblock[k][1] = 0x00000000L;
		}

	/* If more than 895 data bits in last block, there isn't enough room for
		the 1 bit and size field.  Fill this block out with zeros and Process it.
		Then fill another block with zeros and be ready to insert the length
		field.  */
	if ( row > 13 ) {
		SHA512_ProcessBlock(ctx);
		for (i=0; i<14; i++) {
			ctx->Mblock[i][0] = 0x00000000L;
			ctx->Mblock[i][1] = 0x00000000L;
			}
		}
	
	/*  Put in the length field of the data hashed.  */
	/* increment Message Length counter  */
	if ( (ctx->MsgLen[1][1] + numbits) < ctx->MsgLen[1][1] ) {
		if ( ctx->MsgLen[1][0] == 0xffffffff ) {
			if ( ctx->MsgLen[0][1] == 0xffffffff ) {
				if (ctx->MsgLen[0][0] == 0xffffffff )
					exit(-1);
				ctx->MsgLen[0][0]++;
				}
			ctx->MsgLen[0][1]++;
			}
		ctx->MsgLen[1][0]++;
		}
	ctx->MsgLen[1][1] += numbits;

	ctx->Mblock[14][0] = ctx->MsgLen[0][0];
	ctx->Mblock[14][1] = ctx->MsgLen[0][1];
	ctx->Mblock[15][0] = ctx->MsgLen[1][0];
	ctx->Mblock[15][1] = ctx->MsgLen[1][1];

	SHA512_ProcessBlock(ctx);

	return 0;
	}
