#include "config.h"
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "sha.h"
#include "shadecls.h"
#include "mp.h"
#include "dsa.h"

void Hash(BYTE *msg, int len, HASH *ctx, BYTE **hashval)
{
	int		i;

	switch(ctx->hashlen) {
		case 160:
			SHA1_Init(&(ctx->u_ctx.ctx1));
			SHA1_Update(&(ctx->u_ctx.ctx1), msg, len);
			SHA1_Final(&(ctx->u_ctx.ctx1));
			*hashval = (BYTE *)malloc(SHA1_BYTEHASHLEN);
			bcopy((BYTE *)(ctx->u_ctx.ctx1.H), *hashval, SHA1_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
			c2LH(*hashval, SHA1_BYTEHASHLEN);
			for ( i=0; i<SHA1_ULONGHASHLEN; i++ )
				cLONG2DIGITS((DIGIT *)&((*hashval)[i*4]));
#endif
			break;
		/*  Have to do something special for hashlen=224  */
		case 224:
		case 256:
			SHA256_Init(&(ctx->u_ctx.ctx256));
			SHA256_Update(&(ctx->u_ctx.ctx256), msg, len);
			SHA256_Final(&(ctx->u_ctx.ctx256));
			*hashval = (BYTE *)malloc(SHA256_BYTEHASHLEN);
			bcopy((BYTE *)(ctx->u_ctx.ctx256.H), *hashval, SHA256_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
			c2LH(*hashval, SHA256_BYTEHASHLEN);
			for ( i=0; i<SHA256_ULONGHASHLEN; i++ )
				cLONG2DIGITS((DIGIT *)&((*hashval)[i*4]));
#endif
			break;
		case 384:
			SHA384_Init(&(ctx->u_ctx.ctx384));
			SHA384_Update(&(ctx->u_ctx.ctx384), msg, len);
			SHA384_Final(&(ctx->u_ctx.ctx384));
			*hashval = (BYTE *)malloc(SHA384_BYTEHASHLEN);
			bcopy((BYTE *)(ctx->u_ctx.ctx384.H), *hashval, SHA384_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
			c2LH(*hashval, SHA384_BYTEHASHLEN);
			for ( i=0; i<SHA384_WORD64HASHLEN*2; i++ )
				cLONG2DIGITS((DIGIT *)&((*hashval)[i*4]));
#endif
			break;
		case 512:
			SHA512_Init(&(ctx->u_ctx.ctx512));
			SHA512_Update(&(ctx->u_ctx.ctx512), msg, len);
			SHA512_Final(&(ctx->u_ctx.ctx512));
			*hashval = (BYTE *)malloc(SHA512_BYTEHASHLEN);
			bcopy((BYTE *)(ctx->u_ctx.ctx512.H), *hashval, SHA512_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
			c2LH(*hashval, SHA512_BYTEHASHLEN);
			for ( i=0; i<SHA512_WORD64HASHLEN*2; i++ )
				cLONG2DIGITS((DIGIT *)&((*hashval)[i*4]));
#endif
			break;
	}
}

int SHA_Test()
{
	HASH	hash;
	BYTE	*hashval;
	BYTE	msg[128];

	// SHA-1 a 448 bit message
	strcpy(msg, "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq");
	hash.hashlen = 160;
	hashval = NULL;
	Hash(msg, 448, &hash, &hashval);

	if ( (hashval[0] != 0x84) || (hashval[1] != 0x98) ||
		 (hashval[2] != 0x3e) || (hashval[3] != 0x44) ||
		 (hashval[4] != 0x1c) || (hashval[5] != 0x3b) ||
		 (hashval[6] != 0xd2) || (hashval[7] != 0x6e) ||
		 (hashval[8] != 0xba) || (hashval[9] != 0xae) ||
		 (hashval[10] != 0x4a) || (hashval[11] != 0xa1) ||
		 (hashval[12] != 0xf9) || (hashval[13] != 0x51) ||
		 (hashval[14] != 0x29) || (hashval[15] != 0xe5) ||
		 (hashval[16] != 0xe5) || (hashval[17] != 0x46) ||
		 (hashval[18] != 0x70) || (hashval[19] != 0xf1)	)
		return 1;
	FREE(hashval);

	// SHA-256 a 448 bit message
	strcpy(msg, "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq");
	hash.hashlen = 256;
	Hash(msg, 448, &hash, &hashval);

	if ( (hashval[0] != 0x24) || (hashval[1] != 0x8d) ||
		 (hashval[2] != 0x6a) || (hashval[3] != 0x61) ||
		 (hashval[4] != 0xd2) || (hashval[5] != 0x06) ||
		 (hashval[6] != 0x38) || (hashval[7] != 0xb8) ||
		 (hashval[8] != 0xe5) || (hashval[9] != 0xc0) ||
		 (hashval[10] != 0x26) || (hashval[11] != 0x93) ||
		 (hashval[12] != 0x0c) || (hashval[13] != 0x3e) ||
		 (hashval[14] != 0x60) || (hashval[15] != 0x39) ||
		 (hashval[16] != 0xa3) || (hashval[17] != 0x3c) ||
		 (hashval[18] != 0xe4) || (hashval[19] != 0x59) ||
		 (hashval[20] != 0x64) || (hashval[21] != 0xff) ||
		 (hashval[22] != 0x21) || (hashval[23] != 0x67) ||
		 (hashval[24] != 0xf6) || (hashval[25] != 0xec) ||
		 (hashval[26] != 0xed) || (hashval[27] != 0xd4) ||
		 (hashval[28] != 0x19) || (hashval[29] != 0xdb) ||
		 (hashval[30] != 0x06) || (hashval[31] != 0xc1) )
		return 2;
	FREE(hashval);

	// SHA-384 a 896 bit message
	strcpy(msg, "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu");
	hash.hashlen = 384;
	Hash(msg, 896, &hash, &hashval);

	if ( (hashval[0] != 0x09) || (hashval[1] != 0x33) ||
		 (hashval[2] != 0x0c) || (hashval[3] != 0x33) ||
		 (hashval[4] != 0xf7) || (hashval[5] != 0x11) ||
		 (hashval[6] != 0x47) || (hashval[7] != 0xe8) ||
		 (hashval[8] != 0x3d) || (hashval[9] != 0x19) ||
		 (hashval[10] != 0x2f) || (hashval[11] != 0xc7) ||
		 (hashval[12] != 0x82) || (hashval[13] != 0xcd) ||
		 (hashval[14] != 0x1b) || (hashval[15] != 0x47) ||
		 (hashval[16] != 0x53) || (hashval[17] != 0x11) ||
		 (hashval[18] != 0x1b) || (hashval[19] != 0x17) ||
		 (hashval[20] != 0x3b) || (hashval[21] != 0x3b) ||
		 (hashval[22] != 0x05) || (hashval[23] != 0xd2) ||
		 (hashval[24] != 0x2f) || (hashval[25] != 0xa0) ||
		 (hashval[26] != 0x80) || (hashval[27] != 0x86) ||
		 (hashval[28] != 0xe3) || (hashval[29] != 0xb0) ||
		 (hashval[30] != 0xf7) || (hashval[31] != 0x12) ||
		 (hashval[32] != 0xfc) || (hashval[33] != 0xc7) ||
		 (hashval[34] != 0xc7) || (hashval[35] != 0x1a) ||
		 (hashval[36] != 0x55) || (hashval[37] != 0x7e) ||
		 (hashval[38] != 0x2d) || (hashval[39] != 0xb9) ||
		 (hashval[40] != 0x66) || (hashval[41] != 0xc3) ||
		 (hashval[42] != 0xe9) || (hashval[43] != 0xfa) ||
		 (hashval[44] != 0x91) || (hashval[45] != 0x74) ||
		 (hashval[46] != 0x60) || (hashval[47] != 0x39) )
		return 3;
	FREE(hashval);

	// SHA-512 a 896 bit message
	strcpy(msg, "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu");
	hash.hashlen = 512;
	Hash(msg, 896, &hash, &hashval);

	if ( (hashval[0] != 0x8e) || (hashval[1] != 0x95) ||
		 (hashval[2] != 0x9b) || (hashval[3] != 0x75) ||
		 (hashval[4] != 0xda) || (hashval[5] != 0xe3) ||
		 (hashval[6] != 0x13) || (hashval[7] != 0xda) ||
		 (hashval[8] != 0x8c) || (hashval[9] != 0xf4) ||
		 (hashval[10] != 0xf7) || (hashval[11] != 0x28) ||
		 (hashval[12] != 0x14) || (hashval[13] != 0xfc) ||
		 (hashval[14] != 0x14) || (hashval[15] != 0x3f) ||
		 (hashval[16] != 0x8f) || (hashval[17] != 0x77) ||
		 (hashval[18] != 0x79) || (hashval[19] != 0xc6) ||
		 (hashval[20] != 0xeb) || (hashval[21] != 0x9f) ||
		 (hashval[22] != 0x7f) || (hashval[23] != 0xa1) ||
		 (hashval[24] != 0x72) || (hashval[25] != 0x99) ||
		 (hashval[26] != 0xae) || (hashval[27] != 0xad) ||
		 (hashval[28] != 0xb6) || (hashval[29] != 0x88) ||
		 (hashval[30] != 0x90) || (hashval[31] != 0x18) ||
		 (hashval[32] != 0x50) || (hashval[33] != 0x1d) ||
		 (hashval[34] != 0x28) || (hashval[35] != 0x9e) ||
		 (hashval[36] != 0x49) || (hashval[37] != 0x00) ||
		 (hashval[38] != 0xf7) || (hashval[39] != 0xe4) ||
		 (hashval[40] != 0x33) || (hashval[41] != 0x1b) ||
		 (hashval[42] != 0x99) || (hashval[43] != 0xde) ||
		 (hashval[44] != 0xc4) || (hashval[45] != 0xb5) ||
		 (hashval[46] != 0x43) || (hashval[47] != 0x3a) ||
		 (hashval[48] != 0xc7) || (hashval[49] != 0xd3) ||
		 (hashval[50] != 0x29) || (hashval[51] != 0xee) ||
		 (hashval[52] != 0xb6) || (hashval[53] != 0xdd) ||
		 (hashval[54] != 0x26) || (hashval[55] != 0x54) ||
		 (hashval[56] != 0x5e) || (hashval[57] != 0x96) ||
		 (hashval[58] != 0xe5) || (hashval[59] != 0x5b) ||
		 (hashval[60] != 0x87) || (hashval[61] != 0x4b) ||
		 (hashval[62] != 0xe9) || (hashval[63] != 0x09) )
		return 4;
	FREE(hashval);

	return 0;
}