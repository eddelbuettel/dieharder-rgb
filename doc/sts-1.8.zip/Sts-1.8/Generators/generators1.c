#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "config.h"
#include "utilities1.h"
#include "utilities2.h"
#include "generators1.h"
#include "lip.h"
#include "mp.h"

double lcg_rand(int N, double SEED, double* DUNIF, int NDIM)
{
	int    i;
	double DZ,DOVER,DZ1,DZ2,DOVER1,DOVER2;
	double DTWO31,DMDLS,DA1,DA2;

	DTWO31 = 2147483648.0; /* DTWO31=2**31  */
	DMDLS  = 2147483647.0; /* DMDLS=2**31-1 */
	DA1 = 41160.0;       /* DA1=950706376 MOD 2**16 */
	DA2 = 950665216.0;   /* DA2=950706376-DA1 */

	DZ = SEED;
	if ( N > NDIM )
		N = NDIM;
	for( i=1; i<=N; i++ ) {
		DZ = floor(DZ);
		DZ1 = DZ*DA1;
		DZ2 = DZ*DA2;
		DOVER1 = floor(DZ1/DTWO31);
		DOVER2 = floor(DZ2/DTWO31);
		DZ1 = DZ1-DOVER1*DTWO31;
		DZ2 = DZ2-DOVER2*DTWO31;
		DZ = DZ1+DZ2+DOVER1+DOVER2;
		DOVER = floor(DZ/DMDLS);
		DZ = DZ-DOVER*DMDLS;
		DUNIF[i-1] = DZ/DMDLS;
		SEED = DZ;
	}

	return SEED;
}

/*
  Author:  Pate Williams (c) 1997

  The following program implements and tests the
  Blum-Blum-Shub random bits generator. The test
  suite is according to FIPS 140-1. See "Handbook
  of Applied Cryptography" by Alfred J. Menezes
  et al Section 5.4.4 pages 181 - 183 and 5.40
  Algorithm page 186.
*/

void bbs_gen_key(long bit_length, verylong *zn, verylong *zx0)
/* generates the key and seed for the Blum-Blum-Shub
   random bits generator */
{
  long length = bit_length / 2;
  verylong zp = 0, zq = 0, zs = 0;

  zrstarts(time(NULL));
  zrandomprime(- length, 5l, &zp, zrandomb);
  zrandomprime(- length, 5l, &zq, zrandomb);
  zmul(zp, zq, zn);
  do zrandomb(*zn, &zs); while (zscompare(zs, 0l) == 0);
  zmulmod(zs, zs, *zn, zx0);
  zfree(&zp);
  zfree(&zq);
  zfree(&zs);
}

/* gets number low order bits of x * x mod n */
long bbs_next_bits(long number, verylong zn, verylong *zx)
{
	long low_bits;

	verylong zx0 = 0;

	zcopy(*zx, &zx0);
	zmulmod(zx0, zx0, zn, zx);
	zlowbits(*zx, number, &zx0);
	low_bits = zx0[1];
	zfree(&zx0);

	return low_bits;
}

/*
  Author:  Pate Williams (c) 1997

  The following program implements and tests the
  Micali-Schnorr random bits generator. The test
  suite is according to FIPS 140-1. See "Handbook
  of Applied Cryptography" by Alfred J. Menezes
  et al Section 5.4.4 pages 181 - 183 and 5.37
  Algorithm page 186.
*/

/* generates the key and seed for the Micali-Schnorr
   pseudorandom bits generator */
void Micali_Schnorr_gen_key(long bit_length, verylong *ze,
                            verylong *zn, verylong *zx0,
                            long *k, long *r)
{
	long		length = bit_length / 2, N;
	verylong	zd = 0, zp = 0, zq = 0, zs = 0, zt = 0;
	verylong	zphi = 0;

	zrstarts(time(NULL));
	zrandomprime(length, 5l, &zp, zrandomb);
	zrandomprime(length, 5l, &zq, zrandomb);
	zmul(zp, zq, zn);
	zsadd(zp, - 1l, &zs);
	zsadd(zq, - 1l, &zt);
	zmul(zs, zt, &zphi);
	N = z2log(*zn);
	zpstart();
	do {
		zintoz(zpnext(), ze);
		zgcd(*ze, zphi, &zd);
		zsmul(*ze, 80l, &zs);
		} while ( (zscompare(zd, 1l) != 0) && (zscompare(zs, N) > 0) );
	*k = (long)(N * (1.0 - 2 / (double) ztoint(*ze)));
	*r = N - *k;
	zrandomprime(*r, 5l, zx0, zrandomb);
	zfree(&zd);
	zfree(&zp);
	zfree(&zq);
	zfree(&zs);
	zfree(&zt);
	zfree(&zphi);
}

void Micali_Schnorr_next_bits(long k, long r, verylong ze,
                              verylong zn, verylong *zx,
                              verylong *zz)
/* gets the next bits in the sequence */
{
	verylong	zx0 = 0, zy = 0;

	zcopy(*zx, &zx0);
	zexpmod(zx0, ze, zn, &zy);
	zhighbits(zy, r, zx);
	zlowbits(zy, k, zz);
	zfree(&zx0);
	zfree(&zy);
}
