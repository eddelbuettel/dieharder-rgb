
/*  These Random Number Generators (RNGs) are not necessarily accurate
    implementations of various RNGs from various standards.  They are
	here for experimental purpose with the Statistical Test Suite only. */


#include "Rng.h"

/****************************************************************************
 * shaG()                                                                   *
 *                                                                          *
 *  This is the implementation of the G-function based on a subset          *
 *  of SHA steps as defined in Appendix 3.3.                                *
 *                                                                          *
 *  INPUTS:                                                                 *
 *      tval:    Points to initial hash array (IH) to initialize SHA        *
 *                                                                          *
 *      b:       Length of c in bits <= 512                                 *
 *                                                                          *
 *      C:       160-512 bit SEED.                                          *
 *                                                                          *
 *      hashlen: selects the hash algorithm to use.                         *
 *                                                                          *
 *  OUTPUTS:                                                                *
 *      G:  160-bit return value                                            *
 ****************************************************************************/
void shaG(BYTE *tval, BYTE *C, int b, BYTE **G, int hashlen)
{
	BYTE	*M1;
	HASH	ctx;
	int		i, CBytes;

	ctx.hashlen = hashlen;
	CBytes = (b+7)/8;
	switch (hashlen) {
	case 160:
		M1 = (BYTE *)calloc(SHA1_BYTEBLOCKLEN, 1);
		bcopy(C, M1, CBytes);
		SHA1_Init2 (&(ctx.u_ctx.ctx1), (ULONG *)tval);
		SHA1_Update (&(ctx.u_ctx.ctx1), M1, SHA1_BLOCKLEN);
		*G = (BYTE *)malloc(SHA1_BYTEHASHLEN);
		bcopy((BYTE *)ctx.u_ctx.ctx1.H, *G, SHA1_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
		c2LH(*G, SHA1_BYTEHASHLEN);
		for ( i=0; i<SHA1_ULONGHASHLEN; i++ )
			cLONG2DIGITS((DIGIT *)&((*G)[i*4]));
#endif
		break;
	case 224:
	case 256:
		M1 = (BYTE *)calloc(SHA256_BYTEBLOCKLEN, 1);
		bcopy(C, M1, CBytes);
		SHA256_Init2 (&(ctx.u_ctx.ctx256), (ULONG *)tval);
		SHA256_Update (&(ctx.u_ctx.ctx256), M1, SHA256_BLOCKLEN);
		*G = (BYTE *)malloc(SHA256_BYTEHASHLEN);
		bcopy((BYTE *)ctx.u_ctx.ctx256.H, *G, SHA256_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
		c2LH(*G, SHA256_BYTEHASHLEN);
		for ( i=0; i<SHA256_ULONGHASHLEN; i++ )
			cLONG2DIGITS((DIGIT *)&((*G)[i*4]));
#endif
		break;
	case 384:
		M1 = (BYTE *)calloc(SHA384_BYTEBLOCKLEN, 1);
		bcopy(C, M1, CBytes);
		SHA384_Init2 (&(ctx.u_ctx.ctx384), (WORD64 *)tval);
		SHA384_Update (&(ctx.u_ctx.ctx384), M1, SHA384_BLOCKLEN);
		*G = (BYTE *)malloc(SHA384_BYTEHASHLEN);
		bcopy((BYTE *)ctx.u_ctx.ctx384.H, *G, SHA384_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
		c2LH(*G, SHA384_BYTEHASHLEN);
		for ( i=0; i<SHA384_ULONGHASHLEN; i++ )
			cLONG2DIGITS((DIGIT *)&((*G)[i*4]));
#endif
		break;
	case 512:
		M1 = (BYTE *)calloc(SHA512_BYTEBLOCKLEN, 1);
		bcopy(C, M1, CBytes);
		SHA512_Init2 (&(ctx.u_ctx.ctx512), (WORD64 *)tval);
		SHA512_Update (&(ctx.u_ctx.ctx512), M1, SHA512_BLOCKLEN);
		*G = (BYTE *)malloc(SHA512_BYTEHASHLEN);
		bcopy((BYTE *)ctx.u_ctx.ctx256.H, *G, SHA512_BYTEHASHLEN);
#ifdef LITTLE_ENDIAN
		c2LH(*G, SHA512_BYTEHASHLEN);
		for ( i=0; i<SHA512_ULONGHASHLEN; i++ )
			cLONG2DIGITS((DIGIT *)&((*G)[i*4]));
#endif
		break;
	}

	free(M1);
}

/*********************************************************
 * desG:                                                 *
 *        NOTE: t and c are assumed to be 160 bits long  *
 *********************************************************/
void desG(BYTE *t, BYTE *c, BYTE *G)
{
	BYTE	x[20], y[40], a1[4], a2[4], b1[4], b2[4], tmp[4];
	BYTE	A[8];
	BYTE	K56[7], K64[8];
	int		i;
	TDESCTX context;

#ifdef LITTLE_ENDIAN
	c2LH(t, SHA1_BYTEHASHLEN);
	for ( i=0; i<SHA1_ULONGHASHLEN; i++ )
		cLONG2DIGITS((DIGIT *)&((t)[i*4]));
#endif

	for ( i=0; i<20; i++ )		/* Step 2 of the Appendix */
		x[i] = t[i] ^ c[i];

	for ( i=0; i<5; i++ )  {	/* Step 3 of the Appendix */
		bcopy(c+((i+4)%5)*4, b1, 4);
		bcopy(c+((i+3)%5)*4, b2, 4);
		bcopy(x+i*4, a1, 4);
		xor(a2, x+((i+1)%5)*4, x+((i+4)%5)*4, 4);
		bcopy(a1, A, 4);
		bcopy(a2, A+4, 4);

		bcopy(b1+1, K56, 3);
		bcopy(b2, K56+3, 4);
		key56to64(K56, K64);

		//K[0] = 0x10; K[1] = 0x31; K[2] = 0x6e; K[3] = 0x02;
		//K[4] = 0x8c; K[5] = 0x8f; K[6] = 0x3b; K[7] = 0x4a;
		TDESInit (&context, K64, K64, K64, NULL, TDES_ECB, DES_ENCIPHER);

		//setkey(IGNOREPARITY, ENCRYPT, K, ks);

		//A[0] = 0x00; A[1] = 0x00; A[2] = 0x00; A[3] = 0x00;
		//A[4] = 0x00; A[5] = 0x00; A[6] = 0x00; A[7] = 0x00;
		TDES(&context, A, A, NULL);
		//des(A, A, ks);				/* Replace A with encrypted A */

		bcopy(A, &(y[i*8]), 8);
	}

	for (i=0; i<5; i++) {			/* Complete step 4 and store */
		xor(tmp, &(y[i*8]), &(y[((i+2)%5)*8+4]), 4);
		xor(G+i*4, tmp, &(y[((i+3)%5)*8]), 4);
	}
#ifdef LITTLE_ENDIAN
	c2LH(t, SHA1_BYTEHASHLEN);
	for ( i=0; i<SHA1_ULONGHASHLEN; i++ )
		cLONG2DIGITS((DIGIT *)&((t)[i*4]));
#endif
}


/***************/
/*  ANSI X9.31 */
/***************/
void ANSIX931Init(TDESCTX *context, BYTE *Key1, BYTE *Key2)
{
	BYTE	Key3[8];

	bcopy(Key1, Key3, 8);
	TDESInit (context, Key1, Key2, Key3, NULL, TDES_ECB, DES_ENCIPHER);
}

void ANSIX931GenR(TDESCTX *context, BYTE *V, BYTE *DT, BYTE *R)
{
	BYTE	I[8], I2[8];
	int		i;

	TDES_Core(context, DT, I);
	for ( i=0; i<8; i++ )
		I2[i] = I[i] ^ V[i];

	TDES_Core(context, I2, R);

	for ( i=0; i<8; i++ )
		I2[i] = R[i] ^ I[i];

	TDES_Core(context, I2, V);

	for ( i=7; i>=0; i-- ) {
		if ( DT[i] == 0xff )
			DT[i] = 0;
		else {
			DT[i]++;
			break;
		}
	}
}


int init_Hash_DRBG(Hash_DRBG_CTX *ctx, int req_sec_level, int hash_len)
{
	int		sec_level;
	BYTE	*entropy_data, *ptr, *tmp;
	int		i;
	HASH	hash_ctx;

	entropy_data = ptr = NULL;
	switch (hash_len) {
	case 160:
		if ( req_sec_level > 128 )
			return BAD_SEC_LEVEL;
		break;
	case 224:
		if ( req_sec_level > 192 )
			return BAD_SEC_LEVEL;
		break;
	case 256:
	case 384:
	case 512:
		if ( req_sec_level > 256 )
			return BAD_SEC_LEVEL;
		break;
	default:
		return BAD_HASH_LEN;
	}
	ctx->hash_len = hash_len;

	if ( req_sec_level > 192 )
		sec_level = 256;
	else if ( req_sec_level > 128 )
		sec_level  = 192;
	else if ( req_sec_level > 112 )
		sec_level  = 128;
	else
		sec_level  = 112;

	ctx->strength = sec_level;
	ctx->min_entropy = sec_level + 64;
	entropy_data = (BYTE *)calloc(ctx->min_entropy, 1);
	
	switch(ctx->hash_len) {
	case 160:
	case 224:
	case 256:
		ctx->seedlen = 440;
		break;
	case 384:
	case 512:
		ctx->seedlen = 952;
		break;
	}

	srand( (unsigned)time( NULL ) );
	for ( i=0; i<ctx->min_entropy/8; i++ )
		entropy_data[i] = rand();

	//  Set up V
	ptr = Hash_df(ctx, entropy_data, ctx->min_entropy/8, ctx->seedlen);
	ctx->V = (BYTE *)calloc(ctx->seedlen/8, 1);
	memcpy(ctx->V, ptr, ctx->seedlen/8);
	if ( entropy_data )
		free(entropy_data);
	if ( ptr )
		free(ptr);

	// Set up C
	tmp = (BYTE *)calloc(ctx->seedlen/8 + 1, 1);
	memcpy(tmp+1, ctx->V, ctx->seedlen/8);
	hash_ctx.hashlen = ctx->hash_len;
	Hash(tmp, ctx->seedlen/8 + 1, &hash_ctx, &ptr);
	ctx->C = (BYTE *)calloc(ctx->hash_len/8, 1);
	memcpy(ctx->C, ptr, ctx->hash_len/8);
	if ( tmp )
		free(tmp);
	if ( ptr )
		free(ptr);

	ctx->reseed_counter = (BYTE *)calloc(ctx->seedlen/8, 1);
	memset(ctx->reseed_counter, 0x00, ctx->seedlen/8);

	return 0;
}

BYTE *Hash_df(Hash_DRBG_CTX *ctx, BYTE *in_data, int in_data_len, int num_bits)
{
	HASH	hash_ctx;
	BYTE	*tmp, *tmp2, *tmp3;
	int		i, len;

	if ( num_bits > (255 * ctx->hash_len) )
		return NULL;

	len = (num_bits + ctx->hash_len - 1) / ctx->hash_len;
	tmp = (BYTE *)malloc(len*ctx->hash_len/8);

	tmp2 = (BYTE *)malloc(in_data_len+5);
	for ( i=0; i<len; i++ ) {
		tmp2[0] = i;
		memcpy(&(tmp2[1]), &num_bits, 4);
		memcpy(&(tmp2[5]), in_data, in_data_len);

		hash_ctx.hashlen = ctx->hash_len;
		Hash(tmp2, (in_data_len+5)*8, &hash_ctx, &tmp3);
		memcpy(tmp+i*ctx->hash_len/8, tmp3, ctx->hash_len/8);
		if ( tmp3 )
			free(tmp3);
	}
	if ( tmp2 )
		free(tmp2);

	return tmp;
}

int Hash_DRBG(Hash_DRBG_CTX *ctx, int num_bits_requested, int req_sec_level,
			  BYTE **rnd_val)
{
	HASH	hash;
	BYTE	*hashval;
	BYTE	*H, *Tmp, One[1];
	
	/* reseedCounter = 1; */
	One[0] = 0x01;
	
	hash.hashlen = ctx->hash_len;
	hashval = NULL;

	Hashgen(&hash, ctx->V, ctx->seedlen, rnd_val, num_bits_requested);

	// precede V with a byte of three
	Tmp = (BYTE *)calloc(ctx->seedlen/8 + 1, 1);
	Tmp[0] = 0x03;
	memcpy(Tmp+1, ctx->V, ctx->seedlen/8);
	Hash(Tmp, ctx->seedlen/8 + 1, &hash, &H);
	

	add(ctx->V, ctx->seedlen/8, H, ctx->hash_len/8);
	add(ctx->V, ctx->seedlen/8, ctx->C, ctx->hash_len/8);
	add(ctx->V, ctx->seedlen/8, ctx->reseed_counter, ctx->seedlen/8);

	// reseed_counter++
	add(ctx->reseed_counter, ctx->seedlen/8, One, 1);

	return 1;

}

void Hashgen(HASH *hash, BYTE *V, int seedlen, BYTE **pseudorandomBits, int numOfBits)
{
	BYTE	*data, *wTemp, One[1];
	int		i, m, bitlen;

	bitlen = hash->hashlen;
	m = (numOfBits + bitlen-1) / bitlen;
	data = V;
	One[0] = 0x01;

	*pseudorandomBits = (BYTE *)malloc(m*bitlen/8);
	wTemp = NULL;
	for( i=0; i<m; i++ ) {

		Hash(data, seedlen, hash, &wTemp);

		bcopy(wTemp, &((*pseudorandomBits)[i*bitlen/8]), bitlen/8);

		add(data, seedlen/8, &One[0], sizeof(One));

		if ( wTemp )
			free(wTemp);
		wTemp = NULL;
	}
}