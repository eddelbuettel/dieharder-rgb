#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "config.h"
#include "generators1.h"
#include "generators2.h"
#include "generators3.h"
#include "utilities2.h"
#include "utilities1.h"
#include "mp.h"

/* function declarations from generator3.h */

void modExp()
{
  /* int i, j, l, bit;
     FILE* fp;
     char  filename[100];
     unsigned long A, C, displayMask = 1 << 31;
  */

  int            k, n0, n1, counter, bitsRead, length, done;
  BYTE           *p, *g, *x, *y, *T;
 
  length = (int)floor(tp.n/512);
  if ((tp.n)%512!= 0) length++;
  if (((epsilon = (BitField*)calloc(tp.n, sizeof(BitField))) == NULL) ||
      ((p = (BYTE*)calloc(MAXPLEN, sizeof(BYTE))) == NULL) ||
      ((g = (BYTE*)calloc(MAXPLEN, sizeof(BYTE))) == NULL) ||
      ((x = (BYTE*)calloc(2*MAXPLEN, sizeof(BYTE))) == NULL) ||
      ((T = (BYTE*) calloc(8, sizeof(BYTE))) == NULL) ||
      ((y = (BYTE*)calloc(MAXPLEN, sizeof(BYTE))) == NULL)) { 
     fprintf(output, "\t\tInsufficient Working Space Allocated in modExp()\n");
  }
  else {
     /*fp = fopen("modexp.data","wb"); */
     bzero(y,MAXPLEN);
     bzero(p,MAXPLEN);
     bzero(g,MAXPLEN);
     /*
     ahtopb("7AB36982CE1ADF832019CDFEB2393CABDF0214EC", y, 20);
     ahtopb("987b6a6bf2c56a97291c445409920032499f9ee7ad128301b5d0254aa1a9633fdbd378d40149f1e23a13849f3d45992f5c4c6b7104099bc301f6005f9d8115e1", p, 64);
     ahtopb("3844506a9456c564b8b8538e0cc15aff46c95e69600f084f0657c2401b3c244734b62ea9bb95be4923b9b7e84eeaf1a224894ef0328d44bc3eb3e983644da3f5", g, 64);
     */
     ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", y, 20);
     ahtopb("8a21a3c5a1953e30c99ac30cec5adaecee15f0d21f6d9f84b90a48b04eed5e7b814a6f57272c39beb738c65b9bf9528539d4300d9cec0b713c2c5f6cb5c78679", p, 64);
     ahtopb("10d6333cfac8e30e808d2192f7c0439480da79db9bbca1667d73be9a677ed31311f3b830937763837cb7b1b1dc75f14eea417f84d9625628750de99e7ef1e976", g, 64);
/*
     printnum("\nPrime p = ",p,64);
     printnum("\n\nPrime y = ",y,20);
     printnum("\n\nPrime g = ",g,64);
*/
     n0 = 0;
     n1 = 0;
     bitsRead = 0;
     done = 0;
     counter = 1;
     /*fp = fopen("modexp1.data","wb");*/
     for(k = 0; k < tp.numOfBitStreams*length; k++) {
        bzero(x,2*MAXPLEN);
        ModExp(x, g, 64, y, 20, p, 64);	      /* NOTE:  g must be less than p */
        /* printnum("\n\nParam X = ",x,64); */
        /*fwrite(x,sizeof(BYTE),64,fp);*/
        /*printnum("\nParam X = ",x,64);*/
        done = convertToBits(x,tp.n,&n0,&n1,&bitsRead,0,16);
        /*fflush(fp);*/
        bzero(y,MAXPLEN);
        mbcopy(x+44,y,20);
        /*printnum("\nParam y = ",y,20);*/
	if (done) {
           /*
           fclose(fp);
           counter++;
	   if (k+1 < tp.numOfBitStreams*length) {
   	      sprintf(filename, "modexp%d.data", counter);
              fp = fopen(filename,"wb");
           }
           */
           fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
	   fflush(output);
           nist_test_suite();
           n0 = 0;
           n1 = 0;
           done = 0;
           bitsRead = 0;
        }
     }
     /*fclose(fp);*/
     free(p);
     free(g);
     free(x);
     free(y);
     free(T);
     free(epsilon);
  }
  return;
}

void quadRes1()
{
  /* 
  FILE* fp;
  char  filename[100];
  int   i, j, bit;
  unsigned long  c, displayMask = 1 << 31;
  unsigned long A;
  */

  int   k, n0, n1, counter, bitsRead, length, done;
  BYTE  *p, *g, *x, *T;

/*
  ahtopb("7844506a9456c564b8b8538e0cc15aff46c95e69600f084f0657c2401b3c244734b62ea9bb95be4923b9b7e84eeaf1a224894ef0328d44bc3eb3e983644da3f5", g, 64);
  ahtopb("a844506a9456c564b8b8538e0cc15aff46c95e69600f084f0657c2401b3c244734b62ea9bb95be4923b9b7e84eeaf1a224894ef0328d44bc3eb3e983644da3f5", g, 64);
*/
  if (((epsilon = (BitField*)calloc(tp.n,sizeof(BitField))) == NULL) ||
      ((p = (BYTE*) calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
      ((g = (BYTE*) calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
      ((T = (BYTE*) calloc(8,sizeof(BYTE))) == NULL) ||
      ((x = (BYTE*) calloc(MAXPLEN,sizeof(BYTE))) == NULL)) {
     fprintf(output,"\t\tInsufficient Working Space Allocated in quadRes1()\n");
  }
  else {
     length = (int)floor(tp.n/512);
     if ((tp.n)%512 != 0) length++;
     bzero(p,MAXPLEN);
     bzero(g,MAXPLEN);
     ahtopb("987b6a6bf2c56a97291c445409920032499f9ee7ad128301b5d0254aa1a9633fdbd378d40149f1e23a13849f3d45992f5c4c6b7104099bc301f6005f9d8115e1", p, 64);
     ahtopb("42985722352572398592585235972389598235232283798723ab348d4582c9384d384c23483489acbdb234b2234bacb35b2a45252c384238448275ac34234933", g, 64);
     /*mbcopy(g,x+64,64);*/
     /*printnum("\nX_{1} (SEED) = ",x+64,64);*/
     n0 = 0;
     n1 = 0;
     done = 0;
     bitsRead = 0;
     counter = 1;
     /*fp = fopen("quadres1.data","wb");*/
     /*fwrite(g,sizeof(BYTE),64,fp);*/
     for(k = 0; k < tp.numOfBitStreams*length; k++) {
        bzero(x,MAXPLEN);
        ModMult(x, g, 64, g, 64, p,64);
        /*printnum("\nX_{i+1} = ",x,MAXPLEN);*/
        /*fwrite(x+64,sizeof(BYTE),64,fp);*/
        done = convertToBits(x,tp.n,&n0,&n1,&bitsRead,64,16);
        bzero(g,MAXPLEN);
        mbcopy(x+64,g,64);
        /*printnum("\nX_i = ",g,64);*/
	if (done) {
           /*
           fclose(fp);
           counter++;
	   if (k+1 < tp.numOfBitStreams*length) {
   	      sprintf(filename, "quadres%d.data", counter);
              fp = fopen(filename,"wb");
           }
           */
           fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
	   fflush(output);
           nist_test_suite();
           n0 = 0;
           n1 = 0;
           done = 0;
           bitsRead = 0;
        }
     }
     /* fclose(fp); */
     free(p);
     free(g);
     free(x);
     free(T);
     free(epsilon);
  }
  return;
}

void exclusiveOR()
{
#ifdef CRYPTX
  int j, k;
  char  filename[100];
  FILE* fp;
  unsigned long sum;
#endif

  int   i, n0, n1, counter, bitsRead, done, fileCounter;
  char* bit_sequence;

  if (((epsilon = (BitField*)calloc(tp.n,sizeof(BitField))) == NULL) ||
      ((bit_sequence = (char*)calloc(128,sizeof(char))) == NULL)) {
     fprintf(output,
             "\t\tInsufficient Working Space Allocated in exclusiveOR()\n");
  }
  else {
     strcpy(bit_sequence,"0001011011011001000101111001001010011011101101000100000010101111111010100100001010110110000000000100110000101110011111111100111");
     n0 = 0;
     n1 = 0;
     bitsRead = 0;
     /*fp = fopen("xor1.data","w");*/
     for(i = 0; i < 127; i++) {
        /*fprintf(fp,"%c", bit_sequence[i]);*/
        if (bit_sequence[i] == '0') {
           epsilon[bitsRead].b = 0;
           n0++;
        }
        else {
           epsilon[bitsRead].b = 1;
           n1++;
        }
        bitsRead++;
        /*if (i==80) fprintf(fp,"\n");*/
     }
     fileCounter = 1;
     counter = 0;
     done = 0;
     for(i = 127; i < tp.n*tp.numOfBitStreams; i++) {
        if (bit_sequence[(i-1)%127] != bit_sequence[(i-127)%127]) {
       	   /*bit_sequence[i] = '1';*/
       	   bit_sequence[i%127] = '1';
           epsilon[bitsRead].b = 1;
           n1++;
        }
        else {
   	   /*bit_sequence[i] = '0';*/
   	   bit_sequence[i%127] = '0';
           epsilon[bitsRead].b = 0;
           n0++;
        }
        bitsRead++;
        counter++;
        /*fprintf(fp,"%c",bit_sequence[i]);*/
        /*
        if (counter%80 ==0) {
           fprintf(fp,"\n");
   	   counter = 0;
        }
        */
        if (bitsRead == tp.n) done = 1;
	if (done) {
#ifdef CRYPTX
           for(j = 0; j < (int)floor(tp.n/32); j++) {
              sum = 0;
              for(k = 0; k < 32; k++) {
                 sum += pow(2,31-k)*epsilon[32*j+k].b;
                 /*printf("%d", epsilon[32*j+k].b);*/
              }
              /*printf("sum = %16d = %08x\n", sum, sum);*/
              fwrite((void*)&sum,sizeof(unsigned long),(size_t)1,fp);
           }
#endif
           fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
	   fflush(output);
           nist_test_suite();
#ifdef CRYPTX
           fileCounter++;
           if (fileCounter-1 < tp.numOfBitStreams) {
              fclose(fp);
              sprintf(filename, "xor%d.data", fileCounter);
              fp = fopen(filename,"wb");
	      if (fp == NULL)
	      {
		 printf("File %s could not be opened. Exiting program.\n", filename);
		 exit(-1);
	      }
           }
#endif
           n0 = 0;
           n1 = 0;
           done = 0;
           bitsRead = 0;
        }
     }
     /*fclose(fp);*/
     free(bit_sequence);
     free(epsilon);
  }
  return;
}

void quadRes2()
{
/* 
  FILE* fp;
  char  filename[100];
  int i, j, bit;
  unsigned long  ch, displayMask = 1 << 31;
  unsigned long A;
*/

  BYTE  *g, *x, *t1, *t2;
  BYTE  *a, *b, *c, *T;
  int    k, n0, n1, counter, bitsRead, length, done;

  if (((epsilon = (BitField*)calloc(tp.n,sizeof(BitField))) == NULL) ||
      ((a = (BYTE*)calloc(2,sizeof(BYTE))) == NULL) ||
      ((b = (BYTE*)calloc(2,sizeof(BYTE))) == NULL) ||
      ((c = (BYTE*)calloc(2,sizeof(BYTE))) == NULL) ||
      ((t1 = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
      ((t2 = (BYTE*)calloc(2*MAXPLEN,sizeof(BYTE))) == NULL) ||
      ((g = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
      ((T = (BYTE*) calloc(8,sizeof(BYTE))) == NULL) ||
      ((x = (BYTE*)calloc(3*MAXPLEN,sizeof(BYTE))) == NULL)) {
     fprintf(output,"\t\tInsufficient Working Space Allocated in quadRes2()\n");
  }
  else {
	      /* fp = fopen("quadres1.data","wb"); */

#ifdef LITTLE_ENDIAN
     a[0] = 0x01;
     a[1] = 0x00;
	 b[0] = 0x02;
	 b[1] = 0x00;
	 c[0] = 0x03;
	 c[1] = 0x00;
#else
     a[0] = 0x00;
     a[1] = 0x01;
	 b[0] = 0x00;
	 b[1] = 0x02;
	 c[0] = 0x00;
	 c[1] = 0x03;
#endif

     length = (int)floor(tp.n/512);
     if ((tp.n)%512 != 0) length++;
     ahtopb("7844506a9456c564b8b8538e0cc15aff46c95e69600f084f0657c2401b3c244734b62ea9bb95be4923b9b7e84eeaf1a224894ef0328d44bc3eb3e983644da3f5", g, 64);
	 /* printnum("\nX_{1} (SEED) = ",g,64);*/

     n0 = 0;
     n1 = 0;
     done = 0;
     counter = 1;
     bitsRead = 0;
 
     /* fwrite(g,sizeof(BYTE),64,fp);*/
     for(k = 0; k < tp.numOfBitStreams*length; k++) {
        /* printnum("\nx = ",g,64); */
        Mult(t1,g,64,b,2);			/* 2x */
        /*printnum("\n2x= ",t1,128);*/
		/*fwrite(t1, sizeof(BYTE), 128, fp);*/
        add(t1,66,c,2);				/* 2x+3 */
        /*printnum("\n2x+3= ",t1,128);*/
		/*fwrite(t1, sizeof(BYTE), 128, fp);*/
        Mult(x,t1,128,g,64);			/* x(2x+3) */
        /*printnum("\nx(2x+3)= ",x,2*128);*/
        add(x,128+2,a,2);			/* x(2x+3)+1 */
        /*printnum("\nx(2x+3)+1= ",x,2*128);*/
        /*printnum("\nx(2x+3)+1= ",x+66,64);*/
        /* fwrite(x+66,sizeof(BYTE),64,fp);*/
        /*fflush(fp);*/
        done = convertToBits(x,tp.n,&n0,&n1,&bitsRead,66,16);
        bzero(g,MAXPLEN);
        mbcopy(x+66,g,64);
        /*printnum("\nX_i = ",g,64);*/
        bzero(x,3*MAXPLEN);
        bzero(t1,MAXPLEN);
        bzero(t2,2*MAXPLEN);
	if (done) {
           /* 
           fclose(fp);
           counter++;
	   if (k+1 < tp.numOfBitStreams*length) {
   	      sprintf(filename, "quadres%d.data", counter);
              fp = fopen(filename,"wb");
           }
           */
           fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
	   fflush(output);
           nist_test_suite();
           n0 = 0;
           n1 = 0;
           done = 0;
           bitsRead = 0;
        }
     }
     /* fclose(fp); */
     free(g);
     free(x);
     free(a);
     free(b);
     free(c);
     free(T);
     free(epsilon);
  }
  return;
}

void cubicRes()
{
  /*
  FILE* fp;
  char  filename[100];
  int i, j, bit;
  unsigned long  c, displayMask = 1 << 31;
  unsigned long A;
  */

  BYTE  *g, *x, *t1, *T;
  int    k, n0, n1, counter, bitsRead, length, done;

  if (((epsilon = (BitField*)calloc(tp.n,sizeof(BitField))) == NULL) ||
      ((t1 = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
      ((g = (BYTE*)calloc(MAXPLEN,sizeof(BYTE))) == NULL) ||
      ((T = (BYTE*) calloc(8,sizeof(BYTE))) == NULL) ||
      ((x = (BYTE*)calloc(2*MAXPLEN,sizeof(BYTE))) == NULL)) {
     fprintf(output,"\t\tInsufficient Working Space Allocated in cubicRes()\n");
  }
  else {
     ahtopb("7844506a9456c564b8b8538e0cc15aff46c95e69600f084f0657c2401b3c244734b62ea9bb95be4923b9b7e84eeaf1a224894ef0328d44bc3eb3e983644da3f5", g, 64);
     length = (int)floor(tp.n/512);
     if ((tp.n)%512 != 0) length++;
     n0 = 0;
     n1 = 0;
     done = 0;
     counter = 1;
     bitsRead = 0;
     /*fp = fopen("cuberes1.data","wb");*/
     /*fwrite(g,sizeof(BYTE),64,fp);*/
     for(k = 0; k < tp.numOfBitStreams*length; k++) {
        /*printnum("\nx = ",g,64);*/
        Mult(t1,g,64,g,64);
        /*printnum("\nx^2 = ",t1,128);*/
        Mult(x,t1,128,g,64);
        /*printnum("\nx^3 = ",x,2*128);*/
        /*fwrite(x+128,sizeof(BYTE),64,fp);*/
        done = convertToBits(x,tp.n,&n0,&n1,&bitsRead,128,16);
        /*fflush(fp);*/
        bzero(g,MAXPLEN);
        mbcopy(x+128,g,64);
        /*printnum("\nX_i = ",g,64);*/
        bzero(x,2*MAXPLEN);
        bzero(t1,MAXPLEN);
	if (done) {
           /* 
           fclose(fp);
           counter++;
	   if (k+1 < tp.numOfBitStreams*length) {
   	      sprintf(filename, "cuberes%d.data", counter);
              fp = fopen(filename,"wb");
           }
           */
           fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
	   fflush(output);
           nist_test_suite();
           n0 = 0;
           n1 = 0;
           done = 0;
           bitsRead = 0;
        }
     }
     /*fclose(fp); */
     free(g);
     free(x);
     free(t1);
     free(T);
     free(epsilon);
  }
  return;
}
