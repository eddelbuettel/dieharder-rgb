#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "defs.h"
#include "externs.h"
#include "proto.h"
#include "utilities1.h"
#include "utilities2.h"
#include "generators3.h"
#include "mp.h"
#include "sha.h"
#include "sha256.h"
#include "tdesutil.h"


#ifdef LBBBBBBBBBBBBBBBBB
void DES()
{
  /*
    int l, bit;
    FILE*  fp;
    char   filename[100];
    unsigned long  c, displayMask = 1 << 31;
    unsigned long A;
    static ULONG tx[5] = {0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0};
  */

  int    keylen = 160;  /* 160 <= keylen  <= 512:  Must be a multiple of 8. */
  int    seedlen = 160; /* 160 <= seedlen <= 512:  Must be a multiple of 8. */
  BYTE   *Xkey;
  BYTE   *X;
  BYTE   *Q_;
  BYTE   *Xseed;
  BYTE   xval[64];
  BYTE   temp[66];
  BYTE   power2[66];
  BYTE   one[2];
  BYTE   G[DSA_H_SIZE];
  int    k, n0, n1, bitsRead, length;
  int    done = 0;
  BYTE   *T;
  int    counter;

  if (((epsilon = (BitField *) calloc(tp.n,sizeof(BitField))) == NULL) ||
     ((T = (BYTE*)calloc(8,sizeof(BYTE))) == NULL)) {
     fprintf(output,"Insufficient memory available.\n");
     exit(1);
  }
  else {
  Xseed = (BYTE*)calloc(20,sizeof(BYTE));
  Xkey  = (BYTE*)calloc(20,sizeof(BYTE));
  Q_    = (BYTE*)calloc(20,sizeof(BYTE));
  X     = (BYTE*)calloc(20,sizeof(BYTE));
  bzero(T,8);
  bzero(Xseed,20);
  bzero(Xkey,20);
  bzero(X,20);
  bzero(Q_,20);

  bzero(power2,66);				/* set power2 = 2^keylen */
#ifdef LITTLE_ENDIAN
  power2[66-keylen/8-2] = 0x01;
#else
  power2[66-keylen/8-1] = 0x01;
#endif

  bzero(one,2);
#ifdef LITTLE_ENDIAN
  one[0] = 0x01;
#else
  one[1] = 0x01;
#endif

  ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", Xseed, 20);
  ahtopb("ec822a619d6ed5d9492218a7a4c5b15d57c61601", Xkey, 20);
  ahtopb("b32a3033fbd7ba96168a6c396e760c2b1f5a3143", Q_, 20);
  bzero(xval,64);		/* temp = Xkey left padded out to 66 bytes */
  bzero(temp,66);
  bcopy(Xkey, &temp[66-keylen/8], keylen/8);
  add(temp,66,  Xseed, seedlen/8);	/* temp = temp + Xseed */

  Mod(temp, 66, power2, 66);			/* temp = temp mod 2&keylen */
  bcopy(&temp[66-keylen/8], xval, keylen/8);	/* xval = temp */
  length = (int)floor(tp.n/160);
  if ((tp.n)%160 != 0) length++;
  n0 = 0;
  n1 = 0;
  bitsRead = 0;
  counter = 1;
  /*fp = fopen("des1.data","wb");*/
  for(k = 0; k < tp.numOfBitStreams*length; k++) {
     G_from_DES(Xkey, Xseed, G);
     /*printnum("\nParam DES G  = ",G,20);*/
     /*fwrite(G,sizeof(BYTE),20,fp);*/
     done = convertToBits(G,tp.n,&n0,&n1,&bitsRead,0,5);    
     if (done) {
        /*
        fclose(fp);
        counter++;
        if (i+1 < tp.numOfBitStreams*length) {
           sprintf(filename, "des%d.data", counter);
           fp = fopen(filename,"wb");
        }
        */
        fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
        fflush(output);
        nist_test_suite();
        done = 0;
        n0 = 0;
        n1 = 0;
        bitsRead = 0;
     }
     /*printnum("\nParam Xkey   = ",Xkey,20);*/
     Mod(G,DSA_H_SIZE, Q_,DSA_Q_SIZE);
     bcopy(G, X, DSA_Q_SIZE);
     /*
     bzero(Xkey, 20);
     mbcopy(G,Xseed, 20);
     */
     /* Update XKEY : Compute XKEY = (1+XKEY+X) mod 2^keylen */

     bzero(temp,66);				/* temp = Xkey */
     bcopy(Xkey, &temp[66-keylen/8], keylen/8);
     add(temp,66,  X, DSA_X_SIZE);		/* temp = temp + X */
     add(temp,66, one, 2);			/* temp = temp + 1 */ 

     Mod(temp, 66, power2, 66); 		/* temp = temp mod 2&keylen */
     bcopy(&temp[66-keylen/8], Xkey, keylen/8); /* Xkey = temp */
  }
  free(T);
  free(Xseed);
  free(Xkey);
  free(Q_);
  free(X);
  free(epsilon);
  }
  return;
}

void SHA1()
{
	int		keylen = 160;  /* 160 <= keylen  <= 512:  Must be a multiple of 8. */
	int		seedlen = 160; /* 160 <= seedlen <= 512:  Must be a multiple of 8. */
	BYTE	*Xkey;
	BYTE	*Xseed;
	BYTE	xval[20];
	BYTE	temp[22];
	BYTE	power2[22];
	BYTE	*G;
	int		i, n0, n1, bitsRead, length;
	int		done = 0, counter;
	BYTE	*T;
	ULONG	tx[5], ulongInt;
	FILE	*fp1;
/*
  static ULONG tx[5] = {0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 
			0xc3d2e1f0};
*/

	/* Altered by J. Soto: 12/3/99 */ 

	/* Define the 1st word in the IV */
	if ( (fp1 = fopen("data/sha-iv.dat", "r")) == NULL ) {
		printf("file \"data/sha-iv.dat\" could not be opened. Exiting program.\n");
		return;
	}

	fscanf(fp1, "%08lx", &ulongInt);
	fclose(fp1);

	/* Update the 1st word in the IV */
	if ( (fp1 = fopen("data/sha-iv.dat", "w")) == NULL) {
		printf("file \"data/sha-iv.dat\" could not be opened. Exiting program.\n");
		return;
	}
	fprintf(fp1, "%08lx",ulongInt+1);
	fclose(fp1);

	/* DEFINE IV */
	for( i=0; i<5; i++ )
		tx[i] = ulongInt + (ULONG)i;

	if ( ((epsilon = (BitField *)calloc(tp.n, sizeof(BitField))) == NULL) ||
		 ((T = (BYTE*)calloc(8, sizeof(BYTE))) == NULL) ||
		 ((Xseed = (BYTE*)calloc(20, sizeof(BYTE))) == NULL) ||
		 ((Xkey  = (BYTE*)calloc(20, sizeof(BYTE))) == NULL)) {
		fprintf(output,"Insufficient memory available.\n");
		exit(1);
	}
	else {
		bzero(T, 8);
		bzero(Xseed, 20);
		bzero(Xkey, 20);
		ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", Xseed, 20);
		ahtopb("ec822a619d6ed5d9492218a7a4c5b15d57c61601", Xkey, 20);

		bzero(xval,20);		/* temp = Xkey left padded out to 66 bytes */
		bzero(temp,22);
		bcopy(Xkey, &temp[22-keylen/8], keylen/8);
		add(temp,22,  Xseed, seedlen/8);	/* temp = temp + Xseed */

		bzero(power2,22);			/* set power2 = 2^keylen */
#ifdef LITTLE_ENDIAN
		power2[22-2] = 0x01;
#else
		power2[22-1] = 0x01;
#endif
		for (i=0;i<keylen;i++)
			bshl(power2, 22);
		Mod(temp, 22, power2, 22);			/* temp = temp mod 2&keylen */
		bcopy(&temp[22-keylen/8], xval, keylen/8);	/* xval = temp */

		length = (tp.n + 159) / 160;
		n0 = 0;
		n1 = 0;
		bitsRead = 0;
		counter = 1;
		for( i=0; i<tp.numOfBitStreams*length; i++ ) {
			G = NULL;
			shaG(tx, keylen, xval, &G, 160);
			done = convertToBits(G, tp.n, &n0, &n1, &bitsRead, 0, 5);    
			bcopy(G, xval, 20);
			FREE(G);
			if ( done ) {
				fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
				fflush(output);
				nist_test_suite();
				done = 0;
				n0 = 0;
				n1 = 0;
				bitsRead = 0;
			}
		}
		free(epsilon);
		free(Xkey);
		free(Xseed);
		free(T);
	}

	return;
}

void ANSI()
{					     /* Both must be a multiple of 8. */
  /* int           keylen = 160, seedlen = 160; */ /* 160 <= keylen, seedlen <= 512 */    
  /* int           k, l, bit;
     FILE*         fp;
     char          filename[100];
     unsigned long A, c, displayMask = 1 << 31;
  */

  BYTE          *T, *Xkey, *Xseed, G[DSA_H_SIZE];
  int           i, n0, n1, bitsRead, done, length, counter;

  if (((epsilon = (BitField *) calloc(tp.n,sizeof(BitField))) == NULL) ||
     ((T = (BYTE*)calloc(8,sizeof(BYTE))) == NULL) ||
     ((Xseed = (BYTE*)calloc(20,sizeof(BYTE))) == NULL) ||
     ((Xkey  = (BYTE*)calloc(20,sizeof(BYTE))) == NULL)) {
     fprintf(output,"Insufficient memory available.\n");
     exit(1);
  }
  else {
  bzero(T,8);
  bzero(Xseed,20);
  bzero(Xkey,20);
  bzero(G,20);
  ahtopb("237c5f791c2cfe47bfb16d2d54a0d60665b20904", Xseed, 20);
  ahtopb("ec822a619d6ed5d9492218a7a4c5b15d57c61601", Xkey, 20);
  length = (int)floor(tp.n/160);
  if ((tp.n)%160 != 0) length++;
  n0 = 0;
  n1 = 0;
  done = 0;
  bitsRead = 0;
  counter = 1;
  /*fp = fopen("ansi1.data","wb");*/
  for(i = 0; i < tp.numOfBitStreams*length; i++) {
     G_from_ANSI(Xkey, Xseed, G);
     /*printnum("\nParam ANSI G = ",G,20);*/
     /*fwrite(G,sizeof(BYTE),20,fp);*/
     done = convertToBits(G,tp.n,&n0,&n1,&bitsRead,0,5);    
     if (done) {
        /*
        fclose(fp);
        counter++;
        if (i+1 < tp.numOfBitStreams*length) {
           sprintf(filename, "ansi%d.data", counter);
           fp = fopen(filename,"wb");
        }
        */
        fprintf(output,"\t\tBITSREAD = %d 0s = %d 1s = %d\n",bitsRead,n0,n1);
        fflush(output);
        nist_test_suite();
        done = 0;
        n0 = 0;
        n1 = 0;
        bitsRead = 0;
     }
     bzero(Xseed, 20);
     mbcopy(G,Xseed, 20);
  }
  free(epsilon);
  free(T);
  free(Xseed);
  free(Xkey);
  return;
  }
}
#endif

#ifdef LBBBBBBBBBBBBB
int shaG(ULONG tval[], int lenc, BYTE* c, BYTE* G)
/* -----------------------------------------------------------------------------
   This is the implementation of the G-function based on a subset
   of SHA steps as defined in Appendix 3.3 of the DSS.

   INPUTS:
       tval	Points to initial hash array (IH) to initialize the SHA with
       lenc	Length of c in bits <= 512
		** for this implementation seedlen must be divisible by 8
       c	160-512 bit SEED. 
   OUTPUTS:
       G	160-bit return value
------------------------------------------------------------------------------*/
{
  BYTE  	M1[20];  		/* 512 bit SHA block */
  SHA_CTX  	shaContext;

#ifdef LITTLE_ENDIAN
  int           i;
#endif

  bzero(M1, 20);
  bcopy(c, M1, lenc/8);

#ifdef LITTLE_ENDIAN
  /* Convert Seed C which is assumed to be formatted as a multi-precision
     integer into a sequence of 32-bit long words which is the format
     the SHA expects */
  
  for (i=0;i<5;i++)
      cDIGITS2LONG((DIGIT *)&M1[i*4]);
  byteReverse((ULONG*)M1,20);
#endif

  /* Do not apply SHAFinal here.  Only steps (a)-(e) are to be used. */

  SHAInit2 (&shaContext, tval);
  SHAUpdate (&shaContext, M1, 20*8);

  bcopy((BYTE *)shaContext.H, G, 20);

#ifdef LITTLE_ENDIAN
  for (i=0;i<5;i++)
      cLONG2DIGITS((DIGIT *)&G[i*4]);
#endif

  return 0;
} /* END shaG */
#endif

int shaG256(ULONG tval[], int lenc, BYTE* c, BYTE* G)
/* -----------------------------------------------------------------------------
   This is the implementation of the G-function based on a subset
   of SHA steps as defined in Appendix 3.3 of the DSS.

   INPUTS:
       tval	Points to initial hash array (IH) to initialize the SHA with
       lenc	Length of c in bits <= 512
		** for this implementation seedlen must be divisible by 8
       c	160-512 bit SEED. 
   OUTPUTS:
       G	160-bit return value
------------------------------------------------------------------------------*/
{
	BYTE  		M1[32];  		/* 512 bit SHA block */
	SHA256_CTX  	shaContext;
	FILE	*fp;

#ifdef LITTLE_ENDIAN
	int           i;
#endif

	bzero(M1, 32);
	bcopy(c, M1, lenc/8);

#ifdef LITTLE_ENDIAN
	/* Convert Seed C which is assumed to be formatted as a multi-precision
	integer into a sequence of 32-bit long words which is the format
	the SHA expects */

	for ( i=0; i<8; i++ )
		cDIGITS2LONG((DIGIT *)&M1[i*4]);
	byteReverse((ULONG*)M1, 32);
#endif

	/* Do not apply SHAFinal here.  Only steps (a)-(e) are to be used. */

	SHA256_Init2 (&shaContext, tval);
	SHA256_Update (&shaContext, M1, 32*8);

	fp=fopen("data.txt", "a");
	for ( i=0; i<32; i++ )
		fprintf(fp, "%08x", M1[i]);
	fprintf(fp,"\n");
	fclose(fp);

	bcopy((BYTE *)shaContext.H, G, 32);

#ifdef LITTLE_ENDIAN
	for ( i=0; i<8; i++ )
		cLONG2DIGITS((DIGIT *)&G[i*4]);
#endif

	return 0;
} /* END shaG */

void G_from_DES(BYTE *t, BYTE *c, BYTE *G)
/* t and c are assumed to be 160 bits long */
{
  ULONG T[5], C[5];
  BYTE *byteptr_t, *byteptr_c;
  int i;

  byteptr_t = t;
  byteptr_c = c;

  for(i = 0; i < 5; i++)  {   		/* Convert into unsigned longs */
     VOID_to_UL(&T[i], byteptr_t);
     VOID_to_UL(&C[i], byteptr_c);
     byteptr_t +=4; 			/* On to next dword */
     byteptr_c +=4;
  }
  GDES(T, C, G);			/* Calculate GDES */
}

void GDES(ULONG *t, ULONG *c, BYTE *outbuf)
{
  ULONG a1, a2, b1, b2;
  ULONG x[5], y[5][2], z[5];
  BYTE  A[8];				/* Packed 8 byte block */
  BYTE  K[8];				/* Packed 8 byte key */
  int i;

  for(i=0; i < 5; i++) 			/* Step 2 of the Appendix */
     x[i] = t[i] ^ c[i];
  for(i=0; i<5; i++)  {			/* Step 3 of the Appendix */
     b1 = c[((i + 4) % 5)];
     b2 = c[((i + 3) % 5)];
     a1 = x[i];
     a2 = x[((i + 1) % 5)] ^ x[((i + 4) % 5)];
     UL_to_VOID (A, a1);
     UL_to_VOID(&A[4], a2);
     UL_to_VOID(K, b1);			/* Load the DES key */
     UL_to_VOID(&K[4], b2);
     setkey(IGNORE_PARITY, ENCRYPT, K);
     des(A,A);				/* Replace A with encrypted A */
     VOID_to_UL(&y[i][0], A);		/* Store y1 */
     VOID_to_UL(&y[i][1], &A[4]);	/* Store y2 */
  }
  for(i=0; i<5; i++) {			/* Complete step 4 and store */
     z[i] = y[i][0] ^ y[((i + 2) % 5)][1] ^ y[((i + 3) % 5)][0];
     UL_to_VOID(&outbuf[i*4], z[i]);
  }
}

void G_from_ANSI(BYTE *t, BYTE *c, BYTE *G)
/**************************************************************************
* FUNCTION: ANSI X9.17 Pseudorandom Number Generator                      *
*                                                                         *
* This function requires a 64 bit vector, as well as a 64 bit key.  The   *
* result required is 192 bit value.  To generate the required values, the *
* algorithm must run 3 times						  *
*                                                                         *
* INPUT:                               		                          *
*    BYTE *t	- 160 bit value	  					  *
*    BYTE *c 	- 160 bit value					  	  *
* OUTPUT							          *
*    BYTE *G   - 160 bit random number			          	  *
***************************************************************************/
{
  BYTE V[64];             /* Note: V must be large enough; V=16 + 16*N */
  BYTE K[10];             /* 64 bit key */
  int N = 3;		  /* Number of 64 bit values returned */

  bcopy(t, V, 8);	  /* Require starting vector */
  bcopy(c, K, 8);	  /* Load K with 64 bits */
  ANSI917(V, K, N, FALSE);
  bcopy(&V[8], G, 20);
}

void ANSI917(BYTE *V, BYTE *K, int N, int TestFlag)
/**************************************************************************
* FUNCTION: ANSI X9.17 Pseudorandom Number Generator                      *
*                                                                         *
* Generate random numbers according to the following:                     *
*	V0 = V;                                                           *
*	for j = 0 to (N-1) do {                                           *
*		I = DEAk(Tj)                                              *
*		Vj+1 = DEAk(DEAk(I xor Vj) xor I)                         *
*       }                                                                 *
* Where V is a 64 bit seed, K is a 128 bit keypair, T represents a series *
* of distinct 64 bit date/time vectors (monotonically increasing)         *
*                                                                         *
* INPUT:                                       			          *
*    BYTE *V	- 64 bit seed					          *
*    BYTE *K 	- single key to be encrypted  (64 bit)                    *
*    INT  N 	- Number of 64 bit results needed         	          *
*		0 for encryption, 1 for decryption		          *
*    INT TestFlag - TRUE: calling function directly (for standalone test) *
*		    FALSE: Generating G for DSS			          *
* RETURNS:                                                                *
*    Random vectors in V space                                            *
***************************************************************************/
{
  int i, j;
  BYTE I[8], IV[8], XI[8];
  BYTE *T;
  /*  char msg[5]; */

  if ((T = malloc((N+1) * 8)) == NULL) {
     printf("Cannot allocate sufficient memory to execute ANSI X9.17 ");
     printf("pseudorandom generator.\n");
     printf("Any resulting values should be discarded. ");
     printf("Memory Allocation Fault\n");
     return;
  }
  GenDTVector(T, 0); 			/* Generate new vector */
  if (TestFlag == TRUE) {           	/* Print out data/time vectors */
     printf("\nDate/Time Vectors are monotonically increasing from ");
     printf("rightmost byte.\n");
     printf("First Date/Time Vector = ");
     for(i=0; i<8; i++)              	/* Print out in hex */
        printf("%x\n", T[i]);
     printf("\n\n");
  }
  for(j=0; j <N; j++)  {
     GenDTVector(&T[8*(j+1)], 1); 	/* Generate another vector */

     /* This code prints ALL Date/Time vectors */
     if (TestFlag == TRUE) {           	/* Print out data/time vectors */
        printf("Date/Time Vector %d = ", j+1);
        for(i=0; i<8; i++)             	/* Print out in hex */
      	   printf("%x\n",T[8*(j+1)+i]);
        printf("\n");
     }
  }
  for(j=0; j < N; j++) {
     Crypt917(K, &T[j*8], I, 0, 1);	/* This returns I */
     xor(IV, I, &V[j*8], 8);		/* First encryption */
     Crypt917(K, IV, XI, 0, 1);  	/* This returns XI */
     xor(IV, I, XI, 8);
     Crypt917(K, IV, &V[(j+1)*8], 0, 1);/* Last encryption cycle */
  }
  free(T);
}

void GenDTVector(BYTE *dtvector, int genflag)
/**************************************************************************
* FUNCTION: Generate Date/Time Vector                      	          *
*                                                                         *
* Generate a date/time vector for ANSI 9.17.  If a vector was previously  *
* generated, increment the tm_sec byte.  Otherwise, generate a new vector.*
* NOTE:  Since the granularity of the time function is seconds, and the   *
* vectors do not have to be random, a simple increment is deemed 	  *
* sufficient.  There is no known standard format for this vector.         *
* If a previous vector was generated, it is assumed that that vector 	  *
* occupies the previous 8 bytes.				          *
*                                                                         *
* INPUT:                                       			          *
*    INT  genflag  - 0 for first-time generation, 1 for increment         *
*                                                                         *
* RETURNS:                                                                *
*    BYTE *dvector - 64 bit Date/Time vector		          	  *
***************************************************************************/
{
  BYTE *prevector;			/* Pointer to the previous vector */
  BYTE temp[2];
  time_t timer; 			/* Required to get time */
  struct tm *tblock;

  if (genflag == 1) {
     prevector = dtvector;		/* Init the pointer */
     prevector -=8;			/* Point at previous vector */
     memcpy(dtvector, prevector, 8);
     if (dtvector[7] == 0xff)   {
        dtvector[7] = 0;        	/* If greater than a char, wrap  */
        if (dtvector[6] == 0xff)  	/* Wrap */
	dtvector[5] = dtvector[5] + 1;
        dtvector[6] = dtvector[6] + 1;
     }
     else
	dtvector[7] = dtvector[7] + 1;
  }
  else {
     timer = time(NULL);

     /* converts date/time to a structure */
     tblock = localtime(&timer);

     /* load the time vector byte by byte */
     dtvector[0] = tblock->tm_sec;
     dtvector[1] = tblock->tm_min;
     dtvector[2] = tblock->tm_hour;
     dtvector[3] = tblock->tm_mday;
     dtvector[4] = tblock->tm_mon;
     dtvector[5] = tblock->tm_year;
     memcpy(temp, &tblock->tm_yday, 2);  /* Swap the two bytes of tm_yday */
     dtvector[6] = temp[1];
     dtvector[7] = temp[0];
  }
  return;
}

void UL_to_VOID (BYTE *buffer, ULONG longnum)
/**************************************************************************
* FUNCTION: Convert a Long into a Void                    	          *
*                                                                         *
* Intel stores longs in byte-reversed format.  To copy to a void buffer,  *
* you must perform a byte reversal: swap words and byte reverse.          *
*                                                                         *
* INPUT:                                       			          *
*    BYTE *buffer - Destination buffer    			          *
*    ULONG longnum - unsigned long number to process                      *
*                                                                         *
* RETURNS:                                                                *
*    Nothing                                           			  *
***************************************************************************/
{
  BYTE swap[4], num[4];
  BYTE temp;

  memcpy(num, &longnum, 4);			/* Set up local buffer */
  memcpy(&swap[0], &num[2], 2);
  memcpy(&swap[2], &num[0], 2);
  temp = swap[0];
  swap[0] = swap[1];
  swap[1] = temp;
  temp = swap[2];
  swap[2] = swap[3];
  swap[3] = temp;
  memcpy(buffer, swap, 4);
  return;
}

void VOID_to_UL (ULONG *longnum, BYTE *buffer)
/**************************************************************************
* FUNCTION: Convert a Void into a Long                    		  *
*                                                                         *
* Intel stores longs in byte-reversed format.  To copy from a void buffer,*
* you must perform a byte reversal: swap words and byte reverse.          *
*                                                                         *
* INPUT:                                       			          *
*    ULONG *longnum - destination unsigned long number                    *
*    BYTE *buffer - Source buffer    			                  *
*                                                                         *
* RETURNS:                                                                *
*    Nothing                                                              *
***************************************************************************/
{
  BYTE swap[4];
  BYTE temp;

  memcpy(&swap[0], &buffer[2], 2);  	/* Byte reverse */
  memcpy(&swap[2], &buffer[0], 2);
  temp = swap[0];                       /* Swap the bytes */
  swap[0] = swap[1];
  swap[1] = temp;
  temp = swap[2];
  swap[2] = swap[3];
  swap[3] = temp;
  memcpy(longnum, swap, 4);        	/* Copy to final destination */
  return;
}

void Crypt917(BYTE* key, BYTE* data, BYTE* result, UINT sw1, UINT sw2)
/******************************************************************************
* Encrypts or Decrypts a single or double length key with a		      *	
* double length key in the manner specified by ANSI 9.17		      *
*		        						      *
* sw1 => 0 for encryption, 1 for decryption 		      		      *
* sw2 => 1 for single length data, 2 for double length data		      * 
*******************************************************************************/
{
  BYTE temp[8];
  int  i;

  /* EDE or DED */
  for(i=0; i<(int)sw2; i++) {
     setkey(IGNOREPARITY, sw1, LeftHalf(key));
     des(&data[i*8], &result[i*8]);
     setkey(IGNOREPARITY, /*!sw1*/1, RightHalf(key));
     des(&result[i*8], temp);
     setkey(IGNOREPARITY, sw1, LeftHalf(key));
     des(temp, &result[i*8]);
  }
  return;
}

/*****************************************************************************
 *  dsa.c                                                      VERSION 2.01  *
 *---------------------------------------------------------------------------*
 *  D I G I T A L  S I G N A T U R E   S T A N D A R D  (DSS)                *
 *  FEDERAL INFORMATION PROCESSING STANDARDS PUBLICATION XXX                 *
 *  APRIL 1993                                                               *
 *---------------------------------------------------------------------------*
 *  This software was produced at the National Institute of Standards and    *
 *  Technology (NIST) as part of research efforts and is for demonstration   *
 *  purposes only. Our primary goals in its design did not include widespread*
 *  use outside of our own laboratories.  Acceptance of this software implies*
 *  that you agree to use it for non-commercial purposes only and that you   *
 *  agree to accept it as nonproprietary and unlicensed,not supported by NIST*
 *  and not carrying any warranty, either expressed or implied, as to its    *
 *  performance or fitness for any particular purpose.                       *
 *---------------------------------------------------------------------------*
 *  Produced by the National Institute of Standards and Technology (NIST),   *
 *  Computer Systems Laboratory (CSL) Security Technology Group.             *
 *---------------------------------------------------------------------------*
 *  History:								     *
 *  VERSION     DATE         AUTHOR           CHANGES			     *
 *   2.00b       ?          NIST CSL          Original                       *
 *   2.01     24 Oct, 1995  Isadore Schoen    DSS_GenX, DSS_GenK,            *
 *                                            DSS_GenKeyPair, DSS_Sign       *
 ****************************************************************************/

void
ahtopb (char *ascii_hex, BYTE *p_binary, int bin_len)
{
	BYTE	wbyte, wbyte2;
	int		i; 
	
	for ( i=0; i<bin_len; i++ ) {
        wbyte = ascii_hex[i * 2];
	    if (wbyte > 'F')
	        wbyte -= 0x20;   
	    if (wbyte > '9')
	        wbyte -= 7;      
	    wbyte -= '0';   
	    wbyte2 = wbyte << 4;

	    wbyte = ascii_hex[i * 2 + 1];
	    if (wbyte > 'F')
			wbyte -= 0x20;
        if (wbyte > '9')
            wbyte -= 7;   
        wbyte -= '0';
		wbyte2 += wbyte;

#ifdef LITTLE_ENDIAN
		p_binary[((i%2)==0)? i+1 : i-1] = wbyte2; 
#else
        p_binary[i] = wbyte2; 
#endif
	}
}

void
printnum(S,A,L)
 char *S;
 DIGIT A[];
 int L;
{
 int i;

 printf("%s",S);

  for (i=0;i < L/(signed int)sizeof(DIGIT); i++)
    if (sizeof(DIGIT) == 2)
      printf("%04x",A[i]);
    else
      printf("%02x",A[i]);
  printf("\n");

}

void
mbcopy(str1, str2, len)
BYTE str1[],str2[];
int len;
{
int i;
  for (i=0;i<len;i++)
    str2[i] = str1[i];
}
